<?php
// Kopieer naar config/config.php en vul in. config.php staat in .gitignore.
return [
    'db' => [
        'host' => 'localhost',
        'name' => 'JOUW_DB_NAAM',
        'user' => 'JOUW_DB_GEBRUIKER',
        'pass' => 'JOUW_DB_WACHTWOORD',
    ],
    'app_url'       => 'https://scriptspace.nl',   // zonder slash aan het eind
    'mail_from'     => 'system@scriptspace.nl',     // moet een bestaand STRATO-postvak zijn
    // SMTP via STRATO (aanbevolen, betere aflevering dan mail()). Weglaten = PHP mail().
    'smtp'          => ['host' => 'smtp.strato.com', 'port' => 465, 'secure' => 'ssl', // of 587 + 'tls'
                        'user' => 'system@scriptspace.nl', 'pass' => 'WACHTWOORD_VAN_HET_POSTVAK'],
    'mail_debug'    => false,                       // true = mails in storage/mail.log i.p.v. versturen (lokaal testen)
    // Sleutel voor versleutelde waarden (AI-keys). Genereren: php -r "echo 'base64:'.base64_encode(random_bytes(32)).PHP_EOL;"
    'app_key'       => 'base64:VERVANG_DOOR_EIGEN_SLEUTEL',
    // 'discord_webhook' => 'https://discord.com/api/webhooks/ID/TOKEN',  // alleen voor de test in Admin, Verbindingen (kanaalinstellingen, Integraties, Webhooks)
    // 'registration_open' => true,   // false = niemand kan zich nog registreren (ook niet via OAuth); bestaande accounts blijven werken
    // 'update_check' => true,        // false = nooit op nieuwe versies controleren (er wordt dan niets naar GitHub gestuurd)
    // 'update_repo' => 'Die0uwe/scriptspace-releases',   // publieke repo met de releases
    // 'updater' => false,            // true = Admin, Updates mag ondertekende releases installeren. Zie docs/DEPLOY.md (mapmachtigingen!)
    // 'update_pubkey' => '',         // publieke sleutel (base64); standaard die uit includes/update_pubkey.php
    // 'php_exec' => false,           // true = ▶ PHP in de sandbox aanzetten (alleen super_admin). Geen echte sandbox: zet het alleen aan op een server die je zelf vertrouwt.
    // 'php_bin' => '/usr/bin/php',   // pad naar php-cli voor ▶ PHP (alleen nodig als het niet automatisch wordt gevonden)
    // 'backup_keep' => 10,    // aantal back-ups dat op de server bewaard blijft
    // 'debug' => true,       // alleen lokaal: toont fouten; standaard verborgen en gelogd in storage/php-error.log
    // 'hsts'  => true,       // zet aan zodra https overal werkt (browser onthoudt dat 1 jaar)
    'install_token' => 'VERZIN_EEN_LANGE_WILLEKEURIGE_TEXT', // nodig voor install.php (eerste admin)
    'cron_token'    => 'VERZIN_EEN_ANDERE_LANGE_TEXT',       // alleen nodig voor een externe cron-dienst (cron/cleanup_task.php)
    // 'auto_cleanup_hours' => 6,   // CMS ruimt zelf op (geen cron nodig), hoogstens elke N uur; 0 = uit
    // 'audit_keep_days'    => 180, // audit-log langer dan dit aantal dagen wordt opgeschoond (minimaal 30)
    // 'ai_mock'    => true,   // ALLEEN voor tests: nep-AI-antwoorden zonder externe aanroep
    // Inloggen met GitHub / Google / Discord: laat een provider weg of leeg om hem uit te zetten.
    // Callback-URL bij elke provider: https://scriptspace.nl/login.php?provider=github  (of =google, =discord)
    'oauth' => [
        'github'  => ['client_id' => '', 'client_secret' => ''],
        'google'  => ['client_id' => '', 'client_secret' => ''],
        'discord' => ['client_id' => '', 'client_secret' => ''],
    ],
    'turnstile'     => ['site_key' => '', 'secret' => ''],   // Cloudflare Turnstile; leeg = captcha uit
];
