<?php
// verify.php — activeert een account via de mail-link.
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';
require_once __DIR__ . '/includes/layout.php';

$token = (string)($_GET['t'] ?? '');
$ok = false;

if (preg_match('/^[a-f0-9]{64}$/', $token)) {
    $hash = hash('sha256', $token);
    $st = db()->prepare("SELECT id FROM users WHERE verify_token_hash = ? AND verify_expires > NOW() AND email_verified_at IS NULL AND deleted_at IS NULL");
    $st->execute([$hash]);
    if ($row = $st->fetch()) {
        db()->prepare("UPDATE users SET email_verified_at = NOW(), verify_token_hash = NULL, verify_expires = NULL WHERE id = ?")->execute([$row['id']]);
        audit('auth.email_verified', (int)$row['id']);
        redirect('login.php?verified=1');
    }
}

page_header('Bevestigen');
?>
<div class="card narrow">
  <h1>Link ongeldig</h1>
  <div class="msg err">Deze bevestigingslink is ongeldig of verlopen. Registreer opnieuw of log in als je al bevestigd hebt.</div>
  <a class="btn ghost" href="register.php">Opnieuw registreren</a>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : verify.php                                                ║
// ║  Role    : Auth                                                      ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : E-mailverificatie via tokenlink                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
