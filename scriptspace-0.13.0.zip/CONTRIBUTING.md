# Bijdragen

Privé project van @Die0uwe. Voor wie meewerkt:

1. Werk op een branch; commit klein en beschrijvend (Nederlands of Engels, consistent).
2. Nieuwe pagina's: begin met `require_permission('...')` of `require_login()`; POST-formulieren altijd met `csrf_field()` en `csrf_verify()`.
3. Gebruik prepared statements, `e()` bij uitvoer, `audit()` bij gevoelige acties.
4. Draai lokaal `php -l` op gewijzigde bestanden en `tests/flow_test.py` (zie README).
5. Noteer wijzigingen in `CHANGELOG.md`.
6. Zet nooit secrets in de repo (`config/config.php` staat in `.gitignore`).
