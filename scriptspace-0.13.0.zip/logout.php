<?php
// logout.php — sessie volledig afbreken.
declare(strict_types=1);
require_once __DIR__ . '/includes/bootstrap.php';

// Alleen POST met CSRF-token: voorkomt dat een andere site je kan uitloggen
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_verify()) { redirect('index.php'); }
$uid = $_SESSION['user_id'] ?? null;
if ($uid) { audit('auth.logout', (int)$uid); }
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();
redirect('index.php');

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : logout.php                                                ║
// ║  Role    : Auth                                                      ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Sessie afbreken                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
