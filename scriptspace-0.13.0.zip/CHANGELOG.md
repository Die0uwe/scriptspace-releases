# Changelog

## [0.13.0] — 2026-10-01 — Veilige updater, afbeeldingsgrootte in de editor, handleiding
- Nieuw: Admin, Updates kan een nieuwe release zelf installeren (staat standaard uit: `'updater' => true` in `config.php`). Elke release is digitaal ondertekend (Ed25519); de site controleert de handtekening, de zip en elk afzonderlijk bestand tegen het ondertekende manifest vóór er iets verandert. GitHub hoeft dus niet vertrouwd te worden
- Veilig uitpakken: pad-trucs (`..`, absolute paden), symlinks, onbekende bestandstypen en bestanden buiten het manifest worden geweigerd; PHP-syntaxcontrole van alle nieuwe bestanden zonder uit te voeren; `config/`, `storage/`, `sandboxes/` en `.env` worden nooit aangeraakt; verouderde bestanden van de vorige release worden opgeruimd
- Voorzichtig vervangen: database-back-up vooraf, snapshot van alle te vervangen bestanden, onderhoudsmodus (503, verloopt zelf), per bestand atomair vervangen met `index.php` en `bootstrap.php` als laatste, daarna migraties en een health-check. Mislukt er iets, dan wordt automatisch teruggezet. Knop "Vorige versie terugzetten" voor achteraf. Wachtwoordbevestiging, audit-log en slot tegen dubbel draaien
- `tools/release.py` (op je eigen computer): `keygen` maakt het sleutelpaar, `build` maakt zip + manifest + handtekening en controleert dat de sleutel bij `includes/update_pubkey.php` hoort. De private sleutel verlaat je computer nooit
- Editor: afbeelding invoegen vraagt nu ook de breedte (px of %); een afbeelding aanklikken geeft een grootte-balk (25/50/75/100%, eigen waarde, herstel, links/midden/rechts, verwijderen) en een sleephandvat
- Publieke releasesleutel ingesteld (`includes/update_pubkey.php`); alleen releases ondertekend met de bijbehorende private sleutel worden geïnstalleerd
- Playground: nieuwe standaardindeling: kolom 1 editor met de bestanden eronder, kolom 2 breed met preview en console, kolom 3 smal met de AI. Heb je zelf een indeling opgeslagen, kies dan "3 kolommen (standaard)" bovenin om de nieuwe te krijgen
- Fix: Facebook-kleur ontbrak (PHP-waarschuwing), `registration_open` werd bij registreren genegeerd, mislukte mails worden nu ook in het serverlog gezet
- Nieuw: `docs/HANDLEIDING.md` (wat zit erin, wat moet er nog bij, aandachtspunten)
- Tests: `php tests/updater_install_test.php` (61 controles, ook in de CI) en nieuwe onderdelen in `tests/flow_test.py`

## [0.12.1] — 2026-10-01 — Accounts samenvoegen en navigatie
- Nieuw: Account, Accounts samenvoegen (`user/merge.php`). Heb je per ongeluk twee accounts (bijvoorbeeld Discord met een ander e-mailadres), dan behoud je het account waarmee je bent ingelogd en voeg je het andere erin samen. Eerst bewijs je dat het andere account van jou is: met zijn gekoppelde GitHub/Google/Discord-login, of met zijn gebruikersnaam/e-mail en wachtwoord (met dezelfde inlogbegrenzing). Daarna zie je precies wat er verhuist en bevestig je met je eigen wachtwoord
- Wat verhuist: inlogkoppelingen, sandboxes, socials, API-sleutels en rollen. Is een dienst al aan jouw account gekoppeld, dan wint jouw koppeling. Het oude account wordt verwijderd; beide e-mailadressen krijgen een bevestigingsmail; alles staat in het audit-log (`account.merged`). Geblokkeerde of onbevestigde accounts kunnen niet worden samengevoegd; het bewijs geldt 10 minuten, alleen in die sessie en eenmalig. Niet terug te draaien: maak eerst een back-up
- Fix: de homepage en de playground hadden geen link naar het adminpaneel en het account; die staan er nu (Admin alleen voor wie `admin.access` heeft)

## [0.12.0] — 2026-10-01 — Versie, databasemigraties en updatecontrole
Eerste stap naar een veilige updater (0.13.0): nu alleen controleren en melden, nog niets automatisch installeren.
- Bestand `VERSION` (x.y.z) als enige bron voor de geïnstalleerde versie; versies worden numeriek vergeleken (1.10.0 > 1.9.0)
- Databasemigraties: `sql/migrations/NNNN_naam.sql`, bijgehouden in `schema_migrations` (met checksum). Idempotent, stopt bij de eerste echte fout zonder die migratie vast te leggen, vergrendeld tegen dubbel draaien. Een verse installatie markeert alles als toegepast; `0001_baseline` en `0002_rechten` vervangen de handmatige SQL uit `docs/DEPLOY.md` voor oude installaties
- Updatecontrole: de laatste release van de publieke releases-repo (standaard `Die0uwe/scriptspace-releases`, `update_repo`) via de GitHub-API met User-Agent en ETag. Hoogstens elke 6 uur (bij een fout elk uur) via de pseudo-cron, zonder cron; uit te zetten met `'update_check' => false`. Concepten, pre-releases en vreemde tags worden genegeerd
- Admin, Updates (recht `system.update`, standaard alleen super_admin): versie, nieuwste release met notities, "Nu controleren" en "Migraties uitvoeren"; op het adminoverzicht verschijnt een melding bij een nieuwe versie of openstaande migraties
- Tests: `php tests/update_migrate_test.php` (ook in de CI)

## [0.11.0] — 2026-10-01 — Testpaneel voor verbindingen
- Nieuw: Admin, Verbindingen (`admin/connections.php`, recht `system.test`, standaard alleen super_admin)
- Testmail versturen (standaard naar je eigen adres) met de gebruikte methode (SMTP, `mail()` of debug) en bij SMTP de precieze reden van een mislukking (verbinding, inloggen, afzender, ontvanger)
- Testbericht naar een Discord-webhook (`'discord_webhook'` in `config.php`, of een tijdelijk geplakte URL die niet wordt opgeslagen). Alleen `discord.com`/`discordapp.com`-webhooks worden geaccepteerd; de URL wordt gemaskeerd getoond; foutcodes krijgen uitleg (404, 401, 429)
- Database-test, opslagtest (storage en sandboxes schrijfbaar), bereikbaarheidstest van GitHub, Google, Facebook en Discord
- OAuth-overzicht: welke providers ingesteld zijn en welke redirect-URL je bij de provider moet zetten
- Maximaal 20 tests per uur per gebruiker, elke test in het audit-log (`conn.test`), CSRF op alles
- `send_mail()` en `smtp_send()` geven optioneel de reden terug (bestaande aanroepen blijven werken)
- Bestaande installatie: super_admin heeft het recht automatisch (`*`); wil je het aan admins geven, voer dan de `INSERT IGNORE` uit `docs/DEPLOY.md` uit

## [0.10.2] — 2026-10-01 — Beveiliging: OAuth pre-hijack en PHP-sandbox
**Opgelost: pre-hijack via OAuth**
- Iemand kon het e-mailadres van een ander registreren (onbevestigd, eigen wachtwoord). Logde het slachtoffer later in via Google, GitHub of Discord, dan werd dat account bevestigd en bleef het wachtwoord van de aanvaller werken. Een onbevestigd account wordt nu bij OAuth-login verwijderd en vervangen door een nieuw account zonder wachtwoord (`auth.oauth_unverified_replaced` in het audit-log)
- Gevolg voor een echte gebruiker die zich registreerde maar de mail niet bevestigde: bij OAuth-login begint hij met een vers account en gebruikt "wachtwoord vergeten" om een wachtwoord te kiezen

**Aangescherpt: PHP uitvoeren (▶ PHP)**
- Staat standaard uit: zet `'php_exec' => true` in `config.php` om het aan te zetten
- Alleen `super_admin`; `admin` verliest `php.execute` (schema én een rolcontrole in code, dus ook zonder SQL veilig)
- php-cli draait met `-n` (geen shared extensies: PDO, mysqli, curl, ftp, sockets, posix bestaan niet), `disable_classes`, uitgebreide `disable_functions` (DNS, `error_log`, `posix_kill`, `php_uname` e.a.)
- Harde limieten via `prlimit` (bestand max 1 MB, 6 s CPU, 64 open bestanden). Zonder `prlimit` staat PHP uitvoeren uit
- Docs zijn eerlijker: dit is best-effort afscherming, geen echte sandbox

**Tests en CI**
- Nieuwe tests: pre-hijack, admin zonder super_admin, bypass-lijst (klassen/functies), schrijflimiet; `auto_cleanup_test.php` draait nu ook in de CI

## [0.10.1] — 2026-10-01 — Opschonen zonder cron
- STRATO draait geen cron: het CMS ruimt nu zelf op ("pseudo-cron"). Na een gewone GET-paginaweergave draait `cleanup_run()` hoogstens elke 6 uur (`auto_cleanup_hours`, 0 = uit), na het versturen van het antwoord, met een bestandsslot zodat maar één verzoek het doet. Kost bij elke andere paginaweergave één `filemtime()`
- Opschonen verwijdert nu ook audit-log ouder dan 180 dagen (`audit_keep_days`, minimaal 30), zodat de tabel niet onbegrensd groeit
- Admin, Opschonen toont het interval en de laatste automatische ronde; cron-token blijft alleen nodig voor een externe cron-dienst
- Test: `php tests/auto_cleanup_test.php`

## [0.10.0] — 2026-09-30 — Account-koppelingen, visuele modus, download/upload, layout
**Account en socials**
- Account-pagina toont alle gekoppelde accounts (GitHub, Google, Discord, Facebook) met koppelen en ontkoppelen, en een socials-lijst (YouTube, Facebook, Instagram, X, Twitch, TikTok, LinkedIn, website)
- Koppelen vanuit je account gaat via POST + CSRF + `state`; een identiteit van een ander account kan nooit worden overgenomen; je laatste inlogmethode kun je niet ontkoppelen
- Accounts die via OAuth zijn gemaakt hebben geen wachtwoord (`password_set`): ze kunnen er op de account-pagina één instellen zonder "huidig wachtwoord"
- Nieuwe service toevoegen = één regel in `SOCIAL_SERVICES` (`includes/socials.php`) of in `OAUTH_DEFS` (`includes/oauth.php`)
- Facebook: alleen koppelen vanuit je account, daarna inloggen; nooit een nieuw account of overname via e-mail (Facebook bevestigt e-mail niet betrouwbaar)
- Profiel-links zijn gemarkeerd als niet geverifieerd, worden gevalideerd (https, juiste host, geen inloggegevens) en krijgen `rel="nofollow ugc"`
- Admin: gebruikerslijst toont koppelingen als badges; gebruikersdetail toont alle koppelingen (geverifieerd/profiel-link)
- Tabellen `oauth_identities` (uitgebreid), `social_links`; kolom `users.password_set`

**Playground**
- Visuele modus (Preview | ✏ Visueel): klik en typ direct in de pagina; werkbalk (stijl, vet, cursief, lijsten, uitlijning, link, afbeelding, tabel, kleuren); eigenschappenpaneel (kleur, achtergrond, grootte, ruimte, afronding, breedte, verplaatsen, dupliceren, verwijderen)
- Schrijft alleen de inhoud van `<body>` terug; `<head>`, doctype, scripts en CSS blijven letterlijk staan; plakken wordt opgeschoond; in een iframe zonder scripts
- Download: los bestand of hele sandbox als ZIP; upload van losse bestanden of ZIP (ook slepen); `api/sandbox_io.php` met zip-slip-, symlink-, grootte- en aantalcontroles en limiet 30 uploads per uur

**Layout**
- Beheerpagina's: gedeelde tabbalk, tabellen scrollen binnen hun kaart, lange e-mails/logregels breken netjes, filters lopen door op smalle schermen; automatische controle op 1280 en 390 px

**Tests**: flow_test +130 controles (OAuth, account, socials, download/upload), ui_test +35 (visuele modus, download/upload, layout)

## [0.9.0] — 2026-09-30 — Inloggen met GitHub, Google en Discord
- OAuth-login terug, nu gekoppeld aan het echte accountsysteem (rollen, rechten, audit-log) in plaats van een losse sessie
- `includes/oauth.php`; `login.php?provider=github|google|discord` blijft de callback-URL, dus bestaande app-instellingen bij de providers blijven geldig
- Knoppen op de startpagina, inlogpagina en registratiepagina, alleen voor providers die in `config.php` staan
- Koppelen aan een bestaand account uitsluitend via een door de provider **bevestigd** e-mailadres; onbevestigd = geen koppeling (voorkomt accountovername)
- Nieuw account: unieke gebruikersnaam, e-mail als geverifieerd, standaardrol `user`; geblokkeerde accounts komen er niet in
- Tabel `oauth_identities`; `state`-controle, uitgaand alleen HTTPS, limiet 30 pogingen per 10 min per IP
- Terugval: het oude `config/oauth_config.php` (client id/secret) wordt nog gelezen als `oauth` in `config.php` ontbreekt
- Tests: nep-provider, 23 controles (aanmaken, koppelen, overname, state, geblokkeerd, naamconflict)

## [0.8.0] — 2026-09-30 — AI-antwoorden streamen
- Het AI-antwoord verschijnt nu terwijl het binnenkomt (Server-Sent Events) via `api/ai_stream.php`; DeepSeek en Gemini
- `■ Stop`-knop: breekt af en bewaart het gedeeltelijke antwoord; ook verbroken verbindingen stoppen de providerverbinding
- Automatische terugval op `api/ai_chat.php` (antwoord in één keer) als de host streaming buffert of blokkeert
- Gedeelde logica in `includes/ai.php`; validatie, uurlimiet en key-ontsleuteling gebeuren vóór de stroom start (fouten blijven gewone JSON)
- Sessie wordt tijdens lange AI- en PHP-verzoeken vrijgegeven, zodat de rest van de pagina niet wacht
- Tests: stream-frames, samengevoegd == niet-gestreamd antwoord, gespreide aankomst, foutstatussen, Stop in de browser

## [0.7.0] — 2026-09-30 — PHP uitvoeren (alleen beheerders)
- `▶ PHP`-knop in de playground met optionele querystring; uitvoer verschijnt in de preview, stderr en tijd in de console
- `.php`-bestanden in sandboxes voor gebruikers met `php.execute`; op schijf opgeslagen als `.php.sbx`
- `api/php_run.php` en `includes/phprun.php`: apart php-cli-proces met `open_basedir`, uitgeschakelde functies, tijd-, geheugen- en uitvoerlimieten, 60 runs per uur, audit-log
- Detectie van `proc_open` en php-cli; knop uitgeschakeld met uitleg als de server het niet toestaat (`php_bin` in config)
- Ace PHP-modus meegeleverd; opschoonroutine ruimt achtergebleven tijdelijke mappen op
- Tests: 30+ controles, waaronder pogingen om `config.php` te lezen, shell te starten en te ontsnappen

## [0.6.0] — 2026-09-30 — Wachtwoord vergeten
- `forgot.php` en `reset.php`: eenmalige link (1 uur, hash in database), geen verklikker of een account bestaat, rate-limits per IP en per account
- `user/account.php`: wachtwoord wijzigen met huidig wachtwoord en begrenzing van pogingen
- Wachtwoordwijziging maakt alle andere sessies ongeldig (`password_changed_at`) en stuurt een mail naar de eigenaar
- Schema: tabel `password_resets`, kolom `users.password_changed_at` (nieuwe installaties; er is nog geen live database om te migreren)
- Login: link "Wachtwoord vergeten?"; dashboard: knop naar account en juiste link naar de playground
- Tests: ruim 35 extra controles

## [0.5.0] — 2026-09-30 — Beveiligingscontrole en uitrolplan
- Fouten worden nooit getoond maar gelogd (`storage/php-error.log`), nette 500-melding; optioneel `debug`
- Logout alleen via POST + CSRF-token
- Beveiligingsheaders en CSP ook vanuit PHP (playground uitgezonderd); optionele HSTS (`hsts`)
- `.htaccess` voor `tests/` en `docs/`
- `install.php`: omgevingscontrole en gegenereerde `app_key`
- Nieuwe docs: `docs/DEPLOY.md` (live zetten op STRATO, testadres, terugweg) en `docs/SECURITY-AUDIT.md`
- Tests: headers, logout, hernoemen-aanvallen, `.htaccess`-aanwezigheid, XSS-sanering van AI-Markdown

## [0.4.1] — 2026-09-30 — Instelbare werkruimte
- Playground-indeling in kolommen met blokken (Bestanden, Editor, Preview, Console, AI): presets (3 kolommen, 4 kolommen, AI lezen, editor+preview, editor+AI, alleen editor/preview), blokken verplaatsen of verbergen via "Indeling…", scheidingen slepen (ook met pijltjestoetsen), keuze blijft bewaard
- Console is nu een eigen blok
- AI-antwoorden overzichtelijker: ruimere typografie, kop per antwoord met model, lange codeblokken standaard ingeklapt, regelafbreking, "Lezen"-modus (groot venster) en "hele antwoord kopiëren"
- Smalle schermen: blokken onder elkaar

## [0.4.0] — 2026-09-30 — Back-up, herstel en opschonen
- `admin/backup_manage.php`: volledige, database- of bestandsback-up als ZIP (SQL-export in PHP, geen `mysqldump` nodig), download, verwijderen, uploaden, retentie (`backup_keep`)
- Herstel alleen voor super admin met wachtwoord en bevestigingswoord; noodback-up vooraf; SQL-whitelist per regel; zip-slip-bescherming; `config.php`, `storage/`, `sandboxes/`, `.git/` worden nooit overschreven
- `admin/system_cleanup.php`: handmatige knop met voorvertoning; ruimt verlopen sandboxes, losse sandbox-mappen, oude inlogpogingen en niet-bevestigde accounts (> 7 dagen) op
- `cron/cleanup_task.php` gebruikt dezelfde logica (`includes/maintenance.php`)
- Tests: ruim 30 extra controles in `flow_test.py`

## [0.3.1] — 2026-09-30
- Licentie: GPL-3.0 (`LICENSE`)
- Mail: SMTP-client (`smtp_send`) voor STRATO (smtp.strato.com, 465 SSL / 587 STARTTLS); valt terug op `mail()` als `smtp` niet is ingesteld

## [0.3.0] — 2026-09-30 — Playground
- Nieuwe `playground.php`: Ace-editor, bestandsbeheer, live preview in `iframe sandbox` (zonder `allow-same-origin`), console-brug met "Fix met AI", apparaatbreedtes, full-screen
- AI-assistent via server-side proxy (`api/ai_chat.php`): DeepSeek en Gemini, eigen key per gebruiker (AES-256-GCM), 40 berichten/uur, Markdown-rendering met DOMPurify en knoppen "Toepassen in editor", "Nieuw bestand", "Kopieer"
- JSON-API's: `api/sandbox.php`, `api/files.php`, `api/ai_keys.php`, `api/ai_chat.php` (login, permissie, CSRF, padbeveiliging, extensie- en groottelimieten)
- Sandboxes: quota 3 actief, 72 uur TTL, nooit direct via de webserver bereikbaar
- Vendored libraries (Ace, marked, DOMPurify, highlight.js) zonder CDN
- Twee oude playground-varianten (`app.js`, `ai_chat.php` in root) samengevoegd en verwijderd; keys staan niet meer in `localStorage`
- Tests: API-controles in `flow_test.py`, nieuwe browsertest `tests/ui_test.py`

## [0.2.0] — 2026-09-30 — Auth v2 naar Blueprint-model
- **RBAC**: tabellen `roles`, `permissions`, `role_permissions`, `user_roles`; rollen `super_admin` (100), `admin` (80), `user` (10); pagina's controleren permissies
- **Audit-log** (`audit_log`, JSON-context) met `admin/logs.php` (filter + paginering)
- **Argon2id** voor wachtwoorden (terugval op PHP-standaard), herhash bij login
- **Veilige redirect** na login (`?redirect=` alleen eigen paden)
- **Gebruikersbeheer**: zoeken, paginering, `user_edit.php` met rolregels (niet boven eigen niveau, geen hogere gebruikers bewerken, zelf-lockout, laatste super admin)
- **AES-256-GCM** helper (`includes/crypto.php`) voor AI-keys
- Schema: `is_active`, `email_verified_at`, `deleted_at`, `last_login_ip`, `display_name`
- Test-suite `tests/flow_test.py` (51 controles) en GitHub Actions-workflow
- Docs: `docs/AUTH.md`, `SECURITY.md`, `CONTRIBUTING.md`, issue- en PR-templates
- Wijziging: `install.php` maakt een `super_admin`; oude tabellen `system_logs` en `users.role/status` zijn vervangen (nog niet live geïnstalleerd, dus geen migratie)

## [0.1.0] — 2026-09-30 — Fase 0 + 1 (fundament)
- Naam-login zonder wachtwoord en OAuth-code verwijderd
- Veilige sessies, CSRF, rate-limit, captcha-hook, mail-helper
- Login, registratie met e-mailverificatie, eenmalige `install.php`
- `/admin/` en `/user/` skeleton, `cron/cleanup_task.php`
- `.htaccess` deny voor gevoelige mappen
