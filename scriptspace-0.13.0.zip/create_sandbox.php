<?php
// create_sandbox.php — formulier-endpoint (dashboard): maakt een tijdelijke sandbox (72 uur). De playground gebruikt api/sandbox.php.
declare(strict_types=1);
require_once __DIR__ . '/includes/sandbox.php';
$u = require_permission('sandbox.create');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_verify()) {
    http_response_code(405);
    exit('Gebruik het formulier op je dashboard.');
}
try {
    $sb = sandbox_create($u['id']);
} catch (RuntimeException $e) {
    http_response_code($e->getMessage() === 'quota' ? 429 : 500);
    exit($e->getMessage() === 'quota' ? 'Sandbox-limiet bereikt (3 actief).' : 'Kon sandbox niet aanmaken.');
}
redirect('playground.php?sandbox=' . urlencode($sb['slug']));
