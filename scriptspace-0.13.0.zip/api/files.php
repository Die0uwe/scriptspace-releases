<?php
// api/files.php — bestanden in een eigen sandbox.
//   GET  ?slug=sb_xxxxxxxx&action=list
//   GET  ?slug=...&action=read&name=index.html
//   POST {action: save|create|delete|rename, slug, name, content?, new_name?}
declare(strict_types=1);
require_once __DIR__ . '/../includes/api.php';
require_once __DIR__ . '/../includes/sandbox.php';

$u = api_user('sandbox.create');
$isPost = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';
$in = $isPost ? api_input() : $_GET;
if ($isPost) { api_require_post(); }

$slug   = (string)($in['slug'] ?? '');
$action = (string)($in['action'] ?? '');
$name   = (string)($in['name'] ?? '');

$php = php_exec_allowed((int)$u['id']);
$dir = sandbox_dir($slug, $u['id']);
if ($dir === null) { api_error('Sandbox niet gevonden of verlopen.', 404); }

function check_content(string $c): void
{
    if (strlen($c) > SB_MAX_BYTES) { api_error('Bestand te groot (max 200 KB).', 413); }
    if (!mb_check_encoding($c, 'UTF-8') || str_contains($c, "\0")) { api_error('Alleen UTF-8 tekst is toegestaan.', 415); }
}

if (!$isPost) {
    if ($action === 'list') { json_out(['files' => sandbox_files($dir, $php)]); }
    if ($action === 'read') {
        if (!sandbox_valid_name($name, $php) || !is_file($dir . '/' . sandbox_disk($name))) { api_error('Bestand niet gevonden.', 404); }
        json_out(['name' => $name, 'content' => (string)file_get_contents($dir . '/' . sandbox_disk($name))]);
    }
    api_error('Onbekende actie.', 400);
}

if (!sandbox_valid_name($name, $php)) { api_error('Ongeldige bestandsnaam. Toegestaan: letters, cijfers, - en _, met extensie ' . implode(', ', $php ? array_merge(SB_EXT, ['php']) : SB_EXT) . '.', 422); }
$path = $dir . '/' . sandbox_disk($name);

switch ($action) {
    case 'save':
    case 'create':
        $content = (string)($in['content'] ?? '');
        check_content($content);
        $exists = is_file($path);
        if ($action === 'create' && $exists) { api_error('Bestand bestaat al.', 409); }
        if ($action === 'save' && !$exists) { api_error('Bestand niet gevonden.', 404); }
        if (!$exists && count(sandbox_files($dir, $php)) >= SB_MAX_FILES) { api_error('Maximaal ' . SB_MAX_FILES . ' bestanden per sandbox.', 429); }
        sandbox_write($dir, $name, $content);
        audit('sandbox.file_' . $action, $u['id'], ['slug' => $slug, 'name' => $name, 'bytes' => strlen($content)]);
        json_out(['ok' => true, 'name' => $name], $action === 'create' ? 201 : 200);

    case 'delete':
        if (!is_file($path)) { api_error('Bestand niet gevonden.', 404); }
        unlink($path);
        audit('sandbox.file_delete', $u['id'], ['slug' => $slug, 'name' => $name]);
        json_out(['ok' => true]);

    case 'rename':
        $new = (string)($in['new_name'] ?? '');
        if (!sandbox_valid_name($new, $php)) { api_error('Ongeldige nieuwe bestandsnaam.', 422); }
        if (!is_file($path)) { api_error('Bestand niet gevonden.', 404); }
        if (is_file($dir . '/' . sandbox_disk($new))) { api_error('Doelbestand bestaat al.', 409); }
        rename($path, $dir . '/' . sandbox_disk($new));
        audit('sandbox.file_rename', $u['id'], ['slug' => $slug, 'from' => $name, 'to' => $new]);
        json_out(['ok' => true, 'name' => $new]);
}
api_error('Onbekende actie.', 400);
