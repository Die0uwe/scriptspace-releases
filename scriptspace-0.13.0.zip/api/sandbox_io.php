<?php
// api/sandbox_io.php — bestanden uit een sandbox halen en erin zetten, voor gebruik met je eigen editor (Notepad++, VS Code, ...).
//   GET  ?slug=sb_xxxxxxxx&download=zip            hele sandbox als ZIP
//   GET  ?slug=...&download=file&name=index.html   één bestand
//   POST multipart: slug + files[] (losse tekstbestanden en/of .zip-bestanden) -> importeert naar de sandbox (zelfde naam = overschrijven)
declare(strict_types=1);
require_once __DIR__ . '/../includes/api.php';
require_once __DIR__ . '/../includes/sandbox.php';

const IO_MAX_UPLOAD = 1048576;     // 1 MB per geüpload bestand (ZIP of los)
const IO_MAX_ENTRIES = 200;        // entries die we in een ZIP bekijken
const IO_MAX_TOTAL = 2097152;      // totaal uitgepakt (2 MB)
const IO_IMPORTS_PER_HOUR = 30;

$u = api_user('sandbox.create');
$php = php_exec_allowed((int)$u['id']);
$isPost = ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST';

// ---------- download ----------
if (!$isPost) {
    $slug = (string)($_GET['slug'] ?? '');
    $dir = sandbox_dir($slug, $u['id']);
    if ($dir === null) { api_error('Sandbox niet gevonden of verlopen.', 404); }
    $what = (string)($_GET['download'] ?? '');
    if ($what === 'file') {
        $name = (string)($_GET['name'] ?? '');
        $path = $dir . '/' . sandbox_disk($name);
        if (!sandbox_valid_name($name, $php) || !is_file($path)) { api_error('Bestand niet gevonden.', 404); }
        audit('sandbox.download', $u['id'], ['slug' => $slug, 'name' => $name]);
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('X-Content-Type-Options: nosniff');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }
    if ($what === 'zip') {
        if (!class_exists('ZipArchive')) { api_error('ZIP-ondersteuning ontbreekt op deze server (PHP-extensie zip).', 501); }
        $files = sandbox_files($dir, $php);
        if (!$files) { api_error('Deze sandbox heeft geen bestanden.', 404); }
        $tmp = tempnam(sys_get_temp_dir(), 'ssz');
        $zip = new ZipArchive();
        if ($tmp === false || $zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) { api_error('ZIP maken mislukt.', 500); }
        foreach ($files as $f) { $zip->addFile($dir . '/' . sandbox_disk($f['name']), $f['name']); }
        $zip->close();
        audit('sandbox.download', $u['id'], ['slug' => $slug, 'zip' => count($files)]);
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="sandbox-' . $slug . '.zip"');
        header('X-Content-Type-Options: nosniff');
        header('Content-Length: ' . filesize($tmp));
        readfile($tmp);
        @unlink($tmp);
        exit;
    }
    api_error('Onbekende download.', 400);
}

// ---------- upload ----------
api_require_post();
$slug = (string)($_POST['slug'] ?? '');
$dir = sandbox_dir($slug, $u['id']);
if ($dir === null) { api_error('Sandbox niet gevonden of verlopen.', 404); }

$st = db()->prepare("SELECT COUNT(*) FROM audit_log WHERE user_id = ? AND action = 'sandbox.import' AND created_at > (NOW() - INTERVAL 1 HOUR)");
$st->execute([$u['id']]);
if ((int)$st->fetchColumn() >= IO_IMPORTS_PER_HOUR) { api_error('Te veel uploads; probeer het over een uur opnieuw.', 429); }

// $_FILES['files'] (meervoud) normaliseren
$uploads = [];
if (isset($_FILES['files']) && is_array($_FILES['files']['name'])) {
    foreach ($_FILES['files']['name'] as $i => $n) {
        $uploads[] = ['name' => (string)$n, 'tmp' => (string)$_FILES['files']['tmp_name'][$i], 'size' => (int)$_FILES['files']['size'][$i], 'err' => (int)$_FILES['files']['error'][$i]];
    }
}
if (!$uploads) { api_error('Geen bestanden ontvangen.', 400); }
if (count($uploads) > SB_MAX_FILES) { api_error('Te veel bestanden in één keer.', 413); }

$existing = array_column(sandbox_files($dir, $php), 'name');
$imported = [];
$skipped = [];

/** Schrijft één bestand als het voldoet; houdt de bestandenlimiet bij. */
$put = function (string $rawName, string $content) use ($dir, $php, &$existing, &$imported, &$skipped): void {
    $name = basename(str_replace('\\', '/', $rawName));
    $name = str_replace(' ', '-', $name);
    if ($name === '' || $name[0] === '.') { return; } // verborgen bestanden (.DS_Store e.d.) stilletjes overslaan
    if (!sandbox_valid_name($name, $php)) { $skipped[] = ['name' => $name, 'reason' => 'naam of type niet toegestaan']; return; }
    if (strlen($content) > SB_MAX_BYTES) { $skipped[] = ['name' => $name, 'reason' => 'groter dan 200 KB']; return; }
    if (!mb_check_encoding($content, 'UTF-8') || str_contains($content, "\0")) { $skipped[] = ['name' => $name, 'reason' => 'geen UTF-8 tekst']; return; }
    $exists = in_array($name, $existing, true);
    if (!$exists && count($existing) >= SB_MAX_FILES) { $skipped[] = ['name' => $name, 'reason' => 'maximaal ' . SB_MAX_FILES . ' bestanden']; return; }
    sandbox_write($dir, $name, $content);
    if (!$exists) { $existing[] = $name; }
    $imported[] = $name;
};

foreach ($uploads as $up) {
    if ($up['err'] !== UPLOAD_ERR_OK || !is_uploaded_file($up['tmp'])) { $skipped[] = ['name' => $up['name'], 'reason' => 'upload mislukt']; continue; }
    if ($up['size'] > IO_MAX_UPLOAD) { $skipped[] = ['name' => $up['name'], 'reason' => 'groter dan 1 MB']; continue; }
    $head = (string)file_get_contents($up['tmp'], false, null, 0, 4);
    if (preg_match('/\.zip$/i', $up['name']) || $head === "PK\x03\x04") {
        if (!class_exists('ZipArchive')) { $skipped[] = ['name' => $up['name'], 'reason' => 'ZIP-ondersteuning ontbreekt op de server']; continue; }
        $zip = new ZipArchive();
        if ($zip->open($up['tmp'], ZipArchive::RDONLY) !== true) { $skipped[] = ['name' => $up['name'], 'reason' => 'geen geldig ZIP-bestand']; continue; }
        $total = 0;
        $n = min($zip->numFiles, IO_MAX_ENTRIES);
        for ($i = 0; $i < $n; $i++) {
            $stat = $zip->statIndex($i);
            if (!$stat || str_ends_with($stat['name'], '/') || str_starts_with($stat['name'], '__MACOSX/')) { continue; }
            $zip->getExternalAttributesIndex($i, $opsys, $attr);
            if ($opsys === ZipArchive::OPSYS_UNIX && (($attr >> 16) & 0170000) === 0120000) { continue; } // symlink
            $total += (int)$stat['size'];
            if ($total > IO_MAX_TOTAL) { $skipped[] = ['name' => $up['name'], 'reason' => 'ZIP is uitgepakt te groot (max 2 MB)']; break; }
            if ((int)$stat['size'] > SB_MAX_BYTES) { $skipped[] = ['name' => basename($stat['name']), 'reason' => 'groter dan 200 KB']; continue; }
            $data = $zip->getFromIndex($i, SB_MAX_BYTES + 1);
            if ($data === false) { continue; }
            $put($stat['name'], $data);
        }
        if ($zip->numFiles > IO_MAX_ENTRIES) { $skipped[] = ['name' => $up['name'], 'reason' => 'alleen de eerste ' . IO_MAX_ENTRIES . ' onderdelen bekeken']; }
        $zip->close();
    } else {
        $put($up['name'], (string)file_get_contents($up['tmp']));
    }
}
audit('sandbox.import', $u['id'], ['slug' => $slug, 'imported' => count($imported), 'skipped' => count($skipped)]);
json_out(['imported' => $imported, 'skipped' => $skipped]);

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : api/sandbox_io.php                                        ║
// ║  Role    : API                                                       ║
// ║  Version : 1.0.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Download (bestand/ZIP) en upload (bestanden/ZIP)          ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
