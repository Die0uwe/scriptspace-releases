<?php
// api/ai_keys.php — eigen AI-keys per provider, versleuteld opgeslagen (AES-256-GCM).
//   GET                       -> {providers: {deepseek: true|false, gemini: ...}}   (de key zelf wordt nooit teruggegeven)
//   POST {action:"save", provider, key}
//   POST {action:"delete", provider}
declare(strict_types=1);
require_once __DIR__ . '/../includes/api.php';
require_once __DIR__ . '/../includes/crypto.php';

const AI_PROVIDERS = ['deepseek', 'gemini'];
$u = api_user('ai.use');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $st = db()->prepare('SELECT provider FROM api_keys WHERE user_id = ?');
    $st->execute([$u['id']]);
    $have = array_column($st->fetchAll(), 'provider');
    $out = [];
    foreach (AI_PROVIDERS as $p) { $out[$p] = in_array($p, $have, true); }
    json_out(['providers' => $out, 'csrf' => csrf_token()]);
}

api_require_post();
$in = api_input();
$provider = (string)($in['provider'] ?? '');
if (!in_array($provider, AI_PROVIDERS, true)) { api_error('Onbekende provider.', 422); }

if (($in['action'] ?? '') === 'delete') {
    db()->prepare('DELETE FROM api_keys WHERE user_id = ? AND provider = ?')->execute([$u['id'], $provider]);
    audit('ai.key_delete', $u['id'], ['provider' => $provider]);
    json_out(['ok' => true]);
}

if (($in['action'] ?? '') === 'save') {
    $key = trim((string)($in['key'] ?? ''));
    if (strlen($key) < 8 || strlen($key) > 300 || preg_match('/\s/', $key) || !preg_match('/^[\x21-\x7e]+$/', $key)) {
        api_error('Ongeldige API-key.', 422);
    }
    try {
        $enc = crypto_encrypt($key);
    } catch (Throwable $e) {
        api_error('De server kan keys nog niet versleutelen (app_key ontbreekt in config.php).', 500);
    }
    db()->prepare('INSERT INTO api_keys (user_id, provider, key_enc) VALUES (?, ?, ?)
                   ON DUPLICATE KEY UPDATE key_enc = VALUES(key_enc), updated_at = NOW()')->execute([$u['id'], $provider, $enc]);
    audit('ai.key_save', $u['id'], ['provider' => $provider]);
    json_out(['ok' => true]);
}
api_error('Onbekende actie.', 400);
