<?php
// api/ai_chat.php — AI-proxy, antwoord in één keer (terugval voor als streaming niet werkt).
//   POST {prompt, model, file: {name, content}?, history: [{role: user|assistant, content}]?}
declare(strict_types=1);
require_once __DIR__ . '/../includes/ai.php';

$u = api_user('ai.use');
api_require_post();
$c = ai_prepare($u, api_input());
session_write_close(); // een lang AI-verzoek mag andere verzoeken van dezelfde gebruiker niet blokkeren
try {
    json_out(['reply' => ai_reply_blocking($c), 'model' => $c['model']]);
} catch (RuntimeException $e) {
    api_error($e->getMessage(), $e->getCode() >= 400 ? $e->getCode() : 502);
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : api/ai_chat.php                                           ║
// ║  Role    : API                                                       ║
// ║  Version : 0.8.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : AI-antwoord in één keer (terugval)                        ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
