<?php
// api/sandbox.php — GET: eigen sandboxes. POST {action:"create"}: nieuwe sandbox.
declare(strict_types=1);
require_once __DIR__ . '/../includes/api.php';
require_once __DIR__ . '/../includes/sandbox.php';

$u = api_user('sandbox.create');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    json_out(['sandboxes' => sandbox_list($u['id']), 'csrf' => csrf_token()]);
}

api_require_post();
try {
    json_out(['sandbox' => sandbox_create($u['id'])], 201);
} catch (RuntimeException $e) {
    if ($e->getMessage() === 'quota') { api_error('Sandbox-limiet bereikt (3 actief). Wacht tot er een verloopt.', 429); }
    api_error('Sandbox aanmaken mislukt.', 500);
}
