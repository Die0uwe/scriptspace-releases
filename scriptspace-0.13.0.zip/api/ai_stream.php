<?php
// api/ai_stream.php — AI-proxy met streaming (Server-Sent Events): het antwoord verschijnt terwijl het binnenkomt.
//   POST {prompt, model, file?, history?}
//   Fouten vóór de start: gewone JSON ({error}) met HTTP-status. Daarna een stroom van events:
//     event: delta  data: {"t":"tekst"}     event: think  data: {}     event: done  data: {"model":"..."}
//     event: error  data: {"error":"..."}
declare(strict_types=1);
require_once __DIR__ . '/../includes/ai.php';

$u = api_user('ai.use');
api_require_post();
$c = ai_prepare($u, api_input());
session_write_close(); // anders houdt deze lange aanvraag het sessiebestand vast en wacht elk ander verzoek van de gebruiker

// Geen buffering of compressie tussen PHP en de browser
while (ob_get_level() > 0) { @ob_end_clean(); }
@ini_set('zlib.output_compression', '0');
@ini_set('output_buffering', '0');
@ini_set('implicit_flush', '1');
if (function_exists('apache_setenv')) { @apache_setenv('no-gzip', '1'); }
@set_time_limit(180);
ignore_user_abort(false);
http_response_code(200);
header('Content-Type: text/event-stream; charset=utf-8');
header('Cache-Control: no-store, no-transform');
header('X-Accel-Buffering: no');
header('Connection: keep-alive');

function sse(string $event, array $data): void
{
    echo "event: $event\ndata: " . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n\n";
    @flush();
}
echo ':' . str_repeat(' ', 2048) . "\n\n"; // vult eventuele proxy-buffers
@flush();

$thinkSent = false;
try {
    ai_reply_stream(
        $c,
        function (string $t): void { sse('delta', ['t' => $t]); },
        function () use (&$thinkSent): void { if (!$thinkSent) { $thinkSent = true; sse('think', []); } },
        fn(): bool => connection_aborted() === 1
    );
    sse('done', ['model' => $c['model']]);
} catch (RuntimeException $e) {
    sse('error', ['error' => $e->getMessage()]);
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : api/ai_stream.php                                         ║
// ║  Role    : API                                                       ║
// ║  Version : 0.8.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : AI-antwoord als SSE-stroom                                ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
