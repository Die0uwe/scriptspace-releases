<?php
// api/php_run.php — voert een PHP-bestand uit een eigen sandbox uit (recht: php.execute).
//   POST {slug, file: "index.php", query?: "a=1&b=2"}  ->  {stdout, stderr, exit, timed_out, truncated, ms}
declare(strict_types=1);
require_once __DIR__ . '/../includes/api.php';
require_once __DIR__ . '/../includes/sandbox.php';
require_once __DIR__ . '/../includes/phprun.php';

const PHPRUN_PER_HOUR = 60;

$u = api_user('php.execute');
if (!php_exec_allowed((int)$u['id'])) { api_error('PHP uitvoeren is alleen voor super_admin.', 403); }
api_require_post();
$in = api_input();
$slug  = (string)($in['slug'] ?? '');
$file  = (string)($in['file'] ?? '');
$query = (string)($in['query'] ?? '');

$dir = sandbox_dir($slug, $u['id']);
if ($dir === null) { api_error('Sandbox niet gevonden of verlopen.', 404); }
if (!sandbox_valid_name($file, true) || !sandbox_is_php($file)) { api_error('Kies een geldig .php-bestand.', 422); }
if (!is_file($dir . '/' . sandbox_disk($file))) { api_error('Bestand niet gevonden.', 404); }
if (strlen($query) > 500) { api_error('Querystring te lang (max 500 tekens).', 413); }

$st = db()->prepare("SELECT COUNT(*) FROM audit_log WHERE user_id = ? AND action = 'php.run' AND created_at > (NOW() - INTERVAL 1 HOUR)");
$st->execute([$u['id']]);
if ((int)$st->fetchColumn() >= PHPRUN_PER_HOUR) { api_error('Limiet bereikt: maximaal ' . PHPRUN_PER_HOUR . ' PHP-runs per uur.', 429); }

phprun_gc();
session_write_close(); // een run van enkele seconden mag de sessie niet vasthouden
try {
    $r = phprun_sandbox($dir, $file, ltrim($query, '?'));
} catch (RuntimeException $e) {
    api_error($e->getMessage(), $e->getMessage() === 'Bestand niet gevonden.' ? 404 : 503);
}
audit('php.run', $u['id'], ['slug' => $slug, 'file' => $file, 'ms' => $r['ms'], 'exit' => $r['exit'], 'timed_out' => $r['timed_out']]);
json_out($r);

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : api/php_run.php                                           ║
// ║  Role    : API                                                       ║
// ║  Version : 0.7.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : PHP-run in afgeschermd proces, 60 per uur                 ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
