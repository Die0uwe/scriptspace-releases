<?php
// register.php — open registratie met e-mailverificatie, captcha en honeypot.
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/oauth.php';

if (current_user() !== null) { redirect('user/dashboard.php'); }

$errors = [];
$done = false;
$username = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $email    = strtolower(trim((string)($_POST['email'] ?? '')));
    $pass     = (string)($_POST['password'] ?? '');
    $pass2    = (string)($_POST['password2'] ?? '');

    if (!csrf_verify()) {
        $errors[] = 'Sessie verlopen, probeer opnieuw.';
    } elseif (!cfg('registration_open', true)) {
        $errors[] = 'Registreren is momenteel gesloten.';
    } elseif (!empty($_POST['website'])) {
        // honeypot: bots vullen dit veld in. Doen alsof het gelukt is.
        $done = true;
    } else {
        if (!preg_match('/^[A-Za-z0-9_]{3,24}$/', $username)) { $errors[] = 'Gebruikersnaam: 3–24 tekens, alleen letters, cijfers en _.'; }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) { $errors[] = 'Ongeldig e-mailadres.'; }
        if (mb_strlen($pass) < 10) { $errors[] = 'Wachtwoord moet minimaal 10 tekens zijn.'; }
        if (strlen($pass) > 200) { $errors[] = 'Wachtwoord is te lang.'; }
        if ($pass !== $pass2) { $errors[] = 'Wachtwoorden komen niet overeen.'; }
        if (!$errors && !captcha_ok()) { $errors[] = 'Captcha mislukt.'; }

        // Registraties per IP beperken (max 5 per uur)
        if (!$errors) {
            $st = db()->prepare("SELECT COUNT(*) FROM audit_log WHERE action = 'auth.register' AND ip_address = ? AND created_at > (NOW() - INTERVAL 1 HOUR)");
            $st->execute([client_ip()]);
            if ((int)$st->fetchColumn() >= 5) { $errors[] = 'Te veel registraties vanaf dit adres. Probeer het later opnieuw.'; }
        }

        if (!$errors) {
            $st = db()->prepare('SELECT id FROM users WHERE username = ?');
            $st->execute([$username]);
            if ($st->fetch()) {
                $errors[] = 'Deze gebruikersnaam is al bezet.';
            } else {
                $st = db()->prepare('SELECT id FROM users WHERE email = ?');
                $st->execute([$email]);
                $existing = $st->fetch();
                if ($existing) {
                    // Geen verklikker of het adres bestaat: dezelfde melding, maar de eigenaar krijgt een seintje.
                    send_mail($email, 'Registratie scriptspace.nl', "Iemand probeerde met dit e-mailadres een account te maken, maar je hebt al een account.\nLog in via " . cfg('app_url') . "/login.php\n");
                    audit('auth.register_duplicate_email', (int)$existing['id']);
                    $done = true;
                } else {
                    $token = bin2hex(random_bytes(32));
                    db()->prepare("INSERT INTO users (username, email, password_hash, display_name, verify_token_hash, verify_expires)
                                   VALUES (?, ?, ?, ?, ?, NOW() + INTERVAL 24 HOUR)")
                        ->execute([$username, $email, hash_password($pass), $username, hash('sha256', $token)]);
                    $uid = (int)db()->lastInsertId();
                    assign_default_role($uid);
                    audit('auth.register', $uid);
                    send_mail($email, 'Bevestig je account op scriptspace.nl',
                        "Hoi $username,\n\nBevestig je e-mailadres (24 uur geldig):\n" . cfg('app_url') . "/verify.php?t=$token\n\nHeb jij dit niet aangevraagd? Dan kun je deze mail negeren.\n");
                    $done = true;
                }
            }
        }
    }
}

page_header('Registreren');
?>
<div class="card narrow">
  <h1>Registreren</h1>
  <?php if ($done): ?>
    <div class="msg ok">Bijna klaar. Controleer je mail en klik op de bevestigingslink om je account te activeren.</div>
  <?php else: ?>
    <?php foreach ($errors as $err): ?><div class="msg err"><?= e($err) ?></div><?php endforeach; ?>
    <form method="post" autocomplete="off">
      <?= csrf_field() ?>
      <div class="hp" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
      <label for="username">Gebruikersnaam</label>
      <input type="text" id="username" name="username" value="<?= e($username) ?>" required>
      <label for="email">E-mail</label>
      <input type="email" id="email" name="email" value="<?= e($email) ?>" required>
      <label for="password">Wachtwoord (min. 10 tekens)</label>
      <input type="password" id="password" name="password" required>
      <label for="password2">Herhaal wachtwoord</label>
      <input type="password" id="password2" name="password2" required>
      <?= captcha_widget() ?>
      <button type="submit">Account maken</button>
    </form>
    <?= oauth_buttons() ?>
    <p class="muted">Al een account? <a href="login.php" style="color:#8b5cf6">Inloggen</a></p>
  <?php endif; ?>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : register.php                                              ║
// ║  Role    : Auth                                                      ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Open registratie met e-mailverificatie, honeypot, captcha ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
