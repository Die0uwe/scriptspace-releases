<?php
// admin/updates.php — versie, updatecontrole en databasemigraties (recht: system.update, standaard alleen super_admin).
// 0.12.0: controleren en migraties. 0.13.0: installeren (ondertekend), vorige versie terugzetten.
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/updater.php';
require_once __DIR__ . '/../includes/migrate.php';
require_once __DIR__ . '/../includes/update_install.php';
$me = require_permission('system.update', '../');

$flash = null; $report = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    if (!csrf_verify()) {
        $flash = ['err', 'Sessie verlopen. Probeer het opnieuw.'];
    } elseif ($action === 'check') {
        $st = update_state();
        if ((int)($st['checked_at'] ?? 0) > time() - 60) {
            $flash = ['err', 'Wacht een minuutje met opnieuw controleren (GitHub begrenst aanvragen).'];
        } else {
            $st = update_check();
            audit('system.update_check', (int)$me['id'], ['latest' => $st['latest'] ?? null, 'error' => $st['error'] ?? '']);
            $flash = ($st['error'] ?? '') !== '' ? ['err', $st['error']] : ['ok', !empty($st['available']) ? 'Er is een nieuwe versie: ' . $st['latest'] . '.' : 'Je hebt de nieuwste versie.'];
        }
    } elseif ($action === 'migrate') {
        try {
            $done = migrate_run(null, (int)$me['id']);
            $flash = ['ok', $done ? count($done) . ' migratie(s) uitgevoerd: ' . implode(', ', $done) . '.' : 'Er was niets uit te voeren.'];
        } catch (Throwable $e) {
            $flash = ['err', $e->getMessage()];
        }
    } elseif ($action === 'install' || $action === 'rollback') {
        $pwOk = true;
        $u = db()->prepare('SELECT password_hash, password_set FROM users WHERE id = ?');
        $u->execute([$me['id']]);
        $ur = $u->fetch() ?: [];
        if ((int)($ur['password_set'] ?? 0) === 1 && !password_verify((string)($_POST['current'] ?? ''), (string)($ur['password_hash'] ?? ''))) { $pwOk = false; }
        $stNow = update_state();
        if (!$pwOk) {
            $flash = ['err', 'Wachtwoord klopt niet.'];
        } elseif (!cfg('updater', false)) {
            $flash = ['err', "De updater staat uit. Zet in config.php: 'updater' => true."];
        } elseif ($action === 'install') {
            if (empty($stNow['available']) || empty($stNow['assets'])) {
                $flash = ['err', 'Er is geen nieuwe release om te installeren. Controleer eerst op updates.'];
            } else {
                audit('system.update_start', (int)$me['id'], ['to' => $stNow['latest'] ?? null]);
                $report = update_install(['release' => ['version' => (string)$stNow['latest'], 'assets' => $stNow['assets']], 'by' => (int)$me['id']]);
                audit($report['ok'] ? 'system.update_done' : 'system.update_failed', (int)$me['id'], ['from' => $report['from'], 'to' => $report['to'], 'error' => $report['error'], 'rolled_back' => $report['rolled_back']]);
                if ($report['ok']) { update_check(); }
                $flash = $report['ok'] ? ['ok', 'Versie ' . $report['to'] . ' is geïnstalleerd.'] : ['err', 'Update mislukt: ' . $report['error']];
            }
        } else {
            $rb = update_rollback_last();
            audit($rb['ok'] ? 'system.update_rollback' : 'system.update_rollback_failed', (int)$me['id'], $rb);
            $flash = $rb['ok'] ? ['ok', 'Vorige versie (' . $rb['to'] . ') is teruggezet, ' . $rb['files'] . ' bestanden.'] : ['err', (string)$rb['error']];
        }
    } else {
        $flash = ['err', 'Onbekende actie.'];
    }
}

$st = update_state();
$pending = []; $changed = []; $applied = 0; $dberr = '';
try { $pending = migrate_pending(); $changed = migrate_changed(); $applied = count(migrate_applied()); } catch (Throwable $e) { $dberr = 'Migratiestatus niet te lezen (databasefout).'; }
$checkOn = (bool)cfg('update_check', true);
$updOn = (bool)cfg('updater', false);
$pre = update_preflight();
$preOk = true; foreach ($pre as $r) { if (!$r[1] && !str_contains($r[0], 'schijfruimte')) { $preOk = false; } }
$hasSnap = is_file(SS_ROOT . '/storage/update/last_rollback/meta.json');
$needPw = false;
try { $q = db()->prepare('SELECT password_set FROM users WHERE id = ?'); $q->execute([$me['id']]); $needPw = (int)$q->fetchColumn() === 1; } catch (Throwable $e) {}

page_header('Updates', '../');
?>
<div class="card">
  <h1>Updates</h1>
  <?php if ($flash): ?><div class="msg <?= e($flash[0]) ?>"><?= e($flash[1]) ?></div><?php endif; ?>
  <table>
    <tr><th>Geïnstalleerde versie</th><td><strong><?= e(ss_version()) ?></strong></td></tr>
    <tr><th>Nieuwste release</th><td><?php if (!empty($st['latest'])): ?>
        <strong><?= e((string)$st['latest']) ?></strong><?= !empty($st['published']) ? ' · ' . e((string)$st['published']) : '' ?>
        <?= !empty($st['available']) ? ' — <strong>nieuwe versie beschikbaar</strong>' : ' — je bent bij' ?>
        <?php if (!empty($st['url'])): ?> · <a href="<?= e((string)$st['url']) ?>" target="_blank" rel="noopener noreferrer">release-notities</a><?php endif; ?>
      <?php else: ?>onbekend<?php endif; ?></td></tr>
    <tr><th>Laatst gecontroleerd</th><td><?= !empty($st['checked_at']) ? e(date('Y-m-d H:i', (int)$st['checked_at'])) : 'nog nooit' ?><?= ($st['error'] ?? '') !== '' ? ' · <span class="muted">' . e((string)$st['error']) . '</span>' : '' ?></td></tr>
    <tr><th>Automatisch controleren</th><td><?= $checkOn ? 'aan (elke ' . UPDATE_CACHE_HOURS . ' uur, bron: ' . e(update_repo()) . ')' : 'uit (<code>update_check</code> in config.php)' ?></td></tr>
  </table>
  <?php if (!empty($st['available']) && !empty($st['notes'])): ?><pre style="white-space:pre-wrap;margin-top:12px"><?= e((string)$st['notes']) ?></pre><?php endif; ?>
  <form method="post" style="margin-top:12px"><?= csrf_field() ?><input type="hidden" name="action" value="check"><button type="submit">Nu controleren</button></form>
</div>

<div class="card">
  <h2>Update installeren</h2>
  <?php if ($report): ?>
    <pre style="white-space:pre-wrap"><?= e(implode("\n", $report['log'])) ?></pre>
  <?php endif; ?>
  <table>
    <?php foreach ($pre as [$label, $okp, $hint]): ?>
      <tr><td><?= $okp ? '✅' : '❌' ?> <?= e($label) ?></td><td class="muted"><?= $okp ? '' : e($hint) ?></td></tr>
    <?php endforeach; ?>
  </table>
  <p class="muted">Elke update is digitaal ondertekend en wordt gecontroleerd vóór er iets verandert. Vooraf wordt een database-back-up gemaakt; tijdens het vervangen staat de site kort in onderhoudsmodus; mislukt er iets, dan wordt automatisch teruggezet. <code>config/</code>, <code>storage/</code> en <code>sandboxes/</code> blijven altijd ongemoeid.</p>
  <?php if (!empty($st['available']) && !empty($st['assets'])): ?>
    <form method="post" onsubmit="return confirm('Update installeren? De site staat even in onderhoudsmodus.');"><?= csrf_field() ?><input type="hidden" name="action" value="install">
      <?php if ($needPw): ?><label for="pw1">Bevestig met je wachtwoord</label><input id="pw1" type="password" name="current" autocomplete="current-password" required><?php endif; ?>
      <button type="submit" <?= ($updOn && $preOk) ? '' : 'disabled' ?>>Installeer <?= e((string)$st['latest']) ?></button>
    </form>
  <?php elseif (!empty($st['available'])): ?>
    <p class="muted">De nieuwste release heeft geen installeerbare onderdelen (manifest, handtekening en zip).</p>
  <?php else: ?>
    <p class="muted">Er is nu geen nieuwere versie om te installeren.</p>
  <?php endif; ?>
  <?php if ($hasSnap): ?>
    <h3>Vorige versie terugzetten</h3>
    <p class="muted">Zet de bestanden terug zoals ze vóór de laatste update waren. De database wordt niet teruggezet; gebruik daarvoor de back-up in Admin, Back-up.</p>
    <form method="post" onsubmit="return confirm('Vorige versie terugzetten?');"><?= csrf_field() ?><input type="hidden" name="action" value="rollback">
      <?php if ($needPw): ?><label for="pw2">Bevestig met je wachtwoord</label><input id="pw2" type="password" name="current" autocomplete="current-password" required><?php endif; ?>
      <button type="submit" <?= $updOn ? '' : 'disabled' ?>>Vorige versie terugzetten</button>
    </form>
  <?php endif; ?>
</div>

<div class="card">
  <h2>Databasemigraties</h2>
  <?php if ($dberr): ?><div class="msg err"><?= e($dberr) ?></div><?php else: ?>
  <p><?= $applied ?> toegepast · <strong><?= count($pending) ?></strong> in afwachting.</p>
  <?php if ($pending): ?>
    <ul><?php foreach ($pending as $n): ?><li><code><?= e($n) ?></code></li><?php endforeach; ?></ul>
    <p class="muted">Maak eerst een back-up (Admin, Back-up). Een migratie stopt bij de eerste echte fout en wordt dan niet als gedaan vastgelegd.</p>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="migrate"><button type="submit">Migraties uitvoeren</button></form>
  <?php endif; ?>
  <?php if ($changed): ?><div class="msg err">Let op: deze al toegepaste migratie(s) zijn daarna gewijzigd: <?= e(implode(', ', $changed)) ?>. Ze worden niet opnieuw uitgevoerd.</div><?php endif; ?>
  <?php endif; ?>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : admin/updates.php                                         ║
// ║  Role    : Admin                                                     ║
// ║  Version : 0.13.0                                                    ║
// ║  Updated : 2026-10-01                                                ║
// ║  Notes   : Controle, installeren, rollback                         ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
