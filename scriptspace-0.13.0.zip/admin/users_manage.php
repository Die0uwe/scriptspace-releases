<?php
// admin/users_manage.php — gebruikerslijst met zoeken en paginering (recht: users.manage).
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/socials.php';
$me = require_permission('users.manage', '../');

const PER_PAGE = 20;
$page   = max(1, (int)($_GET['page'] ?? 1));
$search = trim((string)($_GET['q'] ?? ''));
$where  = 'deleted_at IS NULL';
$params = [];
if ($search !== '') {
    $where .= ' AND (username LIKE ? OR email LIKE ?)';
    $like = '%' . addcslashes($search, '%_\\') . '%';
    $params = [$like, $like];
}
$st = db()->prepare("SELECT COUNT(*) FROM users WHERE $where");
$st->execute($params);
$total = (int)$st->fetchColumn();
$pages = max(1, (int)ceil($total / PER_PAGE));
$page  = min($page, $pages);

$st = db()->prepare("SELECT id, username, email, is_active, email_verified_at, last_login_at FROM users WHERE $where ORDER BY id DESC LIMIT " . PER_PAGE . ' OFFSET ' . (($page - 1) * PER_PAGE));
$st->execute($params);
$users = $st->fetchAll();
// Koppelingen van alle getoonde gebruikers in twee queries (geen N+1)
$ids = array_map(fn($x) => (int)$x['id'], $users);
$byIdent = $byLink = [];
if ($ids) {
    $in = implode(',', $ids);
    foreach (db()->query("SELECT user_id, provider FROM oauth_identities WHERE user_id IN ($in)")->fetchAll() as $r) { $byIdent[(int)$r['user_id']][$r['provider']] = 1; }
    foreach (db()->query("SELECT user_id, service FROM social_links WHERE user_id IN ($in)")->fetchAll() as $r) { $byLink[(int)$r['user_id']][$r['service']] = 1; }
}

page_header('Gebruikers', '../');
?>
<div class="card">
  <h1>Gebruikers</h1>
  <?php if (!empty($_GET['ok'])): ?><div class="msg ok">Bijgewerkt.</div><?php endif; ?>
  <form method="get" class="row"><input type="text" name="q" value="<?= e($search) ?>" placeholder="Zoek op naam of e-mail"><button type="submit" style="margin:0">Zoek</button></form>
  <table style="margin-top:16px">
    <tr><th>ID</th><th>Naam</th><th>E-mail</th><th>Rollen</th><th>Status</th><th>Gekoppeld</th><th>Laatste login</th><th></th></tr>
    <?php foreach ($users as $u): ?>
      <tr>
        <td><?= (int)$u['id'] ?></td><td><?= e($u['username']) ?></td><td class="brk"><?= e($u['email']) ?></td>
        <td style="white-space:nowrap"><?= e(implode(', ', array_column(user_roles((int)$u['id']), 'name'))) ?></td>
        <td><?= !(int)$u['is_active'] ? 'gedeactiveerd' : ($u['email_verified_at'] === null ? 'niet geverifieerd' : 'actief') ?></td>
        <td><?= provider_chips($byIdent[(int)$u['id']] ?? [], $byLink[(int)$u['id']] ?? []) ?></td>
        <td><?= e($u['last_login_at'] ?? '-') ?></td>
        <td><a class="btn ghost" style="margin:0;padding:4px 10px" href="user_edit.php?id=<?= (int)$u['id'] ?>">Bewerk</a></td>
      </tr>
    <?php endforeach; ?>
  </table>
  <p class="muted">Pagina <?= $page ?> van <?= $pages ?> · <?= $total ?> gebruikers
    <?php if ($page > 1): ?> · <a href="?q=<?= urlencode($search) ?>&page=<?= $page - 1 ?>">vorige</a><?php endif; ?>
    <?php if ($page < $pages): ?> · <a href="?q=<?= urlencode($search) ?>&page=<?= $page + 1 ?>">volgende</a><?php endif; ?>
  </p>
  <a class="btn ghost" href="index.php">Terug</a>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : admin/users_manage.php                                    ║
// ║  Role    : Admin                                                     ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Gebruikerslijst met zoeken en paginering                  ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
