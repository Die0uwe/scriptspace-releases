<?php
// admin/connections.php — testpaneel voor verbindingen (recht: system.test, standaard alleen super_admin).
// Test e-mail, Discord-webhook, database, opslag en bereikbaarheid van externe diensten. Toont nooit geheimen.
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/connections.php';
$me = require_permission('system.test', '../');
$st = db()->prepare('SELECT email FROM users WHERE id = ?');
$st->execute([$me['id']]);
$myEmail = (string)$st->fetchColumn();

$result = null;   // [titel, ['ok'=>, 'detail'=>]]
$flash = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    $st = db()->prepare("SELECT COUNT(*) FROM audit_log WHERE user_id = ? AND action = 'conn.test' AND created_at > (NOW() - INTERVAL 1 HOUR)");
    $st->execute([$me['id']]);
    if (!csrf_verify()) {
        $flash = ['err', 'Sessie verlopen. Probeer het opnieuw.'];
    } elseif ((int)$st->fetchColumn() >= CONN_TESTS_PER_HOUR) {
        $flash = ['err', 'Je hebt het maximum van ' . CONN_TESTS_PER_HOUR . ' tests per uur bereikt.'];
    } else {
        $hosts = ['github' => 'https://api.github.com/', 'google' => 'https://accounts.google.com/', 'facebook' => 'https://graph.facebook.com/', 'discord' => 'https://discord.com/api/v10/gateway'];
        switch ($action) {
            case 'mail':
                $to = trim((string)($_POST['to'] ?? '')) ?: $myEmail;
                $result = ['E-mail naar ' . $to, conn_test_mail($to)];
                break;
            case 'discord':
                $result = ['Discord-webhook', conn_test_discord(trim((string)($_POST['webhook'] ?? '')))];
                break;
            case 'database':
                $result = ['Database', conn_test_database()];
                break;
            case 'storage':
                $result = ['Opslag', conn_test_storage()];
                break;
            case 'reach':
                $k = (string)($_POST['target'] ?? '');
                if (!isset($hosts[$k])) { $flash = ['err', 'Onbekend doel.']; break; }
                $result = ['Bereikbaarheid ' . $k, conn_test_reach($hosts[$k])];
                break;
            default:
                $flash = ['err', 'Onbekende test.'];
        }
        if ($result) {
            audit('conn.test', (int)$me['id'], ['test' => $action, 'ok' => $result[1]['ok']]);
        }
    }
}

$mailMode = cfg('mail_debug', false) ? 'debug (naar storage/mail.log)' : (is_array(cfg('smtp', [])) && !empty(cfg('smtp', [])['host']) ? 'SMTP via ' . cfg('smtp')['host'] . ':' . (int)(cfg('smtp')['port'] ?? 465) : 'PHP mail()');
$hook = conn_discord_configured();
$oauth = conn_oauth_overview();

page_header('Verbindingen testen', '../');
?>
<div class="card">
  <h1>Verbindingen testen</h1>
  <p class="muted">Controleer of e-mail, Discord, de database en externe diensten werken. Geheimen worden nooit getoond. Maximaal <?= CONN_TESTS_PER_HOUR ?> tests per uur; elke test staat in het audit-log.</p>
  <?php if ($flash): ?><div class="msg <?= e($flash[0]) ?>"><?= e($flash[1]) ?></div><?php endif; ?>
  <?php if ($result): ?><div class="msg <?= $result[1]['ok'] ? 'ok' : 'err' ?>" id="result"><strong><?= $result[1]['ok'] ? '✅' : '❌' ?> <?= e($result[0]) ?></strong><br><?= e($result[1]['detail']) ?></div><?php endif; ?>
</div>

<div class="card">
  <h2>E-mail</h2>
  <p class="muted">Verzendmethode nu: <strong><?= e($mailMode) ?></strong> · afzender: <?= e((string)cfg('mail_from', '')) ?></p>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="mail">
    <label for="to">Testmail sturen naar</label>
    <input id="to" type="email" name="to" value="<?= e($myEmail) ?>" maxlength="190" autocomplete="off">
    <button type="submit">Testmail versturen</button>
  </form>
</div>

<div class="card">
  <h2>Discord-webhook</h2>
  <p class="muted">Ingesteld in config.php: <strong><?= $hook !== '' ? e(conn_mask_webhook($hook)) : 'nee' ?></strong> (<code>'discord_webhook' =&gt; 'https://discord.com/api/webhooks/…'</code>).
     Je kunt hieronder ook een andere webhook plakken om te proberen; die wordt niet opgeslagen.</p>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="discord">
    <label for="webhook">Andere webhook-URL (optioneel)</label>
    <input id="webhook" type="password" name="webhook" value="" maxlength="300" autocomplete="off" spellcheck="false" placeholder="leeg = die uit config.php">
    <button type="submit">Testbericht naar Discord sturen</button>
  </form>
</div>

<div class="card">
  <h2>Systeem</h2>
  <table>
    <tr><th>Database</th><td><form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="database"><button type="submit">Testen</button></form></td></tr>
    <tr><th>Opslagmappen (storage, sandboxes)</th><td><form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="storage"><button type="submit">Testen</button></form></td></tr>
    <tr><th>PHP</th><td><?= e(PHP_VERSION) ?> · curl: <?= function_exists('curl_init') ? 'ja' : 'nee' ?> · openssl: <?= extension_loaded('openssl') ? 'ja' : 'nee' ?> · tijdzone: <?= e(date_default_timezone_get()) ?></td></tr>
  </table>
</div>

<div class="card">
  <h2>Inloggen met GitHub, Google, Discord, Facebook</h2>
  <p class="muted">Een provider is "ingesteld" als client-id en secret in config.php staan. Zet bij de provider precies de getoonde redirect-URL.</p>
  <table>
    <tr><th>Provider</th><th>Status</th><th>Redirect-URL bij de provider</th><th>Bereikbaar?</th></tr>
    <?php foreach ($oauth as $o): ?>
      <tr>
        <td><?= e($o['label']) ?></td>
        <td><?= $o['on'] ? '✅ ingesteld' : ($o['partial'] ? '⚠️ onvolledig' : '— niet ingesteld') ?></td>
        <td><small><code><?= e($o['redirect']) ?></code></small></td>
        <td><form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="reach"><input type="hidden" name="target" value="<?= e($o['name']) ?>"><button type="submit">Testen</button></form></td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : admin/connections.php                                     ║
// ║  Role    : Admin                                                     ║
// ║  Version : 0.11.0                                                    ║
// ║  Updated : 2026-10-01                                                ║
// ║  Notes   : Testpaneel verbindingen (mail, Discord, DB, OAuth)        ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
