<?php
// admin/system_cleanup.php — handmatig opschonen (recht: cleanup.run). Zelfde logica als cron/cleanup_task.php.
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/maintenance.php';
$me = require_permission('cleanup.run', '../');

$flash = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $flash = ['err', 'Sessie verlopen. Probeer het opnieuw.'];
    } else {
        $r = cleanup_run((int)$me['id']);
        $flash = ['ok', sprintf('Klaar: %d verlopen sandbox(es), %d losse map(pen), %d oude inlogpogingen, %d oude logregels en %d niet-bevestigde account(s) verwijderd.',
            $r['sandboxes_deleted'], $r['orphans_deleted'], $r['attempts_deleted'], $r['audit_deleted'], $r['unverified_deleted'])];
    }
}
$p = cleanup_preview();
$cronSet = (string)cfg('cron_token', '') !== '' && !str_starts_with((string)cfg('cron_token', ''), 'VERZIN_');

page_header('Opschonen', '../');
?>
<div class="card">
  <h1>Opschonen</h1>
  <?php if ($flash): ?><div class="msg <?= e($flash[0]) ?>"><?= e($flash[1]) ?></div><?php endif; ?>
  <table>
    <tr><th>Onderdeel</th><th>Nu opruimbaar</th></tr>
    <tr><td>Verlopen sandboxes (map + database)</td><td><?= $p['sandboxes_expired'] ?></td></tr>
    <tr><td>Losse sandbox-mappen zonder database-rij</td><td><?= $p['orphans'] ?></td></tr>
    <tr><td>Inlogpogingen ouder dan 1 dag</td><td><?= $p['attempts_old'] ?></td></tr>
    <tr><td>Niet-bevestigde accounts ouder dan <?= BK_UNVERIFIED_DAYS ?> dagen</td><td><?= $p['unverified_old'] ?></td></tr>
  </table>
  <p class="muted">Actieve sandboxes: <?= $p['sandboxes_active'] ?> · schijfgebruik sandboxes: <?= e(human_bytes($p['sandbox_bytes'])) ?></p>
  <form method="post"><?= csrf_field() ?><button type="submit">Nu opschonen</button> <a class="btn ghost" href="index.php">Terug</a></form>
</div>
<div class="card">
  <h2>Automatisch opschonen</h2>
  <?php
    $hrs = auto_cleanup_hours();
    $stampFile = SS_ROOT . '/storage/cleanup.stamp';
    $lastRun = is_file($stampFile) ? (int)filemtime($stampFile) : 0;
  ?>
  <p class="muted">STRATO-cron is niet nodig: het CMS ruimt zelf op, hoogstens elke <?= $hrs ?> uur, op de achtergrond na een gewone paginaweergave.
  <?= $hrs === 0 ? '<b>Staat nu uit</b> (<code>auto_cleanup_hours</code> in config is 0).' : 'Laatste automatische ronde: ' . ($lastRun ? e(date('d-m-Y H:i', $lastRun)) : 'nog niet gedraaid') . '.' ?>
  Interval aanpassen kan met <code>'auto_cleanup_hours'</code> in <code>config/config.php</code>; 0 zet het uit.</p>
  <p class="muted">Een externe cron-dienst (bijv. cron-job.org) kan ook: laat die <code>cron/cleanup_task.php</code> openen met de header <code>X-Cron-Token</code>.
  Cron-token in config: <?= $cronSet ? 'ingesteld ✓' : 'nog niet ingesteld (cron-URL is geblokkeerd)' ?></p>
</div>
<?php page_footer();
