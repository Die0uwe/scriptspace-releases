<?php
// admin/backup_manage.php — back-up maken/downloaden/verwijderen (recht: backup.manage); herstel alleen voor super_admin.
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/rbac.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/maintenance.php';
$me = require_permission('backup.manage', '../');
$isSuper = user_has_role((int)$me['id'], 'super_admin');

// Download (alleen lezen, sessie + permissie vereist)
if (isset($_GET['download'])) {
    $path = backup_path((string)$_GET['download']);
    if ($path === null) { http_response_code(404); exit('Niet gevonden.'); }
    audit('backup.download', (int)$me['id'], ['file' => basename($path)]);
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . basename($path) . '"');
    header('Content-Length: ' . filesize($path));
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}

function flash_set(string $t, string $m): void { $_SESSION['flash'] = [$t, $m]; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = (string)($_POST['action'] ?? '');
    try {
        if (!csrf_verify()) { throw new RuntimeException('Sessie verlopen. Probeer het opnieuw.'); }
        if ($act === 'create') {
            $n = backup_create((string)($_POST['type'] ?? 'full'), (int)$me['id']);
            flash_set('ok', 'Back-up gemaakt: ' . $n);
        } elseif ($act === 'delete') {
            $path = backup_path((string)($_POST['name'] ?? ''));
            if ($path === null) { throw new RuntimeException('Back-up niet gevonden.'); }
            unlink($path);
            audit('backup.delete', (int)$me['id'], ['file' => basename($path)]);
            flash_set('ok', 'Back-up verwijderd.');
        } elseif ($act === 'upload') {
            $f = $_FILES['zip'] ?? null;
            if (!$f || $f['error'] !== UPLOAD_ERR_OK || $f['size'] > 200 * 1024 * 1024) { throw new RuntimeException('Upload mislukt of te groot (max 200 MB).'); }
            $z = new ZipArchive();
            if ($z->open($f['tmp_name']) !== true || $z->locateName('manifest.json') === false) { throw new RuntimeException('Dit is geen ScriptSpace-back-up (manifest.json ontbreekt).'); }
            $m = json_decode((string)$z->getFromName('manifest.json'), true);
            $z->close();
            if (!is_array($m) || ($m['app'] ?? '') !== 'scriptspace-cms' || !in_array($m['type'] ?? '', ['full', 'db', 'files'], true)) { throw new RuntimeException('Ongeldige manifest in back-up.'); }
            $name = 'backup_' . date('Ymd_His') . '_' . $m['type'] . '_' . bin2hex(random_bytes(3)) . '.zip';
            if (!move_uploaded_file($f['tmp_name'], backup_dir() . '/' . $name)) { throw new RuntimeException('Opslaan mislukt.'); }
            audit('backup.upload', (int)$me['id'], ['file' => $name]);
            flash_set('ok', 'Back-up geüpload als ' . $name);
        } elseif ($act === 'restore') {
            if (!$isSuper) { throw new RuntimeException('Herstellen mag alleen een super admin.'); }
            $st = db()->prepare('SELECT password_hash FROM users WHERE id = ?');
            $st->execute([$me['id']]);
            if (!password_verify((string)($_POST['password'] ?? ''), (string)$st->fetchColumn())) { audit('backup.restore_denied', (int)$me['id'], []); throw new RuntimeException('Wachtwoord klopt niet.'); }
            if (trim((string)($_POST['confirm'] ?? '')) !== 'HERSTEL') { throw new RuntimeException('Typ HERSTEL om te bevestigen.'); }
            $what = ['db' => !empty($_POST['r_db']), 'files' => !empty($_POST['r_files'])];
            if (!$what['db'] && !$what['files']) { throw new RuntimeException('Kies wat je wilt herstellen.'); }
            $r = backup_restore((string)($_POST['name'] ?? ''), $what, (int)$me['id']);
            flash_set('ok', sprintf('Herstel klaar: %d databaseregels, %d bestanden. Noodback-up van de vorige toestand: %s', $r['statements'], $r['files'], $r['safety']));
        } else {
            throw new RuntimeException('Onbekende actie.');
        }
    } catch (Throwable $e) {
        flash_set('err', $e->getMessage());
    }
    redirect('backup_manage.php');
}

$flash = $_SESSION['flash'] ?? null; unset($_SESSION['flash']);
$list = backup_list();
$labels = ['full' => 'Volledig', 'db' => 'Alleen database', 'files' => 'Alleen bestanden'];
page_header('Back-up', '../');
?>
<div class="card">
  <h1>Back-up</h1>
  <?php if ($flash): ?><div class="msg <?= e($flash[0]) ?>"><?= e($flash[1]) ?></div><?php endif; ?>
  <p class="muted">Een back-up is een ZIP met <code>database.sql</code> en de projectbestanden. <strong>Niet</strong> inbegrepen: <code>config/config.php</code> (geheimen), <code>storage/</code> en tijdelijke sandboxes. De database bevat wachtwoord-hashes en versleutelde AI-keys; bewaar downloads dus veilig. We bewaren de nieuwste <?= max(1, (int)cfg('backup_keep', 10)) ?> back-ups op de server.</p>
  <form method="post" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><?= csrf_field() ?>
    <input type="hidden" name="action" value="create">
    <select name="type" style="padding:10px;background:#000;color:#fff;border:1px solid var(--border);border-radius:8px">
      <?php foreach ($labels as $k => $l): ?><option value="<?= e($k) ?>"><?= e($l) ?></option><?php endforeach; ?>
    </select>
    <button type="submit" style="margin:0">Back-up maken</button>
  </form>
</div>

<div class="card">
  <h2>Beschikbare back-ups</h2>
  <?php if (!$list): ?><p class="muted">Nog geen back-ups.</p><?php else: ?>
  <table>
    <tr><th>Bestand</th><th>Type</th><th>Grootte</th><th>Gemaakt</th><th></th></tr>
    <?php foreach ($list as $b): ?>
      <tr>
        <td><small><?= e($b['name']) ?></small></td><td><?= e($labels[$b['type']]) ?></td><td><?= e(human_bytes($b['size'])) ?></td><td><?= e(date('d-m-Y H:i', $b['time'])) ?></td>
        <td style="white-space:nowrap">
          <a class="btn ghost" style="margin:0" href="?download=<?= e(urlencode($b['name'])) ?>">Download</a>
          <form method="post" style="display:inline" onsubmit="return confirm('Deze back-up verwijderen?')"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="name" value="<?= e($b['name']) ?>"><button type="submit" class="btn ghost" style="margin:0">Verwijder</button></form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>

<div class="card">
  <h2>Back-up uploaden</h2>
  <form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="action" value="upload">
    <input type="file" name="zip" accept=".zip" required> <button type="submit" style="margin:0">Uploaden</button>
  </form>
</div>

<div class="card">
  <h2>Herstellen</h2>
  <?php if (!$isSuper): ?>
    <p class="muted">Alleen een super admin kan herstellen.</p>
  <?php elseif (!$list): ?>
    <p class="muted">Maak of upload eerst een back-up.</p>
  <?php else: ?>
    <p class="muted">Let op: herstellen overschrijft de huidige database en/of bestanden. Vooraf wordt automatisch een volledige noodback-up gemaakt.</p>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="restore">
      <label>Back-up</label>
      <select name="name" style="padding:10px;background:#000;color:#fff;border:1px solid var(--border);border-radius:8px;width:100%">
        <?php foreach ($list as $b): ?><option value="<?= e($b['name']) ?>"><?= e($b['name']) ?> (<?= e($labels[$b['type']]) ?>)</option><?php endforeach; ?>
      </select>
      <label><input type="checkbox" name="r_db" value="1" checked style="width:auto"> Database herstellen</label>
      <label><input type="checkbox" name="r_files" value="1" style="width:auto"> Bestanden herstellen (code overschrijven)</label>
      <label>Jouw wachtwoord</label><input type="password" name="password" autocomplete="current-password" required>
      <label>Typ HERSTEL ter bevestiging</label><input type="text" name="confirm" autocomplete="off" required>
      <button type="submit" style="background:var(--danger)">Herstellen</button>
    </form>
  <?php endif; ?>
  <a class="btn ghost" href="index.php">Terug</a>
</div>
<?php page_footer();
