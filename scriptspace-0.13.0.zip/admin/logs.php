<?php
// admin/logs.php — audit-log met actiefilter en paginering (recht: logs.view).
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_permission('logs.view', '../');

const PER_PAGE = 50;
$page   = max(1, (int)($_GET['page'] ?? 1));
$filter = trim((string)($_GET['action'] ?? ''));
$actions = array_column(db()->query('SELECT DISTINCT action FROM audit_log ORDER BY action')->fetchAll(), 'action');

$where = $filter !== '' ? 'WHERE action = ?' : '';
$params = $filter !== '' ? [$filter] : [];
$st = db()->prepare("SELECT COUNT(*) FROM audit_log $where");
$st->execute($params);
$total = (int)$st->fetchColumn();
$pages = max(1, (int)ceil($total / PER_PAGE));
$page  = min($page, $pages);
$st = db()->prepare("SELECT created_at, action, username, context, ip_address FROM audit_log $where ORDER BY id DESC LIMIT " . PER_PAGE . ' OFFSET ' . (($page - 1) * PER_PAGE));
$st->execute($params);
$rows = $st->fetchAll();

page_header('Audit-log', '../');
?>
<div class="card">
  <h1>Audit-log</h1>
  <form method="get" class="row">
    <select name="action" style="padding:8px;background:#000;color:#fff;border:1px solid var(--border);border-radius:8px">
      <option value="">Alle acties</option>
      <?php foreach ($actions as $a): ?><option value="<?= e($a) ?>" <?= $a === $filter ? 'selected' : '' ?>><?= e($a) ?></option><?php endforeach; ?>
    </select>
    <button type="submit" style="margin:0">Filter</button>
  </form>
  <table style="margin-top:16px">
    <tr><th>Tijd</th><th>Actie</th><th>Gebruiker</th><th>Context</th><th>IP</th></tr>
    <?php foreach ($rows as $l): ?>
      <tr><td><?= e($l['created_at']) ?></td><td><?= e($l['action']) ?></td><td><?= e($l['username'] ?? '-') ?></td><td><small><?= e($l['context'] ?? '') ?></small></td><td><?= e($l['ip_address']) ?></td></tr>
    <?php endforeach; ?>
  </table>
  <p class="muted">Pagina <?= $page ?> van <?= $pages ?> · <?= $total ?> regels
    <?php if ($page > 1): ?> · <a href="?action=<?= urlencode($filter) ?>&page=<?= $page - 1 ?>">vorige</a><?php endif; ?>
    <?php if ($page < $pages): ?> · <a href="?action=<?= urlencode($filter) ?>&page=<?= $page + 1 ?>">volgende</a><?php endif; ?>
  </p>
  <a class="btn ghost" href="index.php">Terug</a>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : admin/logs.php                                            ║
// ║  Role    : Admin                                                     ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Audit-log met filter                                      ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
