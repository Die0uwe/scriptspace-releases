<?php
// admin/index.php — systeemoverzicht (recht: admin.access).
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_permission('admin.access', '../');

$pdo = db();
$stats = [
    'Gebruikers totaal'       => (int)$pdo->query('SELECT COUNT(*) FROM users WHERE deleted_at IS NULL')->fetchColumn(),
    'Wacht op e-mailverificatie' => (int)$pdo->query('SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND email_verified_at IS NULL')->fetchColumn(),
    'Gedeactiveerd'           => (int)$pdo->query('SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND is_active = 0')->fetchColumn(),
    'Actieve sandboxes'       => (int)$pdo->query('SELECT COUNT(*) FROM sandboxes WHERE expires_at > NOW()')->fetchColumn(),
    'Verlopen sandboxes'      => (int)$pdo->query('SELECT COUNT(*) FROM sandboxes WHERE expires_at <= NOW()')->fetchColumn(),
];
$logs = can('logs.view')
    ? $pdo->query('SELECT created_at, action, username, context, ip_address FROM audit_log ORDER BY id DESC LIMIT 15')->fetchAll()
    : [];

$banner = [];
if (can('system.update')) {
    require_once __DIR__ . '/../includes/updater.php';
    require_once __DIR__ . '/../includes/migrate.php';
    $us = update_state();
    if (!empty($us['available'])) { $banner[] = 'Nieuwe versie beschikbaar: ' . $us['latest'] . ' (jij hebt ' . ss_version() . ').'; }
    try { $np = count(migrate_pending()); } catch (Throwable $e) { $np = 0; }
    if ($np > 0) { $banner[] = $np . ' databasemigratie(s) wachten om uitgevoerd te worden.'; }
}

page_header('Admin', '../');
?>
<h1 style="margin:0 0 12px">Beheer</h1>
<?php if ($banner): ?><div class="msg err"><?= e(implode(' ', $banner)) ?> <a href="updates.php">Naar Updates</a></div><?php endif; ?>
<div class="card">
  <h2>Statistieken</h2>
  <table><?php foreach ($stats as $label => $n): ?><tr><th><?= e($label) ?></th><td><?= $n ?></td></tr><?php endforeach; ?></table>
</div>
<?php if ($logs): ?>
<div class="card">
  <h2>Laatste gebeurtenissen</h2>
  <table>
    <tr><th>Tijd</th><th>Actie</th><th>Gebruiker</th><th>Context</th><th>IP</th></tr>
    <?php foreach ($logs as $l): ?>
      <tr><td><?= e($l['created_at']) ?></td><td><?= e($l['action']) ?></td><td><?= e($l['username'] ?? '-') ?></td><td><small><?= e($l['context'] ?? '') ?></small></td><td><?= e($l['ip_address']) ?></td></tr>
    <?php endforeach; ?>
  </table>
</div>
<?php endif; ?>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : admin/index.php                                           ║
// ║  Role    : Admin                                                     ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Systeemoverzicht                                          ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
