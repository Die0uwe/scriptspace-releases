<?php
// admin/user_edit.php — gebruiker activeren/deactiveren en rollen toekennen (recht: users.manage).
//
// Regels (overgenomen en aangescherpt t.o.v. Blueprint CMS, zie docs/AUTH.md):
//  1. Je kunt nooit een rol toekennen met een hogere priority dan je eigen hoogste rol.
//  2. Je kunt geen gebruiker bewerken die een hogere priority heeft dan jij.
//  3. Zelf-lockout: je kunt jezelf niet deactiveren en je eigen laatste rol niet verwijderen.
//  4. Er moet altijd minstens één actieve super_admin overblijven.
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/oauth.php';
require_once __DIR__ . '/../includes/socials.php';
$me = require_permission('users.manage', '../');

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$st = db()->prepare('SELECT id, username, email, is_active, email_verified_at FROM users WHERE id = ? AND deleted_at IS NULL');
$st->execute([$id]);
$target = $st->fetch();
if (!$target) { http_response_code(404); exit('Gebruiker niet gevonden.'); }

$isSelf      = $id === $me['id'];
$actorMax    = highest_priority($me['id']);
$targetMax   = highest_priority($id);
$roles       = all_roles();
$priorityOf  = array_column($roles, 'priority', 'id');
$currentIds  = array_map('intval', array_column(user_roles($id), 'id'));
$error = '';

if ($targetMax > $actorMax) {
    http_response_code(403);
    exit('Je kunt geen gebruiker bewerken met een hogere rol dan jezelf.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify()) {
        $error = 'Sessie verlopen.';
    } else {
        $roleIds    = array_map('intval', (array)($_POST['roles'] ?? []));
        $wantActive = isset($_POST['is_active']);

        if ($isSelf) {
            $wantActive = true;
            if ($roleIds === []) { $error = 'Je kunt je eigen laatste rol niet verwijderen.'; }
        }
        foreach ($roleIds as $rid) {
            if (!isset($priorityOf[$rid])) { $error = 'Onbekende rol.'; break; }
            if ((int)$priorityOf[$rid] > $actorMax) { $error = 'Je kunt geen rol toekennen met een hogere prioriteit dan je eigen rol.'; break; }
        }

        if ($error === '') {
            // Blijft er na deze wijziging minstens één actieve super_admin over?
            $superId = (int)db()->query("SELECT id FROM roles WHERE name = 'super_admin'")->fetchColumn();
            $st = db()->prepare("SELECT COUNT(*) FROM users u JOIN user_roles ur ON ur.user_id = u.id
                                 WHERE ur.role_id = ? AND u.is_active = 1 AND u.deleted_at IS NULL AND u.id <> ?");
            $st->execute([$superId, $id]);
            $othersLeft = (int)$st->fetchColumn();
            $staysSuper = $wantActive && in_array($superId, $roleIds, true);
            if ($othersLeft === 0 && !$staysSuper && in_array($superId, $currentIds, true)) {
                $error = 'Er moet minstens één actieve super admin overblijven.';
            }
        }

        if ($error === '') {
            db()->prepare('UPDATE users SET is_active = ? WHERE id = ?')->execute([$wantActive ? 1 : 0, $id]);
            sync_roles($id, $roleIds, $me['id']);
            audit('users.update', $me['id'], [
                'target_user_id' => $id, 'target_username' => $target['username'],
                'active' => $wantActive, 'role_ids' => $roleIds,
            ]);
            redirect('users_manage.php?ok=1');
        }
    }
}

page_header('Gebruiker bewerken', '../');
?>
<div class="card">
  <h1><?= e($target['username']) ?></h1>
  <p class="muted"><?= e($target['email']) ?><?= $target['email_verified_at'] === null ? ' · e-mail niet geverifieerd' : '' ?></p>
  <?php if ($error): ?><div class="msg err"><?= e($error) ?></div><?php endif; ?>
  <form method="post">
    <?= csrf_field() ?><input type="hidden" name="id" value="<?= $id ?>">
    <label><input type="checkbox" name="is_active" value="1" <?= $target['is_active'] ? 'checked' : '' ?> <?= $isSelf ? 'disabled' : '' ?>> Account actief</label>
    <h2 style="margin-top:20px">Rollen</h2>
    <?php foreach ($roles as $r): $tooHigh = (int)$r['priority'] > $actorMax; ?>
      <label style="color:inherit">
        <input type="checkbox" name="roles[]" value="<?= (int)$r['id'] ?>" <?= in_array((int)$r['id'], $currentIds, true) ? 'checked' : '' ?> <?= $tooHigh ? 'disabled' : '' ?>>
        <?= e($r['display_name']) ?> <small>(prioriteit <?= (int)$r['priority'] ?>)</small><?= $tooHigh ? ' <small>— boven jouw niveau</small>' : '' ?>
      </label>
    <?php endforeach; ?>
    <button type="submit">Opslaan</button>
    <a class="btn ghost" href="users_manage.php">Annuleren</a>
  </form>
</div>
<div class="card">
  <h2>Gekoppelde accounts en socials</h2>
  <?php $ids2 = identities_of($id); $lk2 = social_links_of($id); ?>
  <table>
    <tr><th>Dienst</th><th>Soort</th><th>Gegevens</th></tr>
    <?php foreach ($ids2 as $k => $r): ?><tr><td><?= e(OAUTH_DEFS[$k]['label'] ?? $k) ?></td><td><span class="badge ok">Geverifieerd (inloggen)</span></td><td class="brk"><?= e(($r['display_name'] ?: '') . ($r['email'] ? ' · ' . $r['email'] : '')) ?></td></tr><?php endforeach; ?>
    <?php foreach ($lk2 as $k => $r): ?><tr><td><?= e(SOCIAL_SERVICES[$k]['label'] ?? $k) ?></td><td><span class="badge">Profiel-link</span></td><td class="brk"><?= e($r['url']) ?></td></tr><?php endforeach; ?>
    <?php if (!$ids2 && !$lk2): ?><tr><td colspan="3" class="muted">Geen koppelingen.</td></tr><?php endif; ?>
  </table>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : admin/user_edit.php                                       ║
// ║  Role    : Admin                                                     ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Rollen en status met escalatie-regels                     ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
