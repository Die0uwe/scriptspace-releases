<?php
// includes/rbac.php — rollen en permissies (naar het model van Blueprint CMS).
// Rol = naam + priority. Permissie = tekst zoals 'users.manage'. Permissie '*' = alles (super_admin).
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

/** Rollen van een gebruiker, hoogste priority eerst (per request gecached). */
function user_roles(int $userId, bool $flush = false): array
{
    static $cache = [];
    if ($flush) { unset($cache[$userId]); return []; }
    if (!isset($cache[$userId])) {
        $st = db()->prepare('SELECT r.* FROM roles r JOIN user_roles ur ON ur.role_id = r.id WHERE ur.user_id = ? ORDER BY r.priority DESC');
        $st->execute([$userId]);
        $cache[$userId] = $st->fetchAll();
    }
    return $cache[$userId];
}

function user_permissions(int $userId): array
{
    static $cache = [];
    if (!isset($cache[$userId])) {
        $st = db()->prepare('SELECT DISTINCT p.name FROM permissions p
                             JOIN role_permissions rp ON rp.permission_id = p.id
                             JOIN user_roles ur ON ur.role_id = rp.role_id
                             WHERE ur.user_id = ?');
        $st->execute([$userId]);
        $cache[$userId] = array_column($st->fetchAll(), 'name');
    }
    return $cache[$userId];
}

function user_can(int $userId, string $permission): bool
{
    $perms = user_permissions($userId);
    return in_array($permission, $perms, true) || in_array('*', $perms, true);
}

function user_has_role(int $userId, string $roleName): bool
{
    foreach (user_roles($userId) as $r) {
        if ($r['name'] === $roleName) { return true; }
    }
    return false;
}

/**
 * PHP uitvoeren mag alleen een super_admin met het recht php.execute. De rolcontrole staat in code (en niet
 * alleen in de database), zodat een oudere installatie waar 'admin' het recht nog heeft toch veilig is.
 */
function php_exec_allowed(int $userId): bool
{
    return user_can($userId, 'php.execute') && user_has_role($userId, 'super_admin');
}

/** Hoogste priority van een gebruiker (0 zonder rollen). */
function highest_priority(int $userId): int
{
    $roles = user_roles($userId);
    return $roles === [] ? 0 : (int)$roles[0]['priority'];
}

function all_roles(): array
{
    return db()->query('SELECT * FROM roles ORDER BY priority DESC')->fetchAll();
}

function assign_default_role(int $userId): void
{
    $id = db()->query('SELECT id FROM roles WHERE is_default = 1 ORDER BY priority ASC LIMIT 1')->fetchColumn();
    if ($id) {
        db()->prepare('INSERT IGNORE INTO user_roles (user_id, role_id) VALUES (?, ?)')->execute([$userId, $id]);
    }
}

/** Zet de rollen van een gebruiker exact gelijk aan $roleIds. */
function sync_roles(int $userId, array $roleIds, ?int $assignedBy): void
{
    $pdo = db();
    $pdo->beginTransaction();
    $pdo->prepare('DELETE FROM user_roles WHERE user_id = ?')->execute([$userId]);
    $ins = $pdo->prepare('INSERT INTO user_roles (user_id, role_id, assigned_by) VALUES (?, ?, ?)');
    foreach (array_unique($roleIds) as $rid) { $ins->execute([$userId, (int)$rid, $assignedBy]); }
    $pdo->commit();
    user_roles($userId, true);
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/rbac.php                                         ║
// ║  Role    : Core                                                      ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Rollen, permissies en priority                            ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
