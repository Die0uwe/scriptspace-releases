<?php
// includes/updater.php — versie en updatecontrole (0.12.0: alleen CONTROLEREN en melden; installeren komt in 0.13.0).
// Vraagt de laatste release van de publieke releases-repo op via de GitHub-API (User-Agent, ETag, 6 uur cache).
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

const UPDATE_CACHE_HOURS = 6;
const UPDATE_RETRY_MINUTES = 60;
const UPDATE_DEFAULT_REPO = 'Die0uwe/scriptspace-releases';

/** Geïnstalleerde versie uit het bestand VERSION (x.y.z), anders 0.0.0. */
function ss_version(): string
{
    $v = is_file(SS_ROOT . '/VERSION') ? trim((string)file_get_contents(SS_ROOT . '/VERSION')) : '';
    return preg_match('/^\d+\.\d+\.\d+$/', $v) ? $v : '0.0.0';
}

/** "v1.2.3" of "1.2.3" -> "1.2.3"; alles anders (ook pre-releases als 1.2.3-beta) -> null. */
function update_normalize_tag(string $tag): ?string
{
    $t = ltrim(trim($tag), 'vV');
    return preg_match('/^\d{1,4}\.\d{1,4}\.\d{1,4}$/', $t) ? $t : null;
}

/**
 * Leest het JSON-antwoord van /releases/latest. Geeft null terug voor concepten, pre-releases of ongeldige tags.
 * Resultaat: ['latest','available','url','notes','published'].
 */
function update_parse_release(array $json, string $current): ?array
{
    if (!empty($json['draft']) || !empty($json['prerelease'])) { return null; }
    $latest = update_normalize_tag((string)($json['tag_name'] ?? ''));
    if ($latest === null) { return null; }
    $url = (string)($json['html_url'] ?? '');
    if (!preg_match('#^https://github\.com/[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+/releases/#', $url)) { $url = ''; }
    $assets = [];
    $repo = update_repo();
    foreach ((array)($json['assets'] ?? []) as $a) {
        $n = (string)($a['name'] ?? ''); $u = (string)($a['browser_download_url'] ?? '');
        if (!preg_match('#^https://github\.com/' . preg_quote($repo, '#') . '/releases/download/[A-Za-z0-9._-]+/' . preg_quote($n, '#') . '$#', $u)) { continue; }
        if ($n === 'manifest.json') { $assets['manifest'] = $u; }
        elseif ($n === 'manifest.json.sig') { $assets['sig'] = $u; }
        elseif (preg_match('/^scriptspace-\d+\.\d+\.\d+\.zip$/', $n)) { $assets['zip'] = $u; }
    }
    return [
        'assets' => $assets,
        'latest' => $latest,
        'available' => version_compare($latest, $current, '>'),
        'url' => $url,
        'notes' => mb_substr(trim((string)($json['body'] ?? '')), 0, 1500),
        'published' => substr((string)($json['published_at'] ?? ''), 0, 10),
    ];
}

function update_repo(): string
{
    $r = (string)cfg('update_repo', UPDATE_DEFAULT_REPO);
    return preg_match('#^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$#', $r) ? $r : UPDATE_DEFAULT_REPO;
}

function update_state_path(): string { return SS_ROOT . '/storage/update_check.json'; }

/** Laatste bekende stand: ['checked_at','latest','available','url','notes','published','etag','error']. */
function update_state(): array
{
    $p = update_state_path();
    $j = is_file($p) ? json_decode((string)file_get_contents($p), true) : null;
    $s = is_array($j) ? $j : [];
    // 'available' altijd opnieuw bepalen: de lokale versie kan sinds de controle zijn bijgewerkt
    if (!empty($s['latest'])) { $s['available'] = version_compare((string)$s['latest'], ss_version(), '>'); }
    return $s;
}

function update_state_save(array $s): void
{
    $dir = SS_ROOT . '/storage';
    if (is_dir($dir) && is_writable($dir)) { @file_put_contents(update_state_path(), json_encode($s, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX); }
}

/** GET naar de GitHub-API: [http-code, body, etag, fout]. Geen redirects, alleen https. */
function update_http(string $url, string $etag = ''): array
{
    if (!function_exists('curl_init')) { return [0, '', '', 'De curl-extensie ontbreekt op deze server.']; }
    $headers = ['User-Agent: ScriptSpace-updater/' . ss_version(), 'Accept: application/vnd.github+json', 'X-GitHub-Api-Version: 2022-11-28'];
    if ($etag !== '') { $headers[] = 'If-None-Match: ' . $etag; }
    $newEtag = '';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_HTTPHEADER => $headers, CURLOPT_MAXFILESIZE => 1048576,
        CURLOPT_HEADERFUNCTION => static function ($c, string $line) use (&$newEtag): int {
            if (stripos($line, 'etag:') === 0) { $newEtag = trim(substr($line, 5)); }
            return strlen($line);
        },
    ]);
    $out = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err = $out === false ? curl_error($ch) : '';
    curl_close($ch);
    return [$code, is_string($out) ? $out : '', $newEtag, $err];
}

/**
 * Controleert op een nieuwe release en bewaart de uitkomst in storage/update_check.json.
 * Gooit nooit: fouten komen in de stand ('error'). $fetch is alleen voor tests: fn(url, etag) => [code, body, etag, err].
 */
function update_check(?callable $fetch = null): array
{
    $old = update_state();
    $url = 'https://api.github.com/repos/' . update_repo() . '/releases/latest';
    [$code, $body, $etag, $err] = ($fetch ?? 'update_http')($url, (string)($old['etag'] ?? ''));
    $s = $old;
    $s['checked_at'] = time();
    $s['error'] = '';
    if ($err !== '') {
        $s['error'] = 'GitHub niet bereikbaar: ' . $err;
    } elseif ($code === 304) {
        // ongewijzigd: oude gegevens blijven gelden
    } elseif ($code === 404) {
        $s['error'] = 'Nog geen release gepubliceerd in ' . update_repo() . '.';
    } elseif ($code === 403 || $code === 429) {
        $s['error'] = 'GitHub begrenst het aantal aanvragen; later opnieuw proberen.';
    } elseif ($code !== 200) {
        $s['error'] = "GitHub gaf HTTP $code.";
    } else {
        $r = update_parse_release((array)json_decode($body, true), ss_version());
        if ($r === null) {
            $s['error'] = 'De laatste release is ongeldig (concept, pre-release of onbekende tag).';
        } else {
            $s = array_merge($s, $r, ['etag' => $etag]);
        }
    }
    update_state_save($s);
    return update_state();
}

/** Pseudo-cron: hoogstens elke 6 uur (bij een fout elk uur), goedkoop via filemtime. Uit te zetten met 'update_check' => false. */
function update_check_maybe(?int $now = null): bool
{
    if (!cfg('update_check', true)) { return false; }
    $p = update_state_path();
    $now ??= time();
    $dir = SS_ROOT . '/storage';
    if (!is_dir($dir) || !is_writable($dir)) { return false; }
    $last = is_file($p) ? (int)@filemtime($p) : 0;
    $wait = UPDATE_CACHE_HOURS * 3600;
    if ($last > 0 && $now - $last < $wait) {
        $st = update_state();
        if (($st['error'] ?? '') === '' || $now - $last < UPDATE_RETRY_MINUTES * 60) { return false; }
    }
    $lock = @fopen($dir . '/update_check.lock', 'c');
    if ($lock === false) { return false; }
    try {
        if (!flock($lock, LOCK_EX | LOCK_NB)) { return false; }
        clearstatcache(true, $p);
        if (is_file($p) && $now - (int)@filemtime($p) < UPDATE_RETRY_MINUTES * 60) { return false; }
        update_check();
        return true;
    } finally {
        @flock($lock, LOCK_UN);
        @fclose($lock);
    }
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/updater.php                                      ║
// ║  Role    : Core                                                      ║
// ║  Version : 0.12.0                                                    ║
// ║  Updated : 2026-10-01                                                ║
// ║  Notes   : Versie + GitHub-releasecontrole (alleen melden)           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
