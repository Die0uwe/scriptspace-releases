<?php
// includes/maintenance.php — opschonen en back-up/herstel (gedeeld door admin-pagina's en cron).
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

const BK_NAME_RE = '/^backup_\d{8}_\d{6}_(full|db|files)_[a-f0-9]{6}\.zip$/';
const BK_UNVERIFIED_DAYS = 7;

function rrmdir(string $dir): void
{
    foreach (scandir($dir) ?: [] as $item) {
        if ($item === '.' || $item === '..') { continue; }
        $p = $dir . '/' . $item;
        (is_dir($p) && !is_link($p)) ? rrmdir($p) : @unlink($p);
    }
    @rmdir($dir);
}

function dir_size(string $dir): int
{
    $n = 0;
    if (!is_dir($dir)) { return 0; }
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)) as $f) { if ($f->isFile()) { $n += $f->getSize(); } }
    return $n;
}

function human_bytes(int $b): string
{
    foreach (['B', 'KB', 'MB', 'GB'] as $i => $u) { if ($b < 1024 || $i === 3) { return ($i ? number_format($b, 1, ',', '.') : (string)$b) . ' ' . $u; } $b /= 1024; }
    return '';
}

/* ---------------- Opschonen ---------------- */

/** Wat zou er opgeschoond worden? (voor weergave in de admin) */
function cleanup_preview(): array
{
    $db = db();
    $base = SS_ROOT . '/sandboxes';
    return [
        'sandboxes_expired' => (int)$db->query('SELECT COUNT(*) FROM sandboxes WHERE expires_at <= NOW()')->fetchColumn(),
        'sandboxes_active'  => (int)$db->query('SELECT COUNT(*) FROM sandboxes WHERE expires_at > NOW()')->fetchColumn(),
        'orphans'           => count(cleanup_orphans($base, false)),
        'attempts_old'      => (int)$db->query('SELECT COUNT(*) FROM login_attempts WHERE created_at < (NOW() - INTERVAL 1 DAY)')->fetchColumn(),
        'unverified_old'    => (int)$db->query('SELECT COUNT(*) FROM users WHERE email_verified_at IS NULL AND created_at < (NOW() - INTERVAL ' . BK_UNVERIFIED_DAYS . ' DAY)')->fetchColumn(),
        'sandbox_bytes'     => dir_size($base),
    ];
}

/** Mappen in sandboxes/ zonder databaserij (en ouder dan een uur, zodat nieuwe sandboxes veilig zijn). */
function cleanup_orphans(string $base, bool $delete): array
{
    $found = [];
    if (!is_dir($base)) { return $found; }
    $known = array_flip(array_column(db()->query('SELECT slug FROM sandboxes')->fetchAll(), 'slug'));
    foreach (scandir($base) ?: [] as $d) {
        if (!preg_match('/^sb_[a-f0-9]{8}$/', $d) || isset($known[$d]) || !is_dir("$base/$d") || is_link("$base/$d")) { continue; }
        if (filemtime("$base/$d") > time() - 3600) { continue; }
        $found[] = $d;
        if ($delete) { rrmdir("$base/$d"); }
    }
    return $found;
}

/** Voert alle opschoontaken uit en geeft tellingen terug. $by = user-id of null (cron). */
function cleanup_run(?int $by = null): array
{
    $db = db();
    $base = realpath(SS_ROOT . '/sandboxes');
    $deleted = 0;
    foreach ($db->query('SELECT id, slug FROM sandboxes WHERE expires_at <= NOW()')->fetchAll() as $r) {
        if ($base !== false && preg_match('/^sb_[a-f0-9]{6,32}$/', $r['slug'])) {
            $dir = $base . '/' . $r['slug'];
            if (is_dir($dir) && !is_link($dir)) { rrmdir($dir); }
        }
        $db->prepare('DELETE FROM sandboxes WHERE id = ?')->execute([$r['id']]);
        $deleted++;
    }
    require_once __DIR__ . '/phprun.php';
    phprun_gc();
    $orph = $base !== false ? count(cleanup_orphans($base, true)) : 0;
    $att = $db->exec('DELETE FROM login_attempts WHERE created_at < (NOW() - INTERVAL 1 DAY)');
    // Niet-bevestigde accounts hebben nooit kunnen inloggen en hebben dus geen data
    $unv = $db->exec('DELETE FROM users WHERE email_verified_at IS NULL AND created_at < (NOW() - INTERVAL ' . BK_UNVERIFIED_DAYS . ' DAY)');
    // audit_log begrenzen (standaard 180 dagen; rate limits kijken maar enkele uren/dagen terug)
    $keep = max(30, (int)cfg('audit_keep_days', 180));
    $aud = $db->exec('DELETE FROM audit_log WHERE created_at < (NOW() - INTERVAL ' . $keep . ' DAY)');
    $res = ['sandboxes_deleted' => $deleted, 'orphans_deleted' => $orph, 'attempts_deleted' => (int)$att, 'unverified_deleted' => (int)$unv, 'audit_deleted' => (int)$aud];
    audit('system.cleanup', $by, $res);
    return $res;
}

/* ---------------- Automatisch opschonen zonder cron (STRATO) ---------------- */

/** Interval in uren tussen automatische opschoonrondes; 0 = uit. */
function auto_cleanup_hours(): int
{
    return max(0, (int)cfg('auto_cleanup_hours', 6));
}

/**
 * "Pseudo-cron": draait cleanup_run() hoogstens elke N uur, getriggerd door een gewone paginaweergave.
 * - Goedkoop: één filemtime()-controle op storage/cleanup.stamp, geen databasequery.
 * - Eén uitvoerder tegelijk (flock, niet-blokkerend); andere verzoeken slaan gewoon over.
 * - Draait na het versturen van het antwoord (fastcgi_finish_request) zodat de bezoeker niets merkt.
 * Retourneert true als er een ronde is uitgevoerd. $now/$force alleen voor tests.
 */
function auto_cleanup_maybe(?int $now = null, bool $force = false): bool
{
    $hours = auto_cleanup_hours();
    if ($hours === 0 && !$force) { return false; }
    $dir = SS_ROOT . '/storage';
    if (!is_dir($dir) || !is_writable($dir)) { return false; }
    $now ??= time();
    $stamp = $dir . '/cleanup.stamp';
    $last = is_file($stamp) ? (int)@filemtime($stamp) : 0;
    if (!$force && $now - $last < max(1, $hours) * 3600) { return false; }

    $lock = @fopen($dir . '/cleanup.lock', 'c');
    if ($lock === false) { return false; }
    try {
        if (!flock($lock, LOCK_EX | LOCK_NB)) { return false; }   // iemand anders is al bezig
        clearstatcache(true, $stamp);
        $last = is_file($stamp) ? (int)@filemtime($stamp) : 0;
        if (!$force && $now - $last < max(1, $hours) * 3600) { return false; }   // net door een ander gedaan
        @touch($stamp, $now);   // meteen markeren: bij een fout proberen we pas over N uur opnieuw
        try {
            cleanup_run(null);
        } catch (Throwable $e) {
            error_log('auto-cleanup mislukt: ' . $e->getMessage());
        }
        return true;
    } finally {
        @flock($lock, LOCK_UN);
        @fclose($lock);
    }
}

/** Haakje voor bootstrap: alleen bij gewone GET-paginaweergaven (niet API, cron, CLI of assets). */
function auto_cleanup_register(): void
{
    if (PHP_SAPI === 'cli' || ($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') { return; }
    $path = (string)parse_url((string)($_SERVER['REQUEST_URI'] ?? ''), PHP_URL_PATH);
    if (preg_match('#/(api|cron)/#', $path)) { return; }
    register_shutdown_function(static function (): void {
        if (function_exists('fastcgi_finish_request')) { @fastcgi_finish_request(); }
        @ignore_user_abort(true);
        @set_time_limit(60);
        try { auto_cleanup_maybe(); } catch (Throwable $e) { error_log('auto-cleanup: ' . $e->getMessage()); }
        try { require_once __DIR__ . '/updater.php'; update_check_maybe(); } catch (Throwable $e) { error_log('update-check: ' . $e->getMessage()); }
    });
}

/* ---------------- Back-up ---------------- */

function backup_dir(): string
{
    $d = SS_ROOT . '/storage/backups';
    if (!is_dir($d)) { @mkdir($d, 0750, true); }
    return $d;
}

function backup_list(): array
{
    $out = [];
    foreach (glob(backup_dir() . '/backup_*.zip') ?: [] as $f) {
        $n = basename($f);
        if (!preg_match(BK_NAME_RE, $n, $m)) { continue; }
        $out[] = ['name' => $n, 'type' => $m[1], 'size' => (int)filesize($f), 'time' => (int)filemtime($f)];
    }
    usort($out, fn($a, $b) => $b['time'] <=> $a['time']);
    return $out;
}

function backup_path(string $name): ?string
{
    if (!preg_match(BK_NAME_RE, $name)) { return null; }
    $p = backup_dir() . '/' . $name;
    return is_file($p) ? $p : null;
}

/** SQL-dump in eigen formaat: één statement per regel (veilig terug te lezen). */
function db_dump_sql(): string
{
    $db = db();
    $out = "-- ScriptSpace database-export " . date('c') . "\nSET FOREIGN_KEY_CHECKS=0;\n";
    $tables = $db->query('SHOW FULL TABLES WHERE Table_type = "BASE TABLE"')->fetchAll(PDO::FETCH_NUM);
    foreach ($tables as $t) {
        $name = $t[0];
        if (!preg_match('/^[A-Za-z0-9_]+$/', $name)) { continue; }
        $create = $db->query("SHOW CREATE TABLE `$name`")->fetch(PDO::FETCH_NUM)[1];
        $out .= "DROP TABLE IF EXISTS `$name`;\n" . preg_replace('/\s*\n\s*/', ' ', $create) . ";\n";
        $st = $db->query("SELECT * FROM `$name`");
        $batch = [];
        $flush = function () use (&$batch, &$out, $name) {
            if ($batch) { $out .= "INSERT INTO `$name` VALUES " . implode(',', $batch) . ";\n"; $batch = []; }
        };
        while ($row = $st->fetch(PDO::FETCH_NUM)) {
            $vals = array_map(fn($v) => $v === null ? 'NULL' : $db->quote((string)$v), $row);
            $batch[] = '(' . implode(',', $vals) . ')';
            if (count($batch) >= 200) { $flush(); }
        }
        $flush();
    }
    return $out . "SET FOREIGN_KEY_CHECKS=1;\n";
}

/** Bestanden die in een back-up horen (relatief pad => absoluut pad). */
function backup_file_set(): array
{
    $root = realpath(SS_ROOT);
    $files = [];
    $it = new RecursiveIteratorIterator(new RecursiveCallbackFilterIterator(
        new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
        function (SplFileInfo $f) use ($root) {
            $rel = ltrim(substr($f->getPathname(), strlen($root)), '/\\');
            $rel = str_replace('\\', '/', $rel);
            if ($f->isLink()) { return false; }
            foreach (['.git', 'storage', 'sandboxes', 'node_modules'] as $skip) { if ($rel === $skip || str_starts_with($rel, $skip . '/')) { return false; } }
            return $rel !== 'config/config.php';
        }
    ));
    foreach ($it as $f) { if ($f->isFile()) { $files[str_replace('\\', '/', ltrim(substr($f->getPathname(), strlen($root)), '/\\'))] = $f->getPathname(); } }
    return $files;
}

/** Maakt een back-up ('full' | 'db' | 'files'). Geeft bestandsnaam terug; gooit RuntimeException bij fouten. */
function backup_create(string $type, ?int $by = null): string
{
    if (!in_array($type, ['full', 'db', 'files'], true)) { throw new RuntimeException('Onbekend type.'); }
    if (!class_exists('ZipArchive')) { throw new RuntimeException('PHP-extensie zip ontbreekt op deze server.'); }
    $name = 'backup_' . date('Ymd_His') . '_' . $type . '_' . bin2hex(random_bytes(3)) . '.zip';
    $path = backup_dir() . '/' . $name;
    $zip = new ZipArchive();
    if ($zip->open($path, ZipArchive::CREATE | ZipArchive::EXCL) !== true) { throw new RuntimeException('ZIP aanmaken mislukt (schrijfrechten op storage/?).'); }
    $count = 0;
    if ($type !== 'files') { $zip->addFromString('database.sql', db_dump_sql()); }
    if ($type !== 'db') { foreach (backup_file_set() as $rel => $abs) { $zip->addFile($abs, 'files/' . $rel); $count++; } }
    $zip->addFromString('manifest.json', json_encode(['app' => 'scriptspace-cms', 'type' => $type, 'created' => date('c'), 'files' => $count, 'php' => PHP_VERSION], JSON_PRETTY_PRINT));
    if (!$zip->close()) { @unlink($path); throw new RuntimeException('ZIP schrijven mislukt.'); }
    @chmod($path, 0640);
    // bewaar alleen de nieuwste N back-ups
    $keep = max(1, (int)cfg('backup_keep', 10));
    foreach (array_slice(backup_list(), $keep) as $old) { @unlink(backup_dir() . '/' . $old['name']); }
    audit('backup.create', $by, ['file' => $name, 'type' => $type, 'bytes' => (int)filesize($path)]);
    return $name;
}

/** Leest een dump en voert die uit. Alleen statements in ons eigen formaat worden toegestaan. */
function db_restore_sql(string $sql): int
{
    $db = db();
    $n = 0;
    $lines = preg_split('/\r?\n/', $sql);
    $allowed = '/^(SET FOREIGN_KEY_CHECKS=[01]|DROP TABLE IF EXISTS `[A-Za-z0-9_]+`|CREATE TABLE `[A-Za-z0-9_]+` \(|INSERT INTO `[A-Za-z0-9_]+` VALUES \()/';
    foreach ($lines as $l) {
        $l = trim($l);
        if ($l === '' || str_starts_with($l, '--')) { continue; }
        if (!preg_match($allowed, $l) || !str_ends_with($l, ';')) { throw new RuntimeException('Onverwachte regel in de database-export; herstel afgebroken.'); }
    }
    foreach ($lines as $l) {
        $l = trim($l);
        if ($l === '' || str_starts_with($l, '--')) { continue; }
        $db->exec($l);
        $n++;
    }
    return $n;
}

/** Herstel uit een back-up-ZIP. $what: ['db'=>bool,'files'=>bool]. Maakt eerst een noodback-up. */
function backup_restore(string $name, array $what, ?int $by): array
{
    $path = backup_path($name);
    if ($path === null) { throw new RuntimeException('Back-up niet gevonden.'); }
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) { throw new RuntimeException('ZIP kan niet geopend worden.'); }
    $res = ['statements' => 0, 'files' => 0, 'safety' => ''];
    try {
        $hasDb = $zip->locateName('database.sql') !== false;
        if (!empty($what['db']) && !$hasDb) { throw new RuntimeException('Deze back-up bevat geen database.'); }
        // noodback-up van de huidige toestand
        $res['safety'] = backup_create('full', $by);
        if (!empty($what['db'])) { $res['statements'] = db_restore_sql((string)$zip->getFromName('database.sql')); }
        if (!empty($what['files'])) {
            $root = realpath(SS_ROOT);
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $e = $zip->getNameIndex($i);
                if ($e === false || !str_starts_with($e, 'files/') || str_ends_with($e, '/')) { continue; }
                $rel = substr($e, 6);
                if ($rel === '' || str_contains($rel, '..') || str_contains($rel, "\0") || $rel[0] === '/' || preg_match('/^[A-Za-z]:/', $rel)
                    || $rel === 'config/config.php' || str_starts_with($rel, 'storage/') || str_starts_with($rel, 'sandboxes/') || str_starts_with($rel, '.git/')) { continue; }
                $target = $root . '/' . $rel;
                $dir = dirname($target);
                if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
                $realDir = realpath($dir);
                if ($realDir === false || !str_starts_with($realDir . '/', $root . '/')) { continue; }
                $data = $zip->getFromIndex($i);
                if ($data !== false && @file_put_contents($target, $data) !== false) { $res['files']++; }
            }
        }
    } finally {
        $zip->close();
    }
    audit('backup.restore', $by, ['file' => $name] + $res);
    return $res;
}
