<?php
// includes/migrate.php — databasemigraties (sql/migrations/NNNN_naam.sql), bijgehouden in de tabel schema_migrations.
// Elke migratie is idempotent geschreven. Bij "bestaat al"-fouten (dubbele kolom/index/tabel) telt de regel als gedaan;
// bij elke andere fout stopt de run en wordt die migratie NIET als toegepast vastgelegd.
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

const MIGRATE_TOLERATED = [1060, 1061, 1050, 1091];   // dubbele kolom, dubbele index, tabel bestaat, kolom/index bestaat niet (DROP)

function migrate_dir(): string { return SS_ROOT . '/sql/migrations'; }

/** [naam => pad], gesorteerd op naam. Alleen NNNN_kleine_letters.sql. */
function migrate_files(?string $dir = null): array
{
    $out = [];
    foreach (glob(($dir ?? migrate_dir()) . '/*.sql') ?: [] as $f) {
        if (preg_match('/^\d{4}_[a-z0-9_]+\.sql$/', basename($f))) { $out[basename($f)] = $f; }
    }
    ksort($out, SORT_STRING);
    return $out;
}

function migrate_ensure_table(): void
{
    db()->exec('CREATE TABLE IF NOT EXISTS schema_migrations (name VARCHAR(100) NOT NULL, checksum CHAR(64) NOT NULL, applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (name)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
}

/** [naam => checksum] van wat al is toegepast. */
function migrate_applied(): array
{
    migrate_ensure_table();
    return db()->query('SELECT name, checksum FROM schema_migrations')->fetchAll(PDO::FETCH_KEY_PAIR);
}

/** Namen van migraties die nog niet zijn toegepast. */
function migrate_pending(?string $dir = null): array
{
    return array_values(array_diff(array_keys(migrate_files($dir)), array_keys(migrate_applied())));
}

/** Toegepaste migraties waarvan het bestand sindsdien is gewijzigd (waarschuwing; niet opnieuw uitvoeren). */
function migrate_changed(?string $dir = null): array
{
    $files = migrate_files($dir);
    $out = [];
    foreach (migrate_applied() as $n => $sum) {
        if (isset($files[$n]) && !hash_equals($sum, hash_file('sha256', $files[$n]))) { $out[] = $n; }
    }
    return $out;
}

/** Splitst een SQL-bestand in losse statements (commentaarregels weg, split op ;-regeleinde). */
function migrate_statements(string $sql): array
{
    $sql = preg_replace('/^\s*--.*$/m', '', str_replace("\r\n", "\n", $sql));
    $out = [];
    foreach (explode(";\n", $sql . "\n") as $s) {
        $s = trim($s);
        if ($s !== '') { $out[] = rtrim($s, ';'); }
    }
    return $out;
}

/**
 * Voert alle openstaande migraties uit, in volgorde. Geeft de namen van de uitgevoerde terug.
 * Gooit RuntimeException bij de eerste echte fout (eerdere migraties blijven vastgelegd).
 */
function migrate_run(?string $dir = null, ?int $by = null): array
{
    $pdo = db();
    migrate_ensure_table();
    $got = $pdo->query("SELECT GET_LOCK('ss_migrate', 5)")->fetchColumn();
    if ((int)$got !== 1) { throw new RuntimeException('Er draait al een migratie. Probeer het zo opnieuw.'); }
    $done = [];
    try {
        $files = migrate_files($dir);
        $applied = migrate_applied();
        foreach ($files as $name => $path) {
            if (isset($applied[$name])) { continue; }
            $sql = (string)file_get_contents($path);
            foreach (migrate_statements($sql) as $i => $stmt) {
                try {
                    $pdo->exec($stmt);
                } catch (PDOException $e) {
                    $code = (int)($e->errorInfo[1] ?? 0);
                    if (in_array($code, MIGRATE_TOLERATED, true)) { continue; }
                    audit('system.migrate_failed', $by, ['migration' => $name, 'statement' => $i + 1, 'code' => $code]);
                    throw new RuntimeException("Migratie $name mislukt bij statement " . ($i + 1) . " (MySQL-fout $code). Er is niets meer uitgevoerd; herstel eventueel met de back-up.");
                }
            }
            $pdo->prepare('INSERT INTO schema_migrations (name, checksum) VALUES (?, ?)')->execute([$name, hash('sha256', $sql)]);
            $done[] = $name;
        }
        if ($done) { audit('system.migrate', $by, ['applied' => $done]); }
        return $done;
    } finally {
        $pdo->query("SELECT RELEASE_LOCK('ss_migrate')");
    }
}

/** Verse installatie: schema.sql is de actuele situatie, dus alles wat er aan migraties ligt telt als toegepast. */
function migrate_mark_all_applied(?string $dir = null): int
{
    migrate_ensure_table();
    $n = 0;
    $ins = db()->prepare('INSERT IGNORE INTO schema_migrations (name, checksum) VALUES (?, ?)');
    foreach (migrate_files($dir) as $name => $path) { $ins->execute([$name, hash_file('sha256', $path)]); $n++; }
    return $n;
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/migrate.php                                      ║
// ║  Role    : Core                                                      ║
// ║  Version : 0.12.0                                                    ║
// ║  Updated : 2026-10-01                                                ║
// ║  Notes   : schema_migrations, idempotent, stopt bij echte fout       ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
