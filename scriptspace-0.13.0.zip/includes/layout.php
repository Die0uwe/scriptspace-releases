<?php
// includes/layout.php — eenvoudige gedeelde pagina-opmaak voor auth/admin/user-pagina's.
declare(strict_types=1);

function page_header(string $title, string $root = ''): void
{
    $u = function_exists('current_user') ? current_user() : null;
    ?><!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title) ?> — scriptspace.nl</title>
<link rel="icon" href="<?= e($root) ?>weblogo.png" type="image/png">
<style>
:root{--bg:#0b0d14;--card:#141726;--border:rgba(255,255,255,.1);--text:#e2e8f0;--muted:#94a3b8;--accent:#8b5cf6;--danger:#ef4444;--ok:#22c55e}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:system-ui,sans-serif;min-height:100vh}
header.top{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px 16px;padding:12px 24px;border-bottom:1px solid var(--border)}
header.top nav{display:flex;flex-wrap:wrap;align-items:center;gap:4px 0}
header.top a{color:var(--text);text-decoration:none;margin-left:16px;font-size:.9rem}
header.top .brand{font-weight:700;margin-left:0}header.top .brand span{color:var(--accent)}
main{max-width:1100px;margin:24px auto;padding:0 16px}
main,.card,p,li,label,h1,h2{overflow-wrap:break-word}
a{color:#a78bfa}td.brk,td small{overflow-wrap:anywhere}td.brk{min-width:200px}th,td{overflow-wrap:normal}td:nth-child(-n+2){white-space:nowrap}
nav.subnav{display:flex;flex-wrap:wrap;gap:6px;margin:0 0 16px}nav.subnav a{color:var(--muted);text-decoration:none;padding:7px 13px;border:1px solid var(--border);border-radius:8px;font-size:.88rem}nav.subnav a:hover{color:var(--text)}nav.subnav a.on{background:var(--accent);border-color:var(--accent);color:#fff}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:20px;min-width:0;overflow-x:auto}
@media(max-width:600px){.card{padding:16px}main{margin-top:16px}}
.card.narrow{max-width:420px;margin:48px auto}
h1,h2{margin-top:0}label{display:block;font-size:.85rem;color:var(--muted);margin:12px 0 4px}
input[type=text],input[type=email],input[type=password]{width:100%;padding:10px;border-radius:8px;border:1px solid var(--border);background:rgba(0,0,0,.3);color:#fff}
button,.btn{background:var(--accent);color:#fff;border:0;border-radius:8px;padding:10px 16px;cursor:pointer;font-size:.9rem;text-decoration:none;display:inline-block;margin-top:16px}
.btn.ghost{background:transparent;border:1px solid var(--border)}
.msg{padding:10px 12px;border-radius:8px;margin-bottom:12px;font-size:.9rem}.msg.err{background:rgba(239,68,68,.15);border:1px solid var(--danger)}.msg.ok{background:rgba(34,197,94,.15);border:1px solid var(--ok)}
table{width:100%;border-collapse:collapse;font-size:.88rem}th,td{text-align:left;padding:8px;border-bottom:1px solid var(--border);vertical-align:top}th{color:var(--muted);font-weight:600}
.card>table{min-width:640px}td small{display:block;max-width:340px;font-family:ui-monospace,monospace;font-size:.76rem}
select,input[type=file]{max-width:100%;padding:9px;background:#000;color:#fff;border:1px solid var(--border);border-radius:8px}
.row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.row>input{flex:1 1 200px;min-width:0}
.badge{display:inline-block;padding:2px 9px;border-radius:99px;font-size:.75rem;border:1px solid var(--border);color:var(--muted);white-space:nowrap}.badge.ok{color:var(--ok);border-color:var(--ok)}.badge.warn{color:#f59e0b;border-color:#f59e0b}
pre,code{overflow-wrap:anywhere;white-space:pre-wrap}
.hp{position:absolute;left:-9999px}small,.muted{color:var(--muted)}
</style>
</head>
<body>
<header class="top">
  <a class="brand" href="<?= e($root) ?>index.php">⚡ script<span>space</span>.nl</a>
  <nav>
  <?php if ($u): ?>
    <a href="<?= e($root) ?>user/dashboard.php">Dashboard</a>
    <?php if (can('admin.access')): ?><a href="<?= e($root) ?>admin/index.php">Admin</a><?php endif; ?>
    <form method="post" action="<?= e($root) ?>logout.php" style="display:inline;margin-left:16px"><?= csrf_field() ?><button type="submit" style="background:none;border:0;color:var(--text);cursor:pointer;font-size:.9rem;margin:0;padding:0"><?= e($u['username']) ?> · Uitloggen</button></form>
  <?php else: ?>
    <a href="<?= e($root) ?>login.php">Inloggen</a><a href="<?= e($root) ?>register.php">Registreren</a>
  <?php endif; ?>
  </nav>
</header>
<main>
<?php
    if (str_contains($_SERVER['SCRIPT_NAME'] ?? '', '/admin/') && function_exists('can') && can('admin.access')) { admin_subnav(); }
}

/** Tabbalk bovenaan alle beheerpagina's. */
function admin_subnav(): void
{
    $cur = basename($_SERVER['SCRIPT_NAME'] ?? '');
    $items = ['index.php' => ['Overzicht', 'admin.access'], 'users_manage.php' => ['Gebruikers', 'users.manage'], 'logs.php' => ['Logs', 'logs.view'],
              'system_cleanup.php' => ['Opschonen', 'cleanup.run'], 'backup_manage.php' => ['Back-up', 'backup.manage'], 'connections.php' => ['Verbindingen', 'system.test'], 'updates.php' => ['Updates', 'system.update']];
    echo '<nav class="subnav">';
    foreach ($items as $f => [$l, $perm]) {
        if (!can($perm)) { continue; }
        $on = $cur === $f || ($cur === 'user_edit.php' && $f === 'users_manage.php');
        echo '<a href="' . e($f) . '"' . ($on ? ' class="on"' : '') . '>' . e($l) . '</a>';
    }
    echo "</nav>\n";
}

function page_footer(): void
{
    echo "</main>\n</body>\n</html>\n";
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/layout.php                                       ║
// ║  Role    : View                                                      ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Gedeelde pagina-opmaak                                    ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
