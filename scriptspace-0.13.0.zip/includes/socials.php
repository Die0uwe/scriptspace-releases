<?php
// includes/socials.php — register van socials en profiel-links. Nieuwe service toevoegen = één regel in SOCIAL_SERVICES.
//   kind 'link' : gebruiker vult een profiel in (niet geverifieerd). 'hosts' = toegestane domeinen, 'url' = sjabloon voor een kale @naam.
// Inloggen/koppelen met verificatie (OAuth) staat in includes/oauth.php (OAUTH_DEFS).
declare(strict_types=1);

const SOCIAL_SERVICES = [
    'youtube'   => ['label' => 'YouTube',   'color' => '#ff0033', 'hosts' => ['youtube.com', 'youtu.be'],     'url' => 'https://www.youtube.com/@{h}',   'ph' => '@jouwkanaal of kanaal-URL'],
    'facebook'  => ['label' => 'Facebook',  'color' => '#1877f2', 'hosts' => ['facebook.com', 'fb.com'],      'url' => 'https://www.facebook.com/{h}',   'ph' => 'paginanaam of profiel-URL'],
    'instagram' => ['label' => 'Instagram', 'color' => '#e1306c', 'hosts' => ['instagram.com'],               'url' => 'https://www.instagram.com/{h}',  'ph' => '@jouwnaam'],
    'x'         => ['label' => 'X',         'color' => '#000000', 'hosts' => ['x.com', 'twitter.com'],        'url' => 'https://x.com/{h}',              'ph' => '@jouwnaam'],
    'twitch'    => ['label' => 'Twitch',    'color' => '#9146ff', 'hosts' => ['twitch.tv'],                   'url' => 'https://www.twitch.tv/{h}',      'ph' => 'kanaalnaam'],
    'tiktok'    => ['label' => 'TikTok',    'color' => '#010101', 'hosts' => ['tiktok.com'],                  'url' => 'https://www.tiktok.com/@{h}',    'ph' => '@jouwnaam'],
    'linkedin'  => ['label' => 'LinkedIn',  'color' => '#0a66c2', 'hosts' => ['linkedin.com'],                'url' => 'https://www.linkedin.com/in/{h}', 'ph' => 'profielnaam of URL'],
    'website'   => ['label' => 'Website',   'color' => '#475569', 'hosts' => [],                              'url' => '',                               'ph' => 'https://jouwsite.nl'],
];

/** Valideert en normaliseert een ingevulde profiel-link. Geeft [handle, url, foutmelding]. */
function social_normalize(string $service, string $input): array
{
    $def = SOCIAL_SERVICES[$service] ?? null;
    $input = trim($input);
    if (!$def) { return ['', '', 'Onbekende service.']; }
    if ($input === '' || mb_strlen($input) > 200) { return ['', '', 'Vul een geldige naam of URL in (max. 200 tekens).']; }
    if (preg_match('/[\x00-\x20<>"\'`\\\\]/', $input) && !preg_match('#^https?://[^\s]+$#i', $input)) { return ['', '', 'Ongeldige tekens.']; }

    if (preg_match('#^https?://#i', $input) || ($service === 'website' && str_contains($input, '.'))) {
        $url = preg_match('#^https?://#i', $input) ? $input : 'https://' . $input;
        $p = parse_url($url);
        $host = strtolower((string)($p['host'] ?? ''));
        if (!$p || !in_array(strtolower((string)($p['scheme'] ?? '')), ['http', 'https'], true) || $host === '' || isset($p['user']) || isset($p['pass'])) { return ['', '', 'Ongeldige URL.']; }
        if (!preg_match('/^[a-z0-9.-]+$/', $host) || !str_contains($host, '.')) { return ['', '', 'Ongeldige URL.']; }
        if ($def['hosts']) {
            $okHost = false;
            foreach ($def['hosts'] as $h) { if ($host === $h || str_ends_with($host, '.' . $h)) { $okHost = true; } }
            if (!$okHost) { return ['', '', 'Dit is geen ' . $def['label'] . '-adres (verwacht ' . $def['hosts'][0] . ').']; }
        }
        $path = (string)($p['path'] ?? '');
        if (preg_match('/[\x00-\x20<>"\'`\\\\]/', $path)) { return ['', '', 'Ongeldige URL.']; }
        $clean = 'https://' . $host . (isset($p['port']) && !in_array((int)$p['port'], [80, 443], true) ? ':' . (int)$p['port'] : '') . rtrim($path, '/');
        if (strlen($clean) > 255) { return ['', '', 'URL is te lang.']; }
        $handle = trim(basename($path), '/') ?: $host;
        return [mb_substr($handle, 0, 100), $clean, ''];
    }
    if ($service === 'website') { return ['', '', 'Vul een URL in, bijvoorbeeld https://jouwsite.nl']; }
    $h = ltrim($input, '@');
    if (!preg_match('/^[A-Za-z0-9._-]{2,60}$/', $h)) { return ['', '', 'Een naam mag letters, cijfers, punt, streepje en underscore bevatten (2–60 tekens).']; }
    return ['@' . $h, str_replace('{h}', rawurlencode($h), $def['url']), ''];
}

/** Alle links van één gebruiker, per service. */
function social_links_of(int $userId): array
{
    $st = db()->prepare('SELECT service, handle, url FROM social_links WHERE user_id = ?');
    $st->execute([$userId]);
    $out = [];
    foreach ($st->fetchAll() as $r) { $out[$r['service']] = $r; }
    return $out;
}

/** Gekoppelde OAuth-accounts van één gebruiker, per provider. */
function identities_of(int $userId): array
{
    $st = db()->prepare('SELECT provider, display_name, email, created_at FROM oauth_identities WHERE user_id = ?');
    $st->execute([$userId]);
    $out = [];
    foreach ($st->fetchAll() as $r) { $out[$r['provider']] = $r; }
    return $out;
}

/** Kleine gekleurde label-chips, bijv. voor de gebruikerslijst. */
function provider_chips(array $identities, array $links): string
{
    $colors = ['github' => '#24292e', 'google' => '#db4437', 'discord' => '#5865F2', 'facebook' => '#1877f2'];
    $labels = ['github' => 'GitHub', 'google' => 'Google', 'discord' => 'Discord', 'facebook' => 'Facebook'];
    $h = '';
    foreach ($identities as $k => $_) { $h .= '<span class="badge ok" title="Inloggen gekoppeld" style="border-color:' . ($colors[$k] ?? '#64748b') . '">' . e($labels[$k] ?? $k) . '</span> '; }
    foreach ($links as $k => $_) { $h .= '<span class="badge" title="Profiel-link (niet geverifieerd)">' . e(SOCIAL_SERVICES[$k]['label'] ?? $k) . '</span> '; }
    return $h !== '' ? $h : '<span class="muted">—</span>';
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/socials.php                                      ║
// ║  Role    : Core                                                      ║
// ║  Version : 1.0.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Register socials + validatie profiel-links                ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
