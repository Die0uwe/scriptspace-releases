<?php
// includes/ai.php — gedeelde AI-logica voor api/ai_chat.php (antwoord in één keer) en api/ai_stream.php (streaming).
// De key van de gebruiker wordt server-side ontsleuteld en nooit naar de browser gestuurd.
declare(strict_types=1);
require_once __DIR__ . '/api.php';
require_once __DIR__ . '/crypto.php';

const AI_MODELS = [
    'deepseek-chat'     => ['provider' => 'deepseek', 'api_model' => 'deepseek-chat'],
    'deepseek-reasoner' => ['provider' => 'deepseek', 'api_model' => 'deepseek-reasoner'],
    'gemini-2.5-flash'  => ['provider' => 'gemini',   'api_model' => 'gemini-2.5-flash'],
];
const AI_MAX_PROMPT  = 4000;
const AI_MAX_CODE    = 30000;
const AI_MAX_HISTORY = 6;
const AI_PER_HOUR    = 40;

/**
 * Valideert het verzoek, past de uurlimiet toe, haalt de key op en bouwt de context.
 * Alle fouten komen als JSON (api_error) en dus vóór een eventuele stream.
 */
function ai_prepare(array $u, array $in): array
{
    $prompt = trim((string)($in['prompt'] ?? ''));
    $model  = (string)($in['model'] ?? 'deepseek-chat');
    if ($prompt === '') { api_error('Geen bericht ontvangen.', 422); }
    if (mb_strlen($prompt) > AI_MAX_PROMPT) { api_error('Bericht te lang (max ' . AI_MAX_PROMPT . ' tekens).', 413); }
    if (!isset(AI_MODELS[$model])) { api_error('Onbekend model.', 422); }
    $provider = AI_MODELS[$model]['provider'];

    $st = db()->prepare("SELECT COUNT(*) FROM audit_log WHERE user_id = ? AND action = 'ai.chat' AND created_at > (NOW() - INTERVAL 1 HOUR)");
    $st->execute([$u['id']]);
    if ((int)$st->fetchColumn() >= AI_PER_HOUR) { api_error('Limiet bereikt: maximaal ' . AI_PER_HOUR . ' AI-berichten per uur.', 429); }

    $st = db()->prepare('SELECT key_enc FROM api_keys WHERE user_id = ? AND provider = ?');
    $st->execute([$u['id'], $provider]);
    $enc = $st->fetchColumn();
    if ($enc === false) { api_error('Geen ' . ucfirst($provider) . '-key opgeslagen. Voeg je eigen key toe bij Instellingen.', 422); }
    try { $apiKey = crypto_decrypt((string)$enc); } catch (Throwable $e) { api_error('De server kan keys niet ontsleutelen (app_key).', 500); }
    if ($apiKey === '') { api_error('Opgeslagen key is onleesbaar. Sla je key opnieuw op.', 422); }

    $system = "Je bent de AI-assistent van ScriptSpace, een webdesign- en code-playground. De gebruiker bewerkt losse HTML-, CSS- en JS-bestanden in een sandbox met live preview.\n"
            . "Antwoord kort, praktisch en in het Nederlands. Zet code altijd in fenced codeblocks met de taal erbij. Wijzig je een bestand, geef dan het HELE bestand terug zodat het direct kan worden toegepast.";
    $file = is_array($in['file'] ?? null) ? $in['file'] : null;
    if ($file && isset($file['name'], $file['content'])) {
        $code = mb_substr((string)$file['content'], 0, AI_MAX_CODE);
        $system .= "\n\nHuidig bestand in de editor: " . preg_replace('/[^A-Za-z0-9_.-]/', '', (string)$file['name']) . "\n```\n" . $code . "\n```";
    }
    $history = [];
    foreach (array_slice(is_array($in['history'] ?? null) ? $in['history'] : [], -AI_MAX_HISTORY) as $m) {
        if (is_array($m) && in_array($m['role'] ?? '', ['user', 'assistant'], true) && is_string($m['content'] ?? null)) {
            $history[] = ['role' => $m['role'], 'content' => mb_substr($m['content'], 0, AI_MAX_PROMPT)];
        }
    }
    audit('ai.chat', $u['id'], ['model' => $model, 'prompt_chars' => mb_strlen($prompt)]);
    return ['user' => $u, 'prompt' => $prompt, 'model' => $model, 'provider' => $provider, 'api_model' => AI_MODELS[$model]['api_model'],
            'key' => $apiKey, 'system' => $system, 'history' => $history];
}

/** Testantwoord (alleen met config 'ai_mock' => true): geen netwerkverkeer. */
function ai_mock_reply(string $prompt): string
{
    $long = str_contains($prompt, 'LANG') ? "\n\n```js\n" . implode("\n", array_map(fn($i) => "console.log('regel $i');", range(1, 30))) . "\n```\n" : '';
    return "Mock-antwoord op: " . $prompt . "\n\n```html\n<h1>Van de AI</h1>\n<p>Toegepast vanuit het antwoord.</p>\n```\n" . $long;
}

/** Verzoek-URL, headers en payload voor een provider. */
function ai_request(array $c, bool $stream): array
{
    if ($c['provider'] === 'deepseek') {
        $messages = array_merge([['role' => 'system', 'content' => $c['system']]], $c['history'], [['role' => 'user', 'content' => $c['prompt']]]);
        return ['https://api.deepseek.com/chat/completions', ['Authorization: Bearer ' . $c['key']],
                ['model' => $c['api_model'], 'messages' => $messages, 'temperature' => 0.7, 'stream' => $stream], 150];
    }
    $contents = [];
    foreach (array_merge($c['history'], [['role' => 'user', 'content' => $c['prompt']]]) as $m) {
        $contents[] = ['role' => $m['role'] === 'assistant' ? 'model' : 'user', 'parts' => [['text' => $m['content']]]];
    }
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $c['api_model'] . ($stream ? ':streamGenerateContent?alt=sse' : ':generateContent');
    return [$url, ['x-goog-api-key: ' . $c['key']], ['systemInstruction' => ['parts' => [['text' => $c['system']]]], 'contents' => $contents], 150];
}

function ai_curl(string $url, array $headers, array $payload, int $timeout): CurlHandle
{
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_FOLLOWLOCATION => false, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
        CURLOPT_HTTPHEADER => array_merge(['Content-Type: application/json'], $headers),
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
    ]);
    return $ch;
}

function ai_provider_error(string $provider, int $code, string $body): string
{
    $j = json_decode($body, true);
    if (is_array($j) && isset($j[0]['error'])) { $j = $j[0]; }
    $msg = is_array($j) ? (string)($j['error']['message'] ?? '') : '';
    return ucfirst($provider) . ': ' . ($msg !== '' ? substr($msg, 0, 300) : 'fout (HTTP ' . $code . ')');
}

/** Volledig antwoord in één keer. Gooit RuntimeException(message, httpcode) bij fouten. */
function ai_reply_blocking(array $c): string
{
    if (cfg('ai_mock', false)) { return ai_mock_reply($c['prompt']); }
    [$url, $headers, $payload, $timeout] = ai_request($c, false);
    $ch = ai_curl($url, $headers, $payload, $timeout);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $body = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    if ($body === false) { throw new RuntimeException('Verbinding met de AI-provider mislukt: ' . substr($err, 0, 120), 502); }
    $json = json_decode((string)$body, true);
    if (!is_array($json)) { throw new RuntimeException('Ongeldig antwoord van de AI-provider (HTTP ' . $code . ').', 502); }
    if (isset($json['error'])) { throw new RuntimeException(ai_provider_error($c['provider'], $code, (string)$body), $code >= 400 ? $code : 502); }
    $reply = $c['provider'] === 'deepseek' ? ($json['choices'][0]['message']['content'] ?? null) : ($json['candidates'][0]['content']['parts'][0]['text'] ?? null);
    if (!is_string($reply) || $reply === '') { throw new RuntimeException('Geen antwoord ontvangen van de AI-provider.', 502); }
    return $reply;
}

/** Haalt tekst en "denk"-signaal uit één SSE-datablok van de provider. */
function ai_sse_payload(string $provider, array $j): array
{
    if ($provider === 'deepseek') {
        $d = $j['choices'][0]['delta'] ?? [];
        return [(string)($d['content'] ?? ''), ((string)($d['reasoning_content'] ?? '')) !== ''];
    }
    $text = '';
    foreach ($j['candidates'][0]['content']['parts'] ?? [] as $p) { $text .= (string)($p['text'] ?? ''); }
    return [$text, false];
}

/**
 * Streamt het antwoord: roept $onDelta(string) per stukje tekst en $onThink() bij redeneer-tokens.
 * Geeft de volledige tekst terug. Gooit RuntimeException bij providerfouten of verbindingsproblemen.
 * $aborted: callable die true geeft als de browser is weggegaan.
 */
function ai_reply_stream(array $c, callable $onDelta, callable $onThink, callable $aborted): string
{
    if (cfg('ai_mock', false)) {
        $full = ai_mock_reply($c['prompt']);
        foreach (mb_str_split($full, 12) as $piece) {
            if ($aborted()) { break; }
            $onDelta($piece);
            usleep(10000);
        }
        return $full;
    }
    [$url, $headers, $payload, $timeout] = ai_request($c, true);
    $ch = ai_curl($url, $headers, $payload, $timeout);
    $buf = $full = $errBody = '';
    $curlError = null;
    curl_setopt($ch, CURLOPT_BUFFERSIZE, 2048);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array_merge(['Content-Type: application/json', 'Accept: text/event-stream'], $headers));
    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($ch, string $chunk) use (&$buf, &$full, &$errBody, $c, $onDelta, $onThink, $aborted): int {
        if ($aborted()) { return 0; }
        if ((int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE) >= 400) { $errBody .= substr($chunk, 0, 4096); return strlen($chunk); }
        $buf .= $chunk;
        while (($nl = strpos($buf, "\n")) !== false) {
            $line = rtrim(substr($buf, 0, $nl), "\r");
            $buf = substr($buf, $nl + 1);
            if (!str_starts_with($line, 'data:')) { continue; }
            $data = trim(substr($line, 5));
            if ($data === '' || $data === '[DONE]') { continue; }
            $j = json_decode($data, true);
            if (!is_array($j)) { continue; }
            [$text, $think] = ai_sse_payload($c['provider'], $j);
            if ($think) { $onThink(); }
            if ($text !== '') { $full .= $text; $onDelta($text); }
        }
        return strlen($chunk);
    });
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($aborted()) { return $full; }
    if ($code >= 400) { throw new RuntimeException(ai_provider_error($c['provider'], $code, $errBody), $code); }
    if ($full === '' && $err !== '') { throw new RuntimeException('Verbinding met de AI-provider mislukt: ' . substr($err, 0, 120), 502); }
    if ($full === '') { throw new RuntimeException('Geen antwoord ontvangen van de AI-provider.', 502); }
    return $full;
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/ai.php                                           ║
// ║  Role    : Core                                                      ║
// ║  Version : 0.8.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : AI-proxy gedeeld: volledig antwoord en streaming (SSE)    ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
