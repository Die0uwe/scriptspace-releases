<?php
// includes/accounts.php — twee ScriptSpace-accounts van dezelfde persoon samenvoegen.
// Het account dat je BEHOUDT ($keep) neemt de logins, rollen, sandboxes, API-sleutels en socials van het andere ($drop) over;
// $drop wordt daarna verwijderd. Conflicten (zelfde dienst al aanwezig) lossen we op door het behouden account te laten winnen.
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/rbac.php';

const MERGE_PROOF_SECONDS = 600;

/** Wat er bij het samenvoegen van $id zou verhuizen (voor de bevestigingspagina). */
function account_merge_preview(int $id): array
{
    $pdo = db();
    $one = static function (string $sql, array $p) use ($pdo) { $s = $pdo->prepare($sql); $s->execute($p); return $s; };
    $u = $one('SELECT id, username, email, created_at, last_login_at FROM users WHERE id = ?', [$id])->fetch() ?: [];
    $u['roles'] = array_column(user_roles($id), 'name');
    $u['providers'] = $one('SELECT provider FROM oauth_identities WHERE user_id = ? ORDER BY provider', [$id])->fetchAll(PDO::FETCH_COLUMN);
    $u['sandboxes'] = (int)$one('SELECT COUNT(*) FROM sandboxes WHERE user_id = ?', [$id])->fetchColumn();
    $u['socials'] = (int)$one('SELECT COUNT(*) FROM social_links WHERE user_id = ?', [$id])->fetchColumn();
    $u['keys'] = (int)$one('SELECT COUNT(*) FROM api_keys WHERE user_id = ?', [$id])->fetchColumn();
    return $u;
}

/** Mag $drop in $keep opgaan? Geeft een foutmelding of ''. */
function account_merge_check(int $keep, int $drop): string
{
    if ($keep === $drop) { return 'Dit is hetzelfde account.'; }
    $st = db()->prepare('SELECT id, is_active, email_verified_at, deleted_at FROM users WHERE id = ?');
    foreach ([$keep, $drop] as $id) {
        $st->execute([$id]);
        $r = $st->fetch();
        if (!$r || $r['deleted_at'] !== null) { return 'Een van de accounts bestaat niet (meer).'; }
        if (!(int)$r['is_active']) { return 'Een geblokkeerd account kan niet worden samengevoegd.'; }
        if ($r['email_verified_at'] === null) { return 'Beide accounts moeten een bevestigd e-mailadres hebben.'; }
    }
    return '';
}

/**
 * Voegt $drop samen in $keep, in één transactie. Gooit RuntimeException bij een fout (er is dan niets veranderd).
 * Geeft een samenvatting: ['identities','socials','keys','sandboxes','roles'] (aantallen die zijn verhuisd) + ['dropped'=>[username,email]].
 */
function account_merge(int $keep, int $drop): array
{
    $err = account_merge_check($keep, $drop);
    if ($err !== '') { throw new RuntimeException($err); }
    $pdo = db();
    $info = $pdo->prepare('SELECT username, email FROM users WHERE id = ?');
    $info->execute([$drop]);
    $gone = $info->fetch();
    $info->execute([$keep]);
    $kept = $info->fetch();
    $out = [];
    $pdo->beginTransaction();
    try {
        // inlogkoppelingen: per dienst houdt het behouden account zijn eigen koppeling
        $st = $pdo->prepare('UPDATE oauth_identities d SET d.user_id = ? WHERE d.user_id = ? AND NOT EXISTS (SELECT 1 FROM (SELECT provider FROM oauth_identities WHERE user_id = ?) k WHERE k.provider = d.provider)');
        $st->execute([$keep, $drop, $keep]);
        $out['identities'] = $st->rowCount();
        $st = $pdo->prepare('UPDATE social_links d SET d.user_id = ? WHERE d.user_id = ? AND NOT EXISTS (SELECT 1 FROM (SELECT service FROM social_links WHERE user_id = ?) k WHERE k.service = d.service)');
        $st->execute([$keep, $drop, $keep]);
        $out['socials'] = $st->rowCount();
        $st = $pdo->prepare('UPDATE api_keys d SET d.user_id = ? WHERE d.user_id = ? AND NOT EXISTS (SELECT 1 FROM (SELECT provider FROM api_keys WHERE user_id = ?) k WHERE k.provider = d.provider)');
        $st->execute([$keep, $drop, $keep]);
        $out['keys'] = $st->rowCount();
        $st = $pdo->prepare('UPDATE sandboxes SET user_id = ? WHERE user_id = ?');
        $st->execute([$keep, $drop]);
        $out['sandboxes'] = $st->rowCount();
        $st = $pdo->prepare('INSERT IGNORE INTO user_roles (user_id, role_id, assigned_by) SELECT ?, role_id, ? FROM user_roles WHERE user_id = ?');
        $st->execute([$keep, $keep, $drop]);
        $out['roles'] = $st->rowCount();
        // wat niet kon verhuizen (dubbele dienst) verdwijnt met het oude account via ON DELETE CASCADE
        $pdo->prepare('DELETE FROM users WHERE id = ?')->execute([$drop]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) { $pdo->rollBack(); }
        error_log('account_merge: ' . $e->getMessage());
        throw new RuntimeException('Samenvoegen mislukt; er is niets veranderd.');
    }
    user_roles($keep, true);
    $out['dropped'] = [(string)$gone['username'], (string)$gone['email']];
    audit('account.merged', $keep, ['dropped_id' => $drop, 'dropped_username' => $gone['username']] + array_diff_key($out, ['dropped' => 1]));
    // seintje naar beide adressen: een samenvoeging die je niet zelf deed, moet je kunnen opmerken
    foreach ([$kept['email'], $gone['email']] as $mail) {
        send_mail((string)$mail, 'Accounts samengevoegd op scriptspace.nl',
            "Het account '" . $gone['username'] . "' is samengevoegd met '" . $kept['username'] . "'. Inloggen kan voortaan met '" . $kept['username'] . "'.\nWas jij dit niet? Gebruik direct 'Wachtwoord vergeten' op " . cfg('app_url') . "/forgot.php en neem contact op met de beheerder.\n");
    }
    return $out;
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/accounts.php                                     ║
// ║  Role    : Auth                                                      ║
// ║  Version : 0.12.1                                                    ║
// ║  Updated : 2026-10-01                                                ║
// ║  Notes   : Accounts samenvoegen (logins, rollen, sandboxes, socials) ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
