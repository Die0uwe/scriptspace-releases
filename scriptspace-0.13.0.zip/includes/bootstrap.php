<?php
// includes/bootstrap.php — gedeelde basis: config, sessie, database, CSRF, logging, rate-limit.
declare(strict_types=1);

if (defined('SS_BOOTSTRAPPED')) { return; }
define('SS_BOOTSTRAPPED', true);
define('SS_ROOT', dirname(__DIR__));

function cfg(?string $key = null, $default = null)
{
    static $config = null;
    if ($config === null) {
        $file = SS_ROOT . '/config/config.php';
        if (!is_file($file)) {
            http_response_code(500);
            exit('Configuratie ontbreekt: kopieer config/config.example.php naar config/config.php.');
        }
        $config = require $file;
    }
    if ($key === null) { return $config; }
    $value = $config;
    foreach (explode('.', $key) as $part) {
        if (!is_array($value) || !array_key_exists($part, $value)) { return $default; }
        $value = $value[$part];
    }
    return $value;
}

// --- Onderhoudsmodus: tijdens een update bestaat storage/.maintenance (verloopt vanzelf na 'until'). Alleen een tijdelijke 503. ---
if (PHP_SAPI !== 'cli' && is_file(SS_ROOT . '/storage/.maintenance')) {
    $mt = json_decode((string)@file_get_contents(SS_ROOT . '/storage/.maintenance'), true);
    if (is_array($mt) && (int)($mt['until'] ?? 0) > time() && ($_SERVER['HTTP_X_SS_HEALTH'] ?? '') !== '1') {
        http_response_code(503);
        header('Retry-After: 120');
        header('Content-Type: text/html; charset=utf-8');
        exit('<!DOCTYPE html><html lang="nl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Even onderhoud</title><body style="font-family:system-ui,sans-serif;background:#0b0f19;color:#e6e9f2;display:grid;place-items:center;min-height:100vh;margin:0;text-align:center"><div><h1>Even onderhoud</h1><p>We werken de site bij. Probeer het over een paar minuten opnieuw.</p></div></body></html>');
    }
    if (!is_array($mt) || (int)($mt['until'] ?? 0) <= time()) { @unlink(SS_ROOT . '/storage/.maintenance'); }
}

// --- Fouten nooit aan bezoekers tonen (kunnen DB-gegevens of paden bevatten); wel loggen in storage/ ---
if (!cfg('debug', false)) {
    ini_set('display_errors', '0');
    ini_set('html_errors', '0');
    ini_set('zend.exception_ignore_args', '1');
}
ini_set('log_errors', '1');
ini_set('error_log', SS_ROOT . '/storage/php-error.log');
set_exception_handler(function (Throwable $e): void {
    error_log('Uncaught ' . get_class($e) . ': ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    if (!headers_sent()) { http_response_code(500); }
    if (cfg('debug', false)) { echo '<pre>' . htmlspecialchars((string)$e, ENT_QUOTES, 'UTF-8') . '</pre>'; return; }
    $api = str_contains((string)($_SERVER['SCRIPT_NAME'] ?? ''), '/api/');
    if ($api) { header('Content-Type: application/json; charset=utf-8'); echo '{"error":"Er ging iets mis op de server."}'; }
    else { echo 'Er ging iets mis op de server. Probeer het later opnieuw.'; }
});
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('X-Frame-Options: SAMEORIGIN');
    // De playground laat gebruikerscode in een afgeschermde iframe draaien (srcdoc erft de CSP) en krijgt daarom geen extra CSP.
    if (!defined('SS_NO_CSP')) { header("Content-Security-Policy: frame-ancestors 'self'; base-uri 'self'; form-action 'self'; object-src 'none'"); }
    if (cfg('hsts', false) && ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443'))) {
        header('Strict-Transport-Security: max-age=31536000');
    }
}

// --- Sessie met veilige cookie-instellingen ---
if (session_status() === PHP_SESSION_NONE) {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    session_name('ssid');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

// --- Database ---
function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $c = cfg('db');
        $dsn = 'mysql:host=' . $c['host'] . ';dbname=' . $c['name'] . ';charset=utf8mb4';
        $pdo = new PDO($dsn, $c['user'], $c['pass'], [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

// --- Helpers ---
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function client_ip(): string
{
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45);
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

// --- CSRF ---
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify(): bool
{
    $sent = (string)($_POST['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    return $sent !== '' && hash_equals(csrf_token(), $sent);
}

// --- Audit-log (zoals Blueprint: actie, gebruiker + snapshot van naam, JSON-context, IP) ---
function audit(string $action, ?int $userId = null, array $context = []): void
{
    try {
        $username = null;
        if ($userId !== null) {
            $st = db()->prepare('SELECT username FROM users WHERE id = ?');
            $st->execute([$userId]);
            $username = $st->fetchColumn() ?: null;
        }
        $st = db()->prepare('INSERT INTO audit_log (user_id, username, action, context, ip_address) VALUES (?, ?, ?, ?, ?)');
        $st->execute([
            $userId,
            $username,
            substr($action, 0, 100),
            $context !== [] ? json_encode($context, JSON_UNESCAPED_UNICODE) : null,
            client_ip(),
        ]);
    } catch (Throwable $ex) {
        // auditing mag de aanvraag nooit breken
    }
}

// --- Wachtwoorden: Argon2id (met terugval op de PHP-standaard als de hosting dat niet ondersteunt) ---
function password_algo(): string
{
    return defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_DEFAULT;
}

function password_opts(): array
{
    return password_algo() === PASSWORD_DEFAULT ? [] : ['memory_cost' => 65536, 'time_cost' => 4, 'threads' => 3];
}

function hash_password(string $plain): string
{
    return password_hash($plain, password_algo(), password_opts());
}

// --- Veilige redirect: alleen een pad op deze site (voorkomt open redirect) ---
function safe_redirect_target(?string $target, string $default): string
{
    if ($target === null || $target === '') { return $default; }
    if ($target[0] !== '/' || str_starts_with($target, '//') || str_contains($target, '\\') || preg_match('/[\x00-\x1f]/', $target)) {
        return $default;
    }
    return $target;
}

// --- Rate-limit voor inloggen ---
const SS_LOGIN_WINDOW_MIN = 15;
const SS_LOGIN_MAX_PER_IDENT = 5;
const SS_LOGIN_MAX_PER_IP = 20;

function login_blocked(string $ident): bool
{
    $ident = strtolower($ident);
    $pdo = db();
    $st = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE ident = ? AND created_at > (NOW() - INTERVAL ' . SS_LOGIN_WINDOW_MIN . ' MINUTE)');
    $st->execute([$ident]);
    if ((int)$st->fetchColumn() >= SS_LOGIN_MAX_PER_IDENT) { return true; }
    $st = $pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND created_at > (NOW() - INTERVAL ' . SS_LOGIN_WINDOW_MIN . ' MINUTE)');
    $st->execute([client_ip()]);
    return (int)$st->fetchColumn() >= SS_LOGIN_MAX_PER_IP;
}

function login_failed(string $ident): void
{
    $st = db()->prepare('INSERT INTO login_attempts (ident, ip) VALUES (?, ?)');
    $st->execute([strtolower($ident), client_ip()]);
}

function login_cleared(string $ident): void
{
    $st = db()->prepare('DELETE FROM login_attempts WHERE ident = ?');
    $st->execute([strtolower($ident)]);
}

// --- Captcha (Cloudflare Turnstile, uit als er geen secret is ingesteld) ---
function captcha_enabled(): bool
{
    return (string)cfg('turnstile.secret', '') !== '';
}

function captcha_widget(): string
{
    if (!captcha_enabled()) { return ''; }
    return '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>'
         . '<div class="cf-turnstile" data-sitekey="' . e(cfg('turnstile.site_key', '')) . '"></div>';
}

function captcha_ok(): bool
{
    if (!captcha_enabled()) { return true; }
    $response = (string)($_POST['cf-turnstile-response'] ?? '');
    if ($response === '') { return false; }
    $ch = curl_init('https://challenges.cloudflare.com/turnstile/v0/siteverify');
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_POSTFIELDS     => http_build_query([
            'secret'   => cfg('turnstile.secret'),
            'response' => $response,
            'remoteip' => client_ip(),
        ]),
    ]);
    $out = curl_exec($ch);
    curl_close($ch);
    $data = json_decode((string)$out, true);
    return is_array($data) && !empty($data['success']);
}

// --- Mail ---
function send_mail(string $to, string $subject, string $body, ?string &$how = null): bool
{
    if (cfg('mail_debug', false)) {
        $how = 'debug (naar storage/mail.log, er wordt niets verstuurd)';
        @file_put_contents(SS_ROOT . '/storage/mail.log', "TO: $to\nSUBJECT: $subject\n$body\n---\n", FILE_APPEND);
        return true;
    }
    $from = (string)cfg('mail_from', 'noreply@localhost');
    $smtp = cfg('smtp', []);
    if (is_array($smtp) && !empty($smtp['host'])) {
        $err = null;
        $ok = smtp_send($smtp, $from, $to, $subject, $body, $err);
        $how = 'SMTP via ' . $smtp['host'] . ($ok ? '' : ' — ' . $err);
        if (!$ok) { error_log('send_mail mislukt: ' . $how); }
        return $ok;
    }
    $how = 'PHP mail() (geen SMTP ingesteld)';
    $headers = "From: ScriptSpace <$from>\r\nContent-Type: text/plain; charset=UTF-8\r\nMIME-Version: 1.0";
    $ok = @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $headers);
    if (!$ok) { $how .= ' — mail() gaf false terug'; error_log('send_mail mislukt: ' . $how); }
    return $ok;
}

/**
 * Minimale SMTP-client (AUTH LOGIN) voor o.a. STRATO: smtp.strato.com, poort 465 (SSL) of 587 (STARTTLS).
 * Config: 'smtp' => ['host'=>..., 'port'=>465, 'secure'=>'ssl'|'tls', 'user'=>..., 'pass'=>...]
 */
function smtp_send(array $c, string $from, string $to, string $subject, string $body, ?string &$err = null): bool
{
    $clean = static fn(string $v): string => str_replace(["\r", "\n"], '', $v);
    $from = $clean($from); $to = $clean($to);
    if (!filter_var($to, FILTER_VALIDATE_EMAIL) || !filter_var($from, FILTER_VALIDATE_EMAIL)) { $err = 'Ongeldig afzender- of ontvangeradres.'; return false; }
    $host = (string)$c['host'];
    $port = (int)($c['port'] ?? 465);
    $secure = (string)($c['secure'] ?? ($port === 465 ? 'ssl' : 'tls'));
    $fp = @stream_socket_client(($secure === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port, $en, $es, 15);
    if (!$fp) { $err = "Geen verbinding met $host:$port ($secure): " . ($es ?: 'time-out'); return false; }
    stream_set_timeout($fp, 15);
    $last = '';
    $read = static function () use ($fp, &$last): string {
        $out = '';
        while (($line = fgets($fp, 515)) !== false) { $out .= $line; if (strlen($line) < 4 || $line[3] === ' ') { break; } }
        return $last = trim($out);
    };
    $cmd = static function (string $line, string $expect) use ($fp, $read): bool {
        fwrite($fp, $line . "\r\n");
        return str_starts_with($read(), $expect);
    };
    try {
        if (!str_starts_with($read(), '220')) { $err = 'Server begroet niet: ' . $last; return false; }
        $me = 'scriptspace';
        if (!$cmd("EHLO $me", '250')) { $err = 'EHLO geweigerd: ' . $last; return false; }
        if ($secure === 'tls') {
            if (!$cmd('STARTTLS', '220') || !@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) { $err = 'STARTTLS mislukt: ' . $last; return false; }
            if (!$cmd("EHLO $me", '250')) { $err = 'EHLO na STARTTLS geweigerd: ' . $last; return false; }
        }
        if (!empty($c['user'])) {
            if (!$cmd('AUTH LOGIN', '334') || !$cmd(base64_encode((string)$c['user']), '334') || !$cmd(base64_encode((string)($c['pass'] ?? '')), '235')) { $err = 'Inloggen bij de mailserver mislukt (gebruiker/wachtwoord?): ' . $last; return false; }
        }
        if (!$cmd("MAIL FROM:<$from>", '250')) { $err = 'Afzender geweigerd: ' . $last; return false; }
        if (!$cmd("RCPT TO:<$to>", '25')) { $err = 'Ontvanger geweigerd: ' . $last; return false; }
        if (!$cmd('DATA', '354')) { $err = 'DATA geweigerd: ' . $last; return false; }
        $msg = "From: ScriptSpace <$from>\r\nTo: <$to>\r\nSubject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n"
             . "Date: " . date('r') . "\r\nMIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n"
             . chunk_split(base64_encode($body));
        fwrite($fp, $msg . "\r\n.\r\n");
        $ok = str_starts_with($read(), '250');
        if (!$ok) { $err = 'Bericht niet geaccepteerd: ' . $last; }
        @fwrite($fp, "QUIT\r\n");
        return $ok;
    } finally {
        @fclose($fp);
    }
}

// --- Opschonen zonder cron: draait hoogstens elke 6 uur na een gewone paginaweergave (config: auto_cleanup_hours, 0 = uit) ---
if (PHP_SAPI !== 'cli' && ((int)cfg('auto_cleanup_hours', 6) > 0 || cfg('update_check', true))) {
    require_once __DIR__ . '/maintenance.php';
    auto_cleanup_register();
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/bootstrap.php                                    ║
// ║  Role    : Core                                                      ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Config, sessie, PDO, CSRF, audit, rate-limit, Argon2id, ca║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
