<?php
// includes/auth.php — toegangscontrole. Include bovenaan elke afgeschermde pagina.
// Model: gebruiker -> rollen (met priority) -> permissies (zie includes/rbac.php).
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/rbac.php';

function current_user(): ?array
{
    if (empty($_SESSION['user_id'])) { return null; }
    return ['id' => (int)$_SESSION['user_id'], 'username' => (string)($_SESSION['username'] ?? '')];
}

/** Heeft de ingelogde gebruiker deze permissie? */
function can(string $permission): bool
{
    $u = current_user();
    return $u !== null && user_can($u['id'], $permission);
}

function is_admin(): bool
{
    return can('admin.access');
}

function active_user(): ?array
{
    $u = current_user();
    if ($u === null) { return null; }
    $st = db()->prepare('SELECT username, UNIX_TIMESTAMP(password_changed_at) AS pw_at FROM users WHERE id = ? AND is_active = 1 AND deleted_at IS NULL AND email_verified_at IS NOT NULL');
    $st->execute([$u['id']]);
    $row = $st->fetch();
    if ($row === false) { return null; }
    // Sessies van vóór een wachtwoordwijziging zijn niet meer geldig
    if ($row['pw_at'] !== null && (int)$row['pw_at'] > (int)($_SESSION['login_time'] ?? 0)) { return null; }
    $u['username'] = (string)$row['username'];
    return $u;
}

function require_login(string $root = ''): array
{
    if (current_user() === null) {
        $target = ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET' ? '?redirect=' . urlencode((string)($_SERVER['REQUEST_URI'] ?? '')) : '';
        redirect($root . 'login.php' . $target);
    }
    $u = active_user();
    if ($u === null) {
        $_SESSION = [];
        session_destroy();
        redirect($root . 'login.php');
    }
    return $u;
}

/** Vereist een permissie; anders 403. */
function require_permission(string $permission, string $root = ''): array
{
    $u = require_login($root);
    if (!user_can($u['id'], $permission)) {
        http_response_code(403);
        exit('Toegang geweigerd: recht "' . htmlspecialchars($permission, ENT_QUOTES) . '" vereist.');
    }
    return $u;
}

/** Zet een nieuw wachtwoord: hash, tijdstempel (maakt oude sessies ongeldig), openstaande reset-links weg, mail naar de eigenaar. */
function set_user_password(int $userId, string $newPassword, string $how): void
{
    db()->prepare('UPDATE users SET password_hash = ?, password_changed_at = NOW(), password_set = 1 WHERE id = ?')->execute([hash_password($newPassword), $userId]);
    db()->prepare('DELETE FROM password_resets WHERE user_id = ?')->execute([$userId]);
    audit('auth.' . $how, $userId);
    $st = db()->prepare('SELECT username, email FROM users WHERE id = ?');
    $st->execute([$userId]);
    if ($u = $st->fetch()) {
        send_mail($u['email'], 'Je wachtwoord op scriptspace.nl is gewijzigd',
            "Hoi {$u['username']},\n\nJe wachtwoord is zojuist gewijzigd. Was jij dit niet? Gebruik dan direct 'Wachtwoord vergeten' op " . cfg('app_url') . "/forgot.php en neem contact op met de beheerder.\n");
    }
}

/** Geeft foutmeldingen voor een nieuw wachtwoord (leeg = goed). */
function password_problems(string $pass, string $pass2): array
{
    $e = [];
    if (mb_strlen($pass) < 10) { $e[] = 'Wachtwoord moet minimaal 10 tekens zijn.'; }
    if (strlen($pass) > 200) { $e[] = 'Wachtwoord is te lang.'; }
    if ($pass !== $pass2) { $e[] = 'Wachtwoorden komen niet overeen.'; }
    return $e;
}

function start_user_session(array $user): void
{
    session_regenerate_id(true); // voorkomt session fixation
    $_SESSION['user_id']    = (int)$user['id'];
    $_SESSION['username']   = $user['username'];
    $_SESSION['login_time'] = time();
    unset($_SESSION['csrf']);
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/auth.php                                         ║
// ║  Role    : Core                                                      ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Login-poort: require_login / require_permission / can     ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
