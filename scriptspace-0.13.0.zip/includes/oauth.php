<?php
// includes/oauth.php — inloggen met GitHub, Google en Discord (OAuth 2.0, authorization code + state).
// Geen wachtwoord nodig; een OAuth-account wordt gekoppeld aan een gewoon ScriptSpace-account met rollen en rechten.
// Koppelen aan een bestaand account gebeurt ALLEEN via een door de provider bevestigd e-mailadres.
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

const OAUTH_DEFS = [
    'github' => [
        'label' => 'GitHub', 'auth' => 'https://github.com/login/oauth/authorize', 'token' => 'https://github.com/login/oauth/access_token',
        'user' => 'https://api.github.com/user', 'emails' => 'https://api.github.com/user/emails', 'scope' => 'read:user user:email',
    ],
    'google' => [
        'label' => 'Google', 'auth' => 'https://accounts.google.com/o/oauth2/v2/auth', 'token' => 'https://oauth2.googleapis.com/token',
        'user' => 'https://openidconnect.googleapis.com/v1/userinfo', 'emails' => null, 'scope' => 'openid email profile',
    ],
    // Facebook kan een e-mailadres niet als bevestigd garanderen: alleen koppelen vanuit je account, daarna inloggen.
    'facebook' => [
        'label' => 'Facebook', 'auth' => 'https://www.facebook.com/v19.0/dialog/oauth', 'token' => 'https://graph.facebook.com/v19.0/oauth/access_token',
        'user' => 'https://graph.facebook.com/me?fields=id,name,email', 'emails' => null, 'scope' => 'public_profile email',
    ],
    'discord' => [
        'label' => 'Discord', 'auth' => 'https://discord.com/oauth2/authorize', 'token' => 'https://discord.com/api/oauth2/token',
        'user' => 'https://discord.com/api/users/@me', 'emails' => null, 'scope' => 'identify email',
    ],
];

/** Geconfigureerde providers: config 'oauth' => [naam => [client_id, client_secret]], met terugval op het oude config/oauth_config.php. */
function oauth_providers(): array
{
    $conf = cfg('oauth', []);
    $legacyFile = SS_ROOT . '/config/oauth_config.php';
    if (!$conf && is_file($legacyFile)) {
        if (!defined('OAUTH_PROVIDERS')) { require_once $legacyFile; }
        $conf = defined('OAUTH_PROVIDERS') && is_array(OAUTH_PROVIDERS) ? OAUTH_PROVIDERS : [];
    }
    $mock = (string)cfg('oauth_mock_base', '');
    $out = [];
    foreach (OAUTH_DEFS as $name => $def) {
        $c = is_array($conf[$name] ?? null) ? $conf[$name] : [];
        $id = (string)($c['client_id'] ?? '');
        $secret = (string)($c['client_secret'] ?? '');
        if ($id === '' || $secret === '' || str_starts_with($id, 'JOUW_')) { continue; }
        $p = $def + ['client_id' => $id, 'client_secret' => $secret];
        $p['redirect'] = (string)($c['redirect_uri'] ?? '') ?: rtrim((string)cfg('app_url'), '/') . '/login.php?provider=' . $name;
        if ($mock !== '') { foreach (['auth', 'token', 'user', 'emails'] as $k) { if ($p[$k]) { $p[$k] = $mock . '/' . $name . '/' . $k; } } }
        $out[$name] = $p;
    }
    return $out;
}

/** Knoppen "Inloggen met …" (leeg als er geen provider is ingesteld). */
function oauth_buttons(string $redirect = ''): string
{
    $colors = ['github' => '#24292e', 'google' => '#db4437', 'discord' => '#5865F2', 'facebook' => '#1877f2'];
    $h = '';
    foreach (oauth_providers() as $name => $p) {
        $href = 'login.php?provider=' . $name . ($redirect !== '' ? '&redirect=' . rawurlencode($redirect) : '');
        $h .= '<a class="btn oauth-btn" data-provider="' . e($name) . '" href="' . e($href) . '" style="background:' . $colors[$name] . ';color:#fff;text-decoration:none;text-align:center;flex:1;padding:9px;border-radius:8px;font-size:.85rem">' . e($p['label']) . '</a>';
    }
    return $h === '' ? '' : '<div style="margin:14px 0 4px"><p class="muted" style="margin:0 0 6px">Of log in met:</p><div style="display:flex;gap:6px">' . $h . '</div></div>';
}

function oauth_http(string $url, ?array $post, array $headers): array
{
    $mock = (string)cfg('oauth_mock_base', '') !== '';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_PROTOCOLS => $mock ? (CURLPROTO_HTTP | CURLPROTO_HTTPS) : CURLPROTO_HTTPS,
        CURLOPT_HTTPHEADER => array_merge(['Accept: application/json', 'User-Agent: ScriptSpace'], $headers),
    ]);
    if ($post !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post)); }
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    $json = is_string($body) ? json_decode($body, true) : null;
    return [$code, is_array($json) ? $json : null];
}

/** Te veel pogingen vanaf één IP? (30 per 10 minuten) */
function oauth_rate_limited(): bool
{
    $st = db()->prepare("SELECT COUNT(*) FROM audit_log WHERE action = 'auth.oauth_start' AND ip_address = ? AND created_at > (NOW() - INTERVAL 10 MINUTE)");
    $st->execute([client_ip()]);
    return (int)$st->fetchColumn() >= 30;
}

/** Stap 1: stuur de bezoeker naar de provider. */
function oauth_begin(string $name, string $redirect, string $intent = 'login'): void
{
    $p = oauth_providers()[$name];
    $_SESSION['oauth_state'] = bin2hex(random_bytes(16));
    $_SESSION['oauth_provider'] = $name;
    $_SESSION['oauth_redirect'] = $redirect;
    $_SESSION['oauth_intent'] = $intent;
    audit('auth.oauth_start', null, ['provider' => $name]);
    redirect($p['auth'] . '?' . http_build_query([
        'client_id' => $p['client_id'], 'redirect_uri' => $p['redirect'], 'response_type' => 'code',
        'scope' => $p['scope'], 'state' => $_SESSION['oauth_state'],
    ]));
}

/** Stap 2: code omwisselen en profiel ophalen. Geeft [profiel|null, foutmelding]. */
function oauth_profile(string $name, string $code, string $state): array
{
    $p = oauth_providers()[$name];
    $expected = (string)($_SESSION['oauth_state'] ?? '');
    $sameProvider = ($_SESSION['oauth_provider'] ?? '') === $name;
    unset($_SESSION['oauth_state'], $_SESSION['oauth_provider']);
    if ($expected === '' || !$sameProvider || !hash_equals($expected, $state)) { return [null, 'Ongeldige of verlopen inlogpoging. Probeer het opnieuw.']; }

    [$c, $tok] = oauth_http($p['token'], [
        'client_id' => $p['client_id'], 'client_secret' => $p['client_secret'], 'code' => $code,
        'redirect_uri' => $p['redirect'], 'grant_type' => 'authorization_code',
    ], []);
    $access = is_array($tok) ? (string)($tok['access_token'] ?? '') : '';
    if ($access === '') { return [null, 'Inloggen via ' . $p['label'] . ' is mislukt (geen toegangstoken).']; }
    $auth = ['Authorization: Bearer ' . $access];
    [$c, $u] = oauth_http($p['user'], null, $auth);
    if (!$u) { return [null, 'Kon je gegevens niet ophalen bij ' . $p['label'] . '.']; }

    $email = ''; $verified = false; $uid = ''; $display = '';
    if ($name === 'github') {
        $uid = (string)($u['id'] ?? ''); $display = (string)($u['login'] ?? '');
        [$c2, $mails] = oauth_http((string)$p['emails'], null, $auth);
        foreach (is_array($mails) ? $mails : [] as $m) {
            if (is_array($m) && !empty($m['primary']) && !empty($m['verified']) && !empty($m['email'])) { $email = (string)$m['email']; $verified = true; break; }
        }
    } elseif ($name === 'google') {
        $uid = (string)($u['sub'] ?? ''); $display = (string)($u['name'] ?? '');
        $email = (string)($u['email'] ?? ''); $verified = ($u['email_verified'] ?? false) === true;
    } elseif ($name === 'facebook') {
        $uid = (string)($u['id'] ?? ''); $display = (string)($u['name'] ?? '');
        $email = (string)($u['email'] ?? ''); $verified = false; // nooit als bevestigd behandelen
    } else {
        $uid = (string)($u['id'] ?? ''); $display = (string)($u['username'] ?? '');
        $email = (string)($u['email'] ?? ''); $verified = ($u['verified'] ?? false) === true;
    }
    if ($uid === '') { return [null, 'Onverwacht antwoord van ' . $p['label'] . '.']; }
    return [['uid' => $uid, 'email' => strtolower(trim($email)), 'verified' => $verified && filter_var($email, FILTER_VALIDATE_EMAIL), 'display' => $display], ''];
}

/** Maakt een vrije gebruikersnaam (3–24 tekens, A-Z a-z 0-9 _). */
function oauth_free_username(string $wish, string $email): string
{
    $base = preg_replace('/[^A-Za-z0-9_]/', '', str_replace(' ', '_', $wish)) ?: preg_replace('/[^A-Za-z0-9_]/', '', strstr($email, '@', true) ?: 'gebruiker');
    $base = substr($base !== '' ? $base : 'gebruiker', 0, 18);
    if (strlen($base) < 3) { $base = str_pad($base, 3, '_'); }
    $st = db()->prepare('SELECT 1 FROM users WHERE username = ?');
    for ($i = 0; $i < 30; $i++) {
        $cand = $i === 0 ? $base : $base . random_int(10, 99999);
        $st->execute([substr($cand, 0, 24)]);
        if (!$st->fetchColumn()) { return substr($cand, 0, 24); }
    }
    return 'user' . bin2hex(random_bytes(6));
}

/** Koppelt een OAuth-identiteit aan een ingelogde gebruiker. Geeft een foutmelding of '' bij succes. */
function oauth_link_to_user(int $userId, string $name, array $prof): string
{
    $pdo = db();
    $st = $pdo->prepare('SELECT user_id FROM oauth_identities WHERE provider = ? AND provider_uid = ?');
    $st->execute([$name, $prof['uid']]);
    $owner = $st->fetchColumn();
    if ($owner !== false) {
        return (int)$owner === $userId ? '' : 'Dit ' . OAUTH_DEFS[$name]['label'] . '-account is al gekoppeld aan een ander ScriptSpace-account.';
    }
    $st = $pdo->prepare('SELECT COUNT(*) FROM oauth_identities WHERE user_id = ? AND provider = ?');
    $st->execute([$userId, $name]);
    if ((int)$st->fetchColumn() > 0) { return 'Je hebt al een ' . OAUTH_DEFS[$name]['label'] . '-account gekoppeld. Ontkoppel dat eerst.'; }
    $pdo->prepare('INSERT INTO oauth_identities (user_id, provider, provider_uid, email, display_name) VALUES (?, ?, ?, ?, ?)')
        ->execute([$userId, $name, $prof['uid'], $prof['email'] ?: null, mb_substr($prof['display'], 0, 100)]);
    audit('auth.oauth_connect', $userId, ['provider' => $name]);
    return '';
}

/** Mag deze gebruiker een inlogmethode verwijderen? Alleen als er nog een andere (wachtwoord of andere provider) overblijft. */
function oauth_can_unlink(int $userId): bool
{
    $st = db()->prepare('SELECT password_set FROM users WHERE id = ?');
    $st->execute([$userId]);
    if ((int)$st->fetchColumn() === 1) { return true; }
    $st = db()->prepare('SELECT COUNT(*) FROM oauth_identities WHERE user_id = ?');
    $st->execute([$userId]);
    return (int)$st->fetchColumn() > 1;
}

/** Stap 3: zoek, koppel of maak het account. Geeft [gebruikersrij|null, foutmelding]. */
function oauth_resolve_user(string $name, array $prof): array
{
    $pdo = db();
    $st = $pdo->prepare('SELECT u.* FROM oauth_identities i JOIN users u ON u.id = i.user_id WHERE i.provider = ? AND i.provider_uid = ? AND u.deleted_at IS NULL');
    $st->execute([$name, $prof['uid']]);
    $user = $st->fetch();
    if ($user) {
        $pdo->prepare('UPDATE oauth_identities SET display_name = ? WHERE provider = ? AND provider_uid = ?')->execute([mb_substr($prof['display'], 0, 100), $name, $prof['uid']]);
        return [$user, ''];
    }

    if ($name === 'facebook') { return [null, 'Koppel Facebook eerst vanuit je account (Account, Gekoppelde accounts). Daarna kun je er mee inloggen.']; }
    if (!$prof['verified']) { return [null, 'Dit account heeft geen bevestigd e-mailadres bij de provider. Bevestig het daar eerst of registreer met e-mail en wachtwoord.']; }

    $st = $pdo->prepare('SELECT * FROM users WHERE email = ? AND deleted_at IS NULL');
    $st->execute([$prof['email']]);
    $user = $st->fetch();
    $link = $pdo->prepare('INSERT INTO oauth_identities (user_id, provider, provider_uid, email, display_name) VALUES (?, ?, ?, ?, ?)');
    if ($user && $user['email_verified_at'] === null) {
        // Pre-hijack: iemand kan dit adres hebben aangemeld zonder het te bezitten, met een eigen wachtwoord.
        // Een ONBEVESTIGD account wordt daarom nooit overgenomen of gekoppeld: de rij (met wachtwoord, tokens,
        // rollen en koppelingen, via CASCADE) wordt verwijderd en de echte eigenaar krijgt hieronder een nieuw account.
        if (!cfg('registration_open', true)) { return [null, 'Registreren is momenteel gesloten.']; }
        audit('auth.oauth_unverified_replaced', (int)$user['id'], ['provider' => $name, 'username' => $user['username']]);
        $pdo->prepare('DELETE FROM users WHERE id = ? AND email_verified_at IS NULL')->execute([$user['id']]);
        $user = false;
    }
    if ($user) {
        $link->execute([$user['id'], $name, $prof['uid'], $prof['email'], mb_substr($prof['display'], 0, 100)]);
        audit('auth.oauth_linked', (int)$user['id'], ['provider' => $name]);
        return [$user, ''];
    }

    if (!cfg('registration_open', true)) { return [null, 'Registreren is momenteel gesloten.']; }
    for ($try = 0; $try < 3; $try++) {
        try {
            $username = oauth_free_username($prof['display'], $prof['email']);
            $pdo->beginTransaction();
            $pdo->prepare('INSERT INTO users (username, email, password_hash, display_name, is_active, email_verified_at, password_set) VALUES (?, ?, ?, ?, 1, NOW(), 0)')
                ->execute([$username, $prof['email'], hash_password(bin2hex(random_bytes(24))), $prof['display'] !== '' ? mb_substr($prof['display'], 0, 100) : $username]);
            $uid = (int)$pdo->lastInsertId();
            $link->execute([$uid, $name, $prof['uid'], $prof['email'], mb_substr($prof['display'], 0, 100)]);
            assign_default_role($uid);
            $pdo->commit();
            audit('auth.oauth_register', $uid, ['provider' => $name]);
            $st = $pdo->prepare('SELECT * FROM users WHERE id = ?');
            $st->execute([$uid]);
            return [$st->fetch(), ''];
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
        }
    }
    return [null, 'Account aanmaken mislukt. Probeer het opnieuw.'];
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/oauth.php                                        ║
// ║  Role    : Auth                                                      ║
// ║  Version : 0.10.2                                                    ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : OAuth: GitHub, Google, Discord (state, verified e-mail)   ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
