<?php
// includes/crypto.php — AES-256-GCM voor gevoelige waarden (bijv. AI-keys per gebruiker).
// Sleutel: 'app_key' in config/config.php, formaat "base64:<32 bytes>". Genereren:
//   php -r "echo 'base64:'.base64_encode(random_bytes(32)).PHP_EOL;"
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

function crypto_key(): string
{
    $k = (string)cfg('app_key', '');
    if (!str_starts_with($k, 'base64:')) {
        throw new RuntimeException('app_key ontbreekt of heeft niet het formaat base64:... in config/config.php.');
    }
    $raw = base64_decode(substr($k, 7), true);
    if ($raw === false || strlen($raw) !== 32) {
        throw new RuntimeException('app_key moet 32 bytes zijn (base64).');
    }
    return $raw;
}

function crypto_encrypt(string $plain): string
{
    $iv = random_bytes(12);
    $tag = '';
    $enc = openssl_encrypt($plain, 'aes-256-gcm', crypto_key(), OPENSSL_RAW_DATA, $iv, $tag);
    if ($enc === false) { throw new RuntimeException('Encryptie mislukt.'); }
    return base64_encode($iv . $tag . $enc);
}

function crypto_decrypt(string $payload): string
{
    $raw = base64_decode($payload, true);
    if ($raw === false || strlen($raw) < 28) { return ''; }
    $out = openssl_decrypt(substr($raw, 28), 'aes-256-gcm', crypto_key(), OPENSSL_RAW_DATA, substr($raw, 0, 12), substr($raw, 12, 16));
    return $out === false ? '' : $out;
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/crypto.php                                       ║
// ║  Role    : Core                                                      ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : AES-256-GCM voor gevoelige waarden                        ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
