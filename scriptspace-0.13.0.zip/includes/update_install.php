<?php
// includes/update_install.php — veilig installeren van een ondertekende release (0.13.0).
//
// Vertrouwen: alleen een release waarvan manifest.json een geldige Ed25519-handtekening heeft van de sleutel in
// includes/update_pubkey.php (of config 'update_pubkey'). GitHub zelf wordt NIET vertrouwd: het manifest bindt de zip
// (sha256) en elk bestand (sha256), dus een gehackt account of een onderschepte download kan niets installeren.
//
// Volgorde: voorwaarden -> slot -> downloaden -> handtekening + hashes -> veilig uitpakken naar staging -> PHP-syntaxcontrole ->
// DB-back-up + snapshot van wat vervangen wordt -> onderhoudsmodus -> bestanden vervangen (per bestand atomair) ->
// migraties -> health-check. Bij elke fout na het begin van het vervangen: automatisch terugzetten uit de snapshot.
// Alles werkt op $ctx['root'] (standaard de site) zodat het volledig te testen is op een nagebootste site.
declare(strict_types=1);
require_once __DIR__ . '/updater.php';

const UPD_MAX_MANIFEST = 1048576;       // 1 MB
const UPD_MAX_ZIP = 52428800;           // 50 MB
const UPD_MAX_UNPACKED = 209715200;     // 200 MB uitgepakt
const UPD_MAX_FILES = 5000;
const UPD_MAINT_SECONDS = 600;          // onderhoudsmodus verloopt zelf na 10 minuten
const UPD_PROTECTED_FILES = ['config/config.php', 'config/oauth_config.php', '.env'];
const UPD_PROTECTED_DIRS = ['storage/', 'sandboxes/', 'uploads/'];
const UPD_ENTRY_LAST = ['includes/bootstrap.php', 'index.php'];   // pas als laatste vervangen
const UPD_ALLOWED_EXT = ['php', 'css', 'js', 'json', 'md', 'txt', 'html', 'htm', 'sql', 'png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'ico', 'mp4', 'webm', 'woff', 'woff2', 'ttf', 'map'];
const UPD_ALLOWED_DOTFILES = ['.htaccess', '.gitkeep'];
const UPD_ALLOWED_PLAIN = ['LICENSE', 'VERSION'];

/** Publieke sleutel (base64, 32 bytes) uit config 'update_pubkey' of includes/update_pubkey.php; '' als er geen is. */
function upd_pubkey(): string
{
    $c = cfg('update_pubkey', '');
    if (is_string($c) && $c !== '') { return trim($c); }
    $f = __DIR__ . '/update_pubkey.php';
    $v = is_file($f) ? require $f : '';
    return is_string($v) ? trim($v) : '';
}

/** Genormaliseerd relatief pad of null als het onveilig is (.., absoluut, backslash, vreemde tekens). */
function upd_safe_rel(string $name): ?string
{
    if ($name === '' || strlen($name) > 200 || $name[0] === '/' || str_contains($name, "\0") || str_contains($name, '\\') || str_contains($name, '//')) { return null; }
    $name = rtrim($name, '/');
    foreach (explode('/', $name) as $seg) {
        if ($seg === '' || $seg === '.' || $seg === '..' || !preg_match('/^[A-Za-z0-9._-]+$/', $seg)) { return null; }
    }
    return $name;
}

function upd_protected(string $rel): bool
{
    if (in_array($rel, UPD_PROTECTED_FILES, true)) { return true; }
    foreach (UPD_PROTECTED_DIRS as $d) { if (str_starts_with($rel . '/', $d) || str_starts_with($rel, $d)) { return true; } }
    return false;
}

function upd_ext_ok(string $rel): bool
{
    $base = basename($rel);
    if (in_array($base, UPD_ALLOWED_DOTFILES, true) || in_array($base, UPD_ALLOWED_PLAIN, true)) { return true; }
    $ext = strtolower(pathinfo($base, PATHINFO_EXTENSION));
    return $ext !== '' && in_array($ext, UPD_ALLOWED_EXT, true) && $base[0] !== '.';
}

/** Controleert de handtekening en de vorm van het manifest. Gooit RuntimeException. Geeft het manifest als array. */
function upd_verify_manifest(string $manifest, string $sigB64, string $pubB64): array
{
    if (!function_exists('sodium_crypto_sign_verify_detached')) { throw new RuntimeException('De PHP-extensie sodium ontbreekt; handtekeningen kunnen niet worden gecontroleerd.'); }
    $pub = base64_decode($pubB64, true);
    if ($pub === false || strlen($pub) !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) { throw new RuntimeException('Er is geen geldige publieke sleutel ingesteld (includes/update_pubkey.php).'); }
    $sig = base64_decode(trim($sigB64), true);
    if ($sig === false || strlen($sig) !== SODIUM_CRYPTO_SIGN_BYTES) { throw new RuntimeException('De handtekening heeft een ongeldig formaat.'); }
    if (!sodium_crypto_sign_verify_detached($sig, $manifest, $pub)) { throw new RuntimeException('HANDTEKENING ONGELDIG: deze release is niet door jou ondertekend. Er is niets geïnstalleerd.'); }
    $m = json_decode($manifest, true);
    if (!is_array($m) || !isset($m['version'], $m['zip_sha256'], $m['zip_size'], $m['files']) || !is_array($m['files'])) { throw new RuntimeException('Het manifest is onvolledig.'); }
    if (update_normalize_tag((string)$m['version']) === null) { throw new RuntimeException('Het manifest heeft een ongeldige versie.'); }
    if (!preg_match('/^[a-f0-9]{64}$/', (string)$m['zip_sha256']) || !is_int($m['zip_size']) || $m['zip_size'] < 1 || $m['zip_size'] > UPD_MAX_ZIP) { throw new RuntimeException('Het manifest heeft een ongeldige zip-grootte of -controlesom.'); }
    if (count($m['files']) < 1 || count($m['files']) > UPD_MAX_FILES) { throw new RuntimeException('Het manifest bevat een onverwacht aantal bestanden.'); }
    foreach ($m['files'] as $p => $h) {
        if (!is_string($p) || upd_safe_rel($p) === null || $p !== upd_safe_rel($p) || !is_string($h) || !preg_match('/^[a-f0-9]{64}$/', $h)) { throw new RuntimeException('Het manifest bevat een ongeldig pad of controlesom.'); }
        if (!upd_ext_ok($p)) { throw new RuntimeException('Het manifest bevat een niet-toegestaan bestandstype: ' . $p); }
    }
    return $m;
}

/**
 * Pakt de zip veilig uit naar $stage en controleert elk bestand tegen het manifest.
 * Weigert: onveilige paden, symlinks, niet-toegestane extensies, bestanden buiten het manifest, te veel/te grote inhoud.
 */
function upd_extract(string $zipFile, string $stage, array $manifest): int
{
    if (!class_exists('ZipArchive')) { throw new RuntimeException('De PHP-extensie zip ontbreekt.'); }
    $zip = new ZipArchive();
    if ($zip->open($zipFile) !== true) { throw new RuntimeException('De zip is beschadigd of onleesbaar.'); }
    try {
        if ($zip->numFiles < 1 || $zip->numFiles > UPD_MAX_FILES + 500) { throw new RuntimeException('De zip bevat een onverwacht aantal onderdelen.'); }
        $total = 0; $seen = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $st = $zip->statIndex($i);
            $name = (string)$st['name'];
            $isDir = str_ends_with($name, '/');
            $rel = upd_safe_rel($name);
            if ($rel === null) { throw new RuntimeException('Onveilig pad in de zip geweigerd: ' . substr(preg_replace('/[^\x20-\x7e]/', '?', $name), 0, 80)); }
            $zip->getExternalAttributesIndex($i, $os, $attr);
            if ($os === ZipArchive::OPSYS_UNIX && ((($attr >> 16) & 0xF000) === 0xA000)) { throw new RuntimeException('Symlink in de zip geweigerd: ' . $rel); }
            if ($isDir) { continue; }
            if (!upd_ext_ok($rel)) { throw new RuntimeException('Bestandstype niet toegestaan in de zip: ' . $rel); }
            if (!isset($manifest['files'][$rel])) { throw new RuntimeException('Bestand in de zip dat niet in het ondertekende manifest staat: ' . $rel); }
            if (isset($seen[$rel])) { throw new RuntimeException('Dubbel bestand in de zip: ' . $rel); }
            $seen[$rel] = true;
            $size = (int)$st['size'];
            $total += $size;
            if ($total > UPD_MAX_UNPACKED) { throw new RuntimeException('De zip is uitgepakt te groot.'); }
            $dest = $stage . '/' . $rel;
            if (!is_dir(dirname($dest)) && !mkdir(dirname($dest), 0755, true)) { throw new RuntimeException('Staging-map aanmaken mislukt.'); }
            $in = $zip->getStream($name);
            $out = $in ? fopen($dest, 'wb') : false;
            if (!$in || !$out) { throw new RuntimeException('Uitpakken mislukt voor ' . $rel); }
            $written = stream_copy_to_stream($in, $out, $size + 1);
            fclose($in); fclose($out);
            if ($written !== $size) { throw new RuntimeException('Bestandsgrootte klopt niet: ' . $rel); }
            if (!hash_equals($manifest['files'][$rel], hash_file('sha256', $dest))) { throw new RuntimeException('Controlesom klopt niet voor ' . $rel . '. De release is aangepast na het ondertekenen.'); }
        }
        foreach ($manifest['files'] as $p => $h) {
            if (!isset($seen[$p])) { throw new RuntimeException('Bestand uit het manifest ontbreekt in de zip: ' . $p); }
        }
        return count($seen);
    } finally {
        $zip->close();
    }
}

/** PHP-syntaxcontrole van alle .php-bestanden in $stage zonder uit te voeren (token_get_all met TOKEN_PARSE). */
function upd_lint(string $stage, array $rels): void
{
    foreach ($rels as $rel) {
        if (strtolower(pathinfo($rel, PATHINFO_EXTENSION)) !== 'php') { continue; }
        try {
            token_get_all((string)file_get_contents($stage . '/' . $rel), TOKEN_PARSE);
        } catch (ParseError $e) {
            throw new RuntimeException('Syntaxfout in de nieuwe versie (' . $rel . ' regel ' . $e->getLine() . '). Er is niets veranderd.');
        }
    }
}

function upd_rrmdir(string $dir): void
{
    if (!is_dir($dir) || is_link($dir)) { return; }
    foreach (scandir($dir) ?: [] as $i) {
        if ($i === '.' || $i === '..') { continue; }
        $p = $dir . '/' . $i;
        (is_dir($p) && !is_link($p)) ? upd_rrmdir($p) : @unlink($p);
    }
    @rmdir($dir);
}

/** Schrijft $src naar $dest via een tijdelijk bestand in dezelfde map + rename (atomair per bestand). */
function upd_put(string $src, string $dest): void
{
    $dir = dirname($dest);
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) { throw new RuntimeException('Map aanmaken mislukt: ' . basename($dir)); }
    $tmp = $dir . '/.upd_' . bin2hex(random_bytes(4)) . '_' . basename($dest);
    if (!@copy($src, $tmp)) { @unlink($tmp); throw new RuntimeException('Schrijven mislukt (rechten?): ' . substr($dest, -60)); }
    @chmod($tmp, 0644);
    if (!@rename($tmp, $dest)) { @unlink($tmp); throw new RuntimeException('Vervangen mislukt (rechten?): ' . substr($dest, -60)); }
}

function upd_maint_on(string $root, int $seconds = UPD_MAINT_SECONDS): void
{
    @file_put_contents($root . '/storage/.maintenance', json_encode(['since' => time(), 'until' => time() + $seconds, 'why' => 'update']));
}
function upd_maint_off(string $root): void { @unlink($root . '/storage/.maintenance'); }

/** Zet bestanden terug uit een snapshot (storage/update/last_rollback of de lopende map). Geeft aantal bestanden. */
function upd_restore_snapshot(string $root, string $snapDir): int
{
    $meta = json_decode((string)@file_get_contents($snapDir . '/meta.json'), true);
    if (!is_array($meta)) { throw new RuntimeException('Geen geldige snapshot gevonden.'); }
    $n = 0;
    foreach ((array)($meta['replaced'] ?? []) as $rel) {
        $rel = upd_safe_rel((string)$rel);
        if ($rel === null || upd_protected($rel) || !is_file($snapDir . '/files/' . $rel)) { continue; }
        upd_put($snapDir . '/files/' . $rel, $root . '/' . $rel); $n++;
    }
    foreach ((array)($meta['created'] ?? []) as $rel) {
        $rel = upd_safe_rel((string)$rel);
        if ($rel === null || upd_protected($rel)) { continue; }
        if (is_file($root . '/' . $rel)) { @unlink($root . '/' . $rel); $n++; }
    }
    return $n;
}

/** Controleert of de nieuwe code werkt: login.php moet 200 geven en geen PHP-fout tonen. [ok, melding]. */
function upd_health_http(): array
{
    $url = rtrim((string)cfg('app_url', ''), '/') . '/login.php';
    if (!str_starts_with($url, 'https://') && !str_starts_with($url, 'http://')) { return [true, 'Health-check overgeslagen (app_url ontbreekt).']; }
    if (!function_exists('curl_init')) { return [true, 'Health-check overgeslagen (curl ontbreekt).']; }
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_FOLLOWLOCATION => false, CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS, CURLOPT_HTTPHEADER => ['X-SS-Health: 1']]);
    $body = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err = $body === false ? curl_error($ch) : '';
    curl_close($ch);
    if ($err !== '') { return [true, 'Health-check kon de eigen site niet bereiken (' . $err . '); alleen de syntaxcontrole is gedaan.']; }
    if ($code !== 200) { return [false, "Health-check: login.php gaf HTTP $code."]; }
    if (preg_match('/(Parse error|Fatal error|Uncaught )/', (string)$body)) { return [false, 'Health-check: login.php toont een PHP-fout.']; }
    return [true, 'Health-check: login.php werkt (HTTP 200).'];
}

/** Downloadt een https-URL naar een bestand met maximumgrootte. [httpcode, fout]. Volgt hoogstens 3 https-redirects. */
function upd_download(string $url, string $dest, int $max): array
{
    if (!function_exists('curl_init')) { return [0, 'De curl-extensie ontbreekt.']; }
    $fh = @fopen($dest, 'wb');
    if (!$fh) { return [0, 'Kan niet schrijven naar de staging-map.']; }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_FILE => $fh, CURLOPT_TIMEOUT => 90, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3,
        CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_NOPROGRESS => false,
        CURLOPT_PROGRESSFUNCTION => static fn($r, $dlTotal, $dlNow) => $dlNow > $max ? 1 : 0,
        CURLOPT_HTTPHEADER => ['User-Agent: ScriptSpace-updater/' . ss_version()],
    ]);
    $ok = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err = $ok === false ? curl_error($ch) : '';
    curl_close($ch);
    fclose($fh);
    return [$code, $err];
}

/** Voorwaarden voor het UI: lijst van [label, ok, uitleg]. */
function update_preflight(array $ctx = []): array
{
    $root = $ctx['root'] ?? SS_ROOT;
    $rows = [];
    $rows[] = ['Updater aangezet in config.php (\'updater\' => true)', (bool)($ctx['enabled'] ?? cfg('updater', false)), 'Staat standaard uit.'];
    $rows[] = ['Publieke sleutel aanwezig', base64_decode($ctx['pubkey'] ?? upd_pubkey(), true) !== false && strlen((string)base64_decode($ctx['pubkey'] ?? upd_pubkey(), true)) === 32, 'Draai tools/release.py keygen en zet de publieke sleutel in includes/update_pubkey.php.'];
    $rows[] = ['PHP sodium (handtekeningen)', function_exists('sodium_crypto_sign_verify_detached'), 'Extensie ontbreekt.'];
    $rows[] = ['PHP zip', class_exists('ZipArchive'), 'Extensie ontbreekt.'];
    $rows[] = ['PHP curl', function_exists('curl_init'), 'Extensie ontbreekt.'];
    $bad = [];
    foreach (['', 'includes', 'admin', 'api', 'user', 'assets', 'sql', 'storage'] as $d) {
        $p = $root . ($d === '' ? '' : '/' . $d);
        if (is_dir($p) && !is_writable($p)) { $bad[] = $d === '' ? '(hoofdmap)' : $d; }
    }
    $rows[] = ['Mappen schrijfbaar voor PHP', !$bad, $bad ? 'Niet schrijfbaar: ' . implode(', ', $bad) . '. Zet CHMOD 755 en eigenaar = je FTP-gebruiker.' : ''];
    $free = @disk_free_space($root);
    $rows[] = ['Genoeg schijfruimte (≥ 150 MB)', $free === false || $free > 150 * 1048576, ''];
    return $rows;
}

/**
 * Installeert de release uit $ctx['release'] (['version','assets'=>['manifest'=>url,'sig'=>url,'zip'=>url]]).
 * $ctx (allemaal optioneel, voor tests): root, current, pubkey, fetch(url,dest,max)->[code,err], migrate(), health()->[ok,msg],
 * backup()->string, by (user-id). Geeft ['ok','log','from','to','error','rolled_back'].
 */
function update_install(array $ctx): array
{
    $root = rtrim((string)($ctx['root'] ?? SS_ROOT), '/');
    $from = (string)($ctx['current'] ?? ss_version());
    $rel = (array)($ctx['release'] ?? []);
    $res = ['ok' => false, 'log' => [], 'from' => $from, 'to' => (string)($rel['version'] ?? ''), 'error' => '', 'rolled_back' => false];
    $log = static function (string $m) use (&$res): void { $res['log'][] = date('H:i:s') . ' ' . $m; };
    @set_time_limit(300);
    @ignore_user_abort(true);

    require_once __DIR__ . '/migrate.php';       // nu laden: tijdens het vervangen draait de OUDE, samenhangende code verder
    require_once __DIR__ . '/maintenance.php';
    $storage = $root . '/storage';
    if (!is_dir($storage) || !is_writable($storage)) { $res['error'] = 'storage/ is niet schrijfbaar.'; return $res; }
    $lockF = @fopen($storage . '/update.lock', 'c');
    if (!$lockF || !flock($lockF, LOCK_EX | LOCK_NB)) { $res['error'] = 'Er draait al een update.'; return $res; }

    $id = bin2hex(random_bytes(6));
    $work = $storage . '/update/' . $id;
    $snap = $work . '/rollback';
    $swapStarted = false; $maint = false;
    $fetch = $ctx['fetch'] ?? 'upd_download';
    try {
        foreach (update_preflight($ctx) as [$label, $okp, $hint]) {
            if (!$okp && !str_contains($label, 'schijfruimte')) { throw new RuntimeException('Voorwaarde niet gehaald: ' . $label . '. ' . $hint); }
        }
        $assets = (array)($rel['assets'] ?? []);
        foreach (['manifest', 'sig', 'zip'] as $k) { if (empty($assets[$k])) { throw new RuntimeException('De release mist het onderdeel "' . $k . '" (verwacht: manifest.json, manifest.json.sig en de zip).'); } }
        if (!mkdir($work, 0700, true) || !mkdir($snap . '/files', 0700, true)) { throw new RuntimeException('Staging-map aanmaken mislukt.'); }

        $log('Downloaden van manifest en handtekening');
        foreach ([['manifest', 'manifest.json', UPD_MAX_MANIFEST], ['sig', 'manifest.json.sig', 4096]] as [$k, $f, $max]) {
            [$code, $err] = $fetch((string)$assets[$k], $work . '/' . $f, $max);
            if ($code !== 200) { throw new RuntimeException('Download van ' . $f . ' mislukt' . ($err !== '' ? ': ' . $err : " (HTTP $code)") . '.'); }
        }
        $m = upd_verify_manifest((string)file_get_contents($work . '/manifest.json'), (string)file_get_contents($work . '/manifest.json.sig'), (string)($ctx['pubkey'] ?? upd_pubkey()));
        $res['to'] = $m['version'];
        $log('Handtekening geldig voor versie ' . $m['version']);
        if (!empty($rel['version']) && update_normalize_tag((string)$rel['version']) !== $m['version']) { throw new RuntimeException('De versie in het manifest (' . $m['version'] . ') komt niet overeen met de release (' . $rel['version'] . ').'); }
        if (version_compare($m['version'], $from, '<=')) { throw new RuntimeException('Deze versie (' . $m['version'] . ') is niet nieuwer dan de geïnstalleerde (' . $from . '). Terugzetten naar een oudere versie gebeurt nooit via de updater.'); }
        if (isset($m['min_php']) && version_compare(PHP_VERSION, (string)$m['min_php'], '<')) { throw new RuntimeException('Deze versie vraagt PHP ' . $m['min_php'] . ' of hoger; de server draait ' . PHP_VERSION . '.'); }

        $log('Downloaden van de zip (' . round($m['zip_size'] / 1048576, 1) . ' MB)');
        [$code, $err] = $fetch((string)$assets['zip'], $work . '/release.zip', $m['zip_size'] + 1024);
        if ($code !== 200) { throw new RuntimeException('Download van de zip mislukt' . ($err !== '' ? ': ' . $err : " (HTTP $code)") . '.'); }
        if (filesize($work . '/release.zip') !== $m['zip_size'] || !hash_equals($m['zip_sha256'], hash_file('sha256', $work . '/release.zip'))) { throw new RuntimeException('De gedownloade zip komt niet overeen met het ondertekende manifest (grootte of controlesom). Niets geïnstalleerd.'); }
        $log('Zip komt overeen met het manifest');

        $stage = $work . '/stage';
        $n = upd_extract($work . '/release.zip', $stage, $m);
        $log("$n bestanden veilig uitgepakt en gecontroleerd");
        upd_lint($stage, array_keys($m['files']));
        $log('PHP-syntaxcontrole geslaagd');

        $plan = [];
        foreach (array_keys($m['files']) as $p) {
            if (upd_protected($p)) { $log('Beschermd, niet aangeraakt: ' . $p); continue; }
            $plan[] = $p;
        }
        usort($plan, static fn($a, $b) => (in_array($a, UPD_ENTRY_LAST, true) <=> in_array($b, UPD_ENTRY_LAST, true)) ?: strcmp($a, $b));

        // wat de vorige installatie bracht en nu niet meer bestaat, wordt opgeruimd (alleen eigen bestanden uit het vorige manifest)
        $obsolete = [];
        $prev = json_decode((string)@file_get_contents($storage . '/update/installed_manifest.json'), true);
        if (is_array($prev['files'] ?? null)) {
            foreach (array_keys($prev['files']) as $p) {
                $p2 = upd_safe_rel((string)$p);
                if ($p2 !== null && !isset($m['files'][$p2]) && !upd_protected($p2) && is_file($root . '/' . $p2)) { $obsolete[] = $p2; }
            }
        }

        $bad = [];
        foreach ($plan as $p) { $d = dirname($root . '/' . $p); if (is_dir($d) && !is_writable($d)) { $bad[$d] = true; } }
        if ($bad) { throw new RuntimeException('Deze mappen zijn niet schrijfbaar voor PHP: ' . implode(', ', array_map(static fn($d) => str_replace($root . '/', '', (string)$d), array_slice(array_keys($bad), 0, 8))) . '. Pas de rechten aan (zie handleiding).'); }

        $log('Database-back-up maken');
        $bk = isset($ctx['backup']) ? ($ctx['backup'])() : backup_create_for_update((int)($ctx['by'] ?? 0));
        $log('Back-up klaar: ' . $bk);

        $replaced = []; $created = [];
        foreach ($plan as $p) {
            if (is_file($root . '/' . $p)) {
                if (!is_dir(dirname($snap . '/files/' . $p))) { mkdir(dirname($snap . '/files/' . $p), 0700, true); }
                copy($root . '/' . $p, $snap . '/files/' . $p); $replaced[] = $p;
            } else { $created[] = $p; }
        }
        foreach ($obsolete as $p) {
            if (!is_dir(dirname($snap . '/files/' . $p))) { mkdir(dirname($snap . '/files/' . $p), 0700, true); }
            copy($root . '/' . $p, $snap . '/files/' . $p); $replaced[] = $p;
        }
        file_put_contents($snap . '/meta.json', json_encode(['from' => $from, 'to' => $m['version'], 'at' => date('c'), 'replaced' => $replaced, 'created' => $created, 'deleted' => $obsolete]));
        $log('Snapshot gemaakt van ' . count($replaced) . ' bestanden');

        upd_maint_on($root); $maint = true;
        $log('Onderhoudsmodus aan');
        $swapStarted = true;
        foreach ($plan as $p) { upd_put($stage . '/' . $p, $root . '/' . $p); }
        foreach ($obsolete as $p) { @unlink($root . '/' . $p); }
        $log(count($plan) . ' bestanden vervangen' . ($obsolete ? ', ' . count($obsolete) . ' oude verwijderd' : ''));
        $ver = trim((string)@file_get_contents($root . '/VERSION'));
        if ($ver !== $m['version']) { throw new RuntimeException('VERSION toont ' . ($ver ?: 'niets') . ' na het vervangen, verwacht ' . $m['version'] . '.'); }

        $log('Databasemigraties uitvoeren');
        $done = isset($ctx['migrate']) ? ($ctx['migrate'])() : update_run_migrations((int)($ctx['by'] ?? 0));
        $log($done ? count($done) . ' migratie(s) uitgevoerd: ' . implode(', ', $done) : 'Geen migraties nodig');

        [$hok, $hmsg] = isset($ctx['health']) ? ($ctx['health'])() : upd_health_http();
        $log($hmsg);
        if (!$hok) { throw new RuntimeException($hmsg); }

        // gelukt: manifest onthouden, snapshot bewaren voor "vorige versie terugzetten", staging opruimen
        @copy($work . '/manifest.json', $storage . '/update/installed_manifest.json');
        upd_rrmdir($storage . '/update/last_rollback');
        @rename($snap, $storage . '/update/last_rollback');
        $res['ok'] = true;
        $log('Klaar: versie ' . $m['version'] . ' is geïnstalleerd');
    } catch (Throwable $e) {
        $res['error'] = $e->getMessage();
        $log('FOUT: ' . $e->getMessage());
        if ($swapStarted && is_file($snap . '/meta.json')) {
            try {
                $k = upd_restore_snapshot($root, $snap);
                $res['rolled_back'] = true;
                $log("Teruggezet: $k bestanden uit de snapshot. De site draait weer op $from.");
            } catch (Throwable $e2) {
                $res['error'] .= ' ÉN het terugzetten mislukte: ' . $e2->getMessage() . ' Herstel handmatig met de back-up in Admin, Back-up.';
                $log('TERUGZETTEN MISLUKT: ' . $e2->getMessage());
            }
        }
    } finally {
        if ($maint) { upd_maint_off($root); }
        upd_rrmdir($work);
        flock($lockF, LOCK_UN); fclose($lockF);
    }
    return $res;
}

/** Zet de vorige versie terug uit de laatste snapshot (knop in Admin, Updates). */
function update_rollback_last(?string $root = null): array
{
    $root = rtrim($root ?? SS_ROOT, '/');
    $snap = $root . '/storage/update/last_rollback';
    if (!is_file($snap . '/meta.json')) { return ['ok' => false, 'error' => 'Er is geen snapshot van een vorige versie.']; }
    $meta = json_decode((string)file_get_contents($snap . '/meta.json'), true);
    try {
        upd_maint_on($root, 120);
        $n = upd_restore_snapshot($root, $snap);
        upd_rrmdir($snap);
        @unlink($root . '/storage/update/installed_manifest.json');
        return ['ok' => true, 'files' => $n, 'from' => (string)($meta['to'] ?? ''), 'to' => (string)($meta['from'] ?? '')];
    } catch (Throwable $e) {
        return ['ok' => false, 'error' => $e->getMessage()];
    } finally {
        upd_maint_off($root);
    }
}

function backup_create_for_update(int $by): string
{
    require_once __DIR__ . '/maintenance.php';
    return backup_create('db', $by > 0 ? $by : null);
}

function update_run_migrations(int $by): array
{
    require_once __DIR__ . '/migrate.php';
    return migrate_run(null, $by > 0 ? $by : null);
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/update_install.php                               ║
// ║  Role    : Core                                                      ║
// ║  Version : 0.13.0                                                    ║
// ║  Updated : 2026-10-01                                                ║
// ║  Notes   : Ondertekende updates installeren, met rollback            ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
