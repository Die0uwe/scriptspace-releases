<?php
// includes/phprun.php — PHP uit een sandbox uitvoeren, alleen voor gebruikers met recht php.execute.
//
// Werkwijze: de bestanden worden naar een tijdelijke map gekopieerd en uitgevoerd door een APART php-cli-proces
// (proc_open met argumentenlijst, dus zonder shell), met: open_basedir op alleen die map, uitgeschakelde functies
// voor shell/netwerk/proces, 5 s rekentijd, 6 s klok, 64 MB geheugen, max. 64 KB uitvoer en een lege omgeving.
// Het proces heeft GEEN toegang tot config/config.php, de database of de sessie van de site.
// Let op: open_basedir en disable_functions zijn best-effort afscherming, geen container. Daarom alleen voor beheerders.
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

const PHPRUN_WALL_SECONDS = 6;
const PHPRUN_MAX_OUT = 65536;
const PHPRUN_MAX_ERR = 16384;
const PHPRUN_DISABLED = 'exec,passthru,shell_exec,system,proc_open,popen,pcntl_exec,pcntl_fork,pcntl_signal,pcntl_alarm,proc_nice,proc_terminate,proc_get_status,proc_close,mail,mb_send_mail,'
    . 'curl_exec,curl_multi_exec,curl_init,fsockopen,pfsockopen,stream_socket_client,stream_socket_server,stream_socket_pair,stream_socket_accept,stream_select,socket_create,socket_connect,socket_create_listen,'
    . 'dns_get_record,dns_check_record,dns_get_mx,checkdnsrr,getmxrr,gethostbyname,gethostbynamel,gethostbyaddr,'
    . 'error_log,syslog,openlog,closelog,posix_kill,posix_setuid,posix_setgid,posix_mkfifo,posix_getpwuid,posix_getpwnam,posix_uname,'
    . 'symlink,link,chmod,chown,chgrp,putenv,dl,phpinfo,php_uname,php_ini_loaded_file,php_ini_scanned_files,get_cfg_var,ini_alter,ini_restore,set_time_limit,apache_setenv,mysqli_connect,mysqli_real_connect';
const PHPRUN_DISABLED_CLASSES = 'PDO,mysqli,SQLite3,SoapClient,SoapServer,Phar,PharData,FFI,Socket,COM,DOTNET';
/** Harde grenzen via prlimit (bestandsgrootte, CPU, open bestanden). Zonder prlimit wordt PHP uitvoeren NIET aangeboden. */
const PHPRUN_LIMITS = ['--fsize=1048576', '--cpu=6', '--nofile=64', '--core=0'];

/** Zoekt prlimit; null als het ontbreekt of niet werkt (dan faalt phprun gesloten). */
function phprun_prlimit(): ?string
{
    foreach (['/usr/bin/prlimit', '/bin/prlimit', '/usr/local/bin/prlimit'] as $b) {
        if (is_file($b) && is_executable($b)) { return $b; }
    }
    return null;
}

function phprun_proc_ok(): bool
{
    if (!function_exists('proc_open')) { return false; }
    $dis = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    return !in_array('proc_open', $dis, true) && !in_array('proc_get_status', $dis, true) && !in_array('proc_terminate', $dis, true);
}

/** Start een proces (argumentenlijst) en geeft [stdout, stderr, exitcode, timedOut, truncated]. */
function phprun_exec(array $cmd, string $cwd, int $wall, int $maxOut = PHPRUN_MAX_OUT, int $maxErr = PHPRUN_MAX_ERR): array
{
    $spec = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
    $proc = @proc_open($cmd, $spec, $pipes, $cwd, ['PATH' => '/usr/local/bin:/usr/bin:/bin', 'HOME' => $cwd, 'LANG' => 'C.UTF-8']);
    if (!is_resource($proc)) { return ['', 'Proces starten mislukt.', -1, false, false]; }
    fclose($pipes[0]);
    stream_set_blocking($pipes[1], false);
    stream_set_blocking($pipes[2], false);
    $out = $err = '';
    $timedOut = $truncated = false;
    $exit = -1;
    $start = microtime(true);
    while (true) {
        $r = [$pipes[1], $pipes[2]]; $w = $e = null;
        if (@stream_select($r, $w, $e, 0, 100000) > 0) {
            foreach ($r as $p) {
                $chunk = fread($p, 8192);
                if ($chunk === false || $chunk === '') { continue; }
                if ($p === $pipes[1]) { $out .= $chunk; } else { $err .= $chunk; }
            }
        }
        if (strlen($out) > $maxOut || strlen($err) > $maxErr) { $truncated = true; proc_terminate($proc, 9); }
        $st = proc_get_status($proc);
        if (!$st['running']) {
            $exit = (int)$st['exitcode'];
            foreach ([1, 2] as $i) { while (($c = fread($pipes[$i], 8192)) !== false && $c !== '') { if ($i === 1) { $out .= $c; } else { $err .= $c; } } }
            break;
        }
        if (microtime(true) - $start > $wall) { $timedOut = true; proc_terminate($proc, 9); usleep(100000); break; }
    }
    @fclose($pipes[1]); @fclose($pipes[2]);
    proc_close($proc);
    if (strlen($out) > $maxOut) { $out = substr($out, 0, $maxOut); $truncated = true; }
    if (strlen($err) > $maxErr) { $err = substr($err, 0, $maxErr); $truncated = true; }
    return [$out, $err, $exit, $timedOut, $truncated];
}

/** Zoekt een werkende php-cli en geeft ['ok'=>bool,'bin'=>?string,'reason'=>string]. Resultaat 10 min in de sessie. */
function phprun_info(): array
{
    $cached = $_SESSION['phprun_info'] ?? null;
    if (is_array($cached) && ($cached['at'] ?? 0) > time() - 600) { return $cached['v']; }
    $v = phprun_detect();
    $_SESSION['phprun_info'] = ['at' => time(), 'v' => $v];
    return $v;
}

function phprun_detect(): array
{
    if (!cfg('php_exec', false)) { return ['ok' => false, 'bin' => null, 'reason' => 'PHP uitvoeren staat uit. Zet in config.php: \'php_exec\' => true (alleen op een server die je zelf vertrouwt; dit is geen echte sandbox).']; }
    if (phprun_prlimit() === null) { return ['ok' => false, 'bin' => null, 'reason' => 'prlimit ontbreekt op deze server; zonder harde limieten staat PHP uitvoeren uit.']; }
    if (!phprun_proc_ok()) { return ['ok' => false, 'bin' => null, 'reason' => 'proc_open is uitgeschakeld op deze server (vaak zo bij shared hosting).']; }
    $cands = [];
    $cfg = cfg('php_bin');
    if (is_string($cfg) && $cfg !== '') { $cands[] = $cfg; }
    if (preg_match('/^php[0-9.]*(\.exe)?$/i', basename(PHP_BINARY))) { $cands[] = PHP_BINARY; }
    $cands[] = PHP_BINDIR . '/php';
    foreach (['/usr/local/bin/php', '/usr/bin/php'] as $c) { $cands[] = $c; }
    foreach (glob('/usr/bin/php[0-9]*') ?: [] as $c) { $cands[] = $c; }
    foreach (glob('/usr/local/bin/php[0-9]*') ?: [] as $c) { $cands[] = $c; }
    foreach (array_unique($cands) as $bin) {
        if (!is_file($bin) || !is_executable($bin)) { continue; }
        [$out, , , $to] = phprun_exec(array_merge([phprun_prlimit()], PHPRUN_LIMITS, ['--', $bin, '-n', '-v']), sys_get_temp_dir(), 4, 2048, 512);
        if (!$to && preg_match('/^PHP \d+\.\d+.*\(cli\)/', $out)) { return ['ok' => true, 'bin' => $bin, 'reason' => '']; }
    }
    return ['ok' => false, 'bin' => null, 'reason' => 'Geen php-cli gevonden. Zet in config.php het pad: \'php_bin\' => \'/pad/naar/php\'.'];
}

function phprun_rrmdir(string $dir): void
{
    if (!is_dir($dir) || is_link($dir)) { return; }
    foreach (scandir($dir) ?: [] as $i) {
        if ($i === '.' || $i === '..') { continue; }
        $p = $dir . '/' . $i;
        (is_dir($p) && !is_link($p)) ? phprun_rrmdir($p) : @unlink($p);
    }
    @rmdir($dir);
}

/** Verwijdert achtergebleven tijdelijke mappen ouder dan een uur. */
function phprun_gc(): int
{
    $n = 0;
    foreach (glob(SS_ROOT . '/storage/run/*', GLOB_ONLYDIR) ?: [] as $d) {
        if (filemtime($d) < time() - 3600) { phprun_rrmdir($d); $n++; }
    }
    return $n;
}

/**
 * Voert $entry (logische naam, .php) uit in de sandbox $sbDir. $query is een querystring voor $_GET.
 * Geeft ['stdout','stderr','exit','timed_out','truncated','ms'] of gooit RuntimeException(melding).
 */
function phprun_sandbox(string $sbDir, string $entry, string $query = ''): array
{
    $info = phprun_info();
    if (!$info['ok']) { throw new RuntimeException($info['reason']); }
    $root = SS_ROOT . '/storage/run';
    if (!is_dir($root) && !@mkdir($root, 0700, true)) { throw new RuntimeException('storage/run kan niet worden aangemaakt.'); }
    $id = bin2hex(random_bytes(8));
    $base = $root . '/' . $id;
    $code = $base . '/code';
    if (!mkdir($code, 0700, true)) { throw new RuntimeException('Tijdelijke map aanmaken mislukt.'); }
    try {
        foreach (sandbox_files($sbDir, true) as $f) {
            copy($sbDir . '/' . sandbox_disk($f['name']), $code . '/' . $f['name']);
        }
        if (!is_file($code . '/' . $entry)) { throw new RuntimeException('Bestand niet gevonden.'); }
        $q = substr($query, 0, 500);
        file_put_contents($base . '/prepend.php',
            "<?php\n\$__q = " . var_export($q, true) . ";\nparse_str(\$__q, \$_GET);\n\$_REQUEST = \$_GET;\n\$_SERVER['REQUEST_METHOD'] = 'GET';\n\$_SERVER['QUERY_STRING'] = \$__q;\nunset(\$__q);\n");
        $realCode = realpath($code);
        $realPrep = realpath($base . '/prepend.php');
        $cmd = array_merge([phprun_prlimit()], PHPRUN_LIMITS, ['--', $info['bin'], '-n',
            '-d', 'open_basedir=' . $realCode . ':' . $realPrep,
            '-d', 'disable_functions=' . PHPRUN_DISABLED, '-d', 'disable_classes=' . PHPRUN_DISABLED_CLASSES,
            '-d', 'allow_url_fopen=0', '-d', 'allow_url_include=0', '-d', 'file_uploads=0',
            '-d', 'memory_limit=64M', '-d', 'max_execution_time=5', '-d', 'default_socket_timeout=2',
            '-d', 'display_errors=1', '-d', 'html_errors=0', '-d', 'log_errors=0', '-d', 'error_reporting=32767',
            '-d', 'auto_prepend_file=' . $realPrep, '-d', 'session.auto_start=0',
            '-f', $entry]);
        $t0 = microtime(true);
        [$out, $err, $exit, $timedOut, $trunc] = phprun_exec($cmd, $realCode, PHPRUN_WALL_SECONDS);
        return ['stdout' => $out, 'stderr' => $err, 'exit' => $exit, 'timed_out' => $timedOut, 'truncated' => $trunc, 'ms' => (int)round((microtime(true) - $t0) * 1000)];
    } finally {
        phprun_rrmdir($base);
    }
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/phprun.php                                       ║
// ║  Role    : Core                                                      ║
// ║  Version : 0.10.2                                                    ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : php-cli -n + prlimit, alleen super_admin, php_exec=true   ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
