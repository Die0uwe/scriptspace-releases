<?php
// includes/api.php — hulpfuncties voor JSON-endpoints in /api/.
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

function json_out(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function api_error(string $message, int $status = 400): never
{
    json_out(['error' => $message], $status);
}

/** JSON-body (max 512 KB). */
function api_input(): array
{
    $raw = file_get_contents('php://input', false, null, 0, 524289);
    if ($raw === false || strlen($raw) > 524288) { api_error('Verzoek te groot.', 413); }
    if ($raw === '') { return []; }
    $data = json_decode($raw, true);
    if (!is_array($data)) { api_error('Ongeldige JSON.', 400); }
    return $data;
}

/** Ingelogde, actieve gebruiker met (optioneel) een permissie; anders JSON-fout. */
function api_user(?string $permission = null): array
{
    $u = active_user();
    if ($u === null) { api_error('Niet ingelogd.', 401); }
    if ($permission !== null && !user_can($u['id'], $permission)) { api_error('Geen toegang.', 403); }
    return $u;
}

/** Wijzigende acties: alleen POST met geldig CSRF-token (header X-CSRF-Token of veld csrf). */
function api_require_post(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { api_error('Alleen POST.', 405); }
    if (!csrf_verify()) { api_error('Ongeldig of verlopen CSRF-token. Herlaad de pagina.', 403); }
}
