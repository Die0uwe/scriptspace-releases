<?php
// includes/connections.php — hulpfuncties voor het testpaneel voor verbindingen (admin/connections.php).
// Elke test geeft ['ok' => bool, 'detail' => string] terug en bevat nooit geheimen (wachtwoorden, tokens, volledige webhook-URL).
declare(strict_types=1);
require_once __DIR__ . '/bootstrap.php';

const CONN_TESTS_PER_HOUR = 20;

/** Maskeert een webhook-URL tot .../webhooks/<id>/•••• zodat hij nooit volledig op het scherm of in het log staat. */
function conn_mask_webhook(string $url): string
{
    return (string)preg_replace('#(/api/webhooks/\d+/).+$#', '$1••••', $url);
}

/** Geldige Discord-webhook-URL (alleen discord.com / discordapp.com, https, vast pad) of ''. */
function conn_discord_url(string $url): string
{
    $url = trim($url);
    if (!preg_match('#^https://(?:(?:canary|ptb)\.)?(?:discord|discordapp)\.com/api/webhooks/\d{5,25}/[A-Za-z0-9._-]{20,120}$#D', $url)) { return ''; }
    return $url;
}

/** De webhook uit config.php ('discord_webhook'), of '' als hij ontbreekt of een voorbeeldwaarde is. */
function conn_discord_configured(): string
{
    $u = cfg('discord_webhook', '');
    return is_string($u) ? conn_discord_url($u) : '';
}

/** Eenvoudige HTTPS-aanroep met time-out; geeft [httpcode, body, foutmelding]. Volgt geen redirects. */
function conn_http(string $method, string $url, ?string $body = null, array $headers = [], int $timeout = 8): array
{
    if (!function_exists('curl_init')) { return [0, '', 'De curl-extensie ontbreekt op deze server.']; }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_CUSTOMREQUEST => $method, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_FOLLOWLOCATION => false, CURLOPT_PROTOCOLS => CURLPROTO_HTTPS, CURLOPT_HTTPHEADER => array_merge(['User-Agent: ScriptSpace-connectiontest'], $headers),
    ]);
    if ($body !== null) { curl_setopt($ch, CURLOPT_POSTFIELDS, $body); }
    $out = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    $err = $out === false ? curl_error($ch) : '';
    curl_close($ch);
    return [$code, is_string($out) ? $out : '', $err];
}

function conn_test_mail(string $to): array
{
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) { return ['ok' => false, 'detail' => 'Dat is geen geldig e-mailadres.']; }
    $how = '';
    $ok = send_mail($to, 'Testmail van ScriptSpace', "Dit is een testbericht uit het adminpaneel van " . cfg('app_url') . ".\nTijd: " . date('Y-m-d H:i:s') . "\nAls je dit leest, werkt het versturen van e-mail.\n", $how);
    return ['ok' => $ok, 'detail' => ($ok ? 'Verstuurd naar ' . $to . ' via ' : 'Versturen mislukt via ') . $how . '.'];
}

/** Stuurt een testbericht. $url '' = de webhook uit config.php. */
function conn_test_discord(string $url): array
{
    $u = $url !== '' ? conn_discord_url($url) : conn_discord_configured();
    if ($u === '') {
        return ['ok' => false, 'detail' => $url !== ''
            ? 'Dit is geen geldige Discord-webhook-URL (verwacht: https://discord.com/api/webhooks/<id>/<token>).'
            : "Er is geen webhook ingesteld. Zet in config.php: 'discord_webhook' => 'https://discord.com/api/webhooks/…', of plak er hieronder een."];
    }
    $payload = json_encode(['username' => 'ScriptSpace', 'content' => '✅ Testbericht van ' . cfg('app_url') . ' (' . date('H:i:s') . ')', 'allowed_mentions' => ['parse' => []]], JSON_UNESCAPED_UNICODE);
    [$code, $body, $err] = conn_http('POST', $u . '?wait=false', (string)$payload, ['Content-Type: application/json']);
    $m = conn_mask_webhook($u);
    if ($err !== '') { return ['ok' => false, 'detail' => "Geen verbinding met Discord: $err"]; }
    if ($code === 204 || $code === 200) { return ['ok' => true, 'detail' => "Discord nam het bericht aan (HTTP $code) via $m. Kijk in het kanaal."]; }
    $hint = match (true) {
        $code === 404 => 'de webhook bestaat niet (meer): maak een nieuwe aan in de kanaalinstellingen',
        $code === 401 => 'het webhook-token klopt niet',
        $code === 429 => 'Discord begrenst je tijdelijk, probeer het zo opnieuw',
        $code >= 500 => 'Discord heeft een storing',
        default => 'onverwacht antwoord: ' . mb_substr(trim(strip_tags($body)), 0, 120),
    };
    return ['ok' => false, 'detail' => "Discord weigerde (HTTP $code): $hint."];
}

function conn_test_database(): array
{
    $t0 = microtime(true);
    try {
        $v = (string)db()->query('SELECT VERSION()')->fetchColumn();
        $n = (int)db()->query('SELECT COUNT(*) FROM users')->fetchColumn();
    } catch (Throwable $e) {
        return ['ok' => false, 'detail' => 'Database-fout (details staan in het serverlog).'];
    }
    return ['ok' => true, 'detail' => sprintf('Verbonden, MySQL/MariaDB %s, %d gebruikers, %d ms.', $v, $n, (int)round((microtime(true) - $t0) * 1000))];
}

function conn_test_storage(): array
{
    $bad = [];
    foreach (['storage', 'sandboxes'] as $d) {
        $p = SS_ROOT . '/' . $d;
        if (!is_dir($p)) { $bad[] = "$d bestaat niet"; continue; }
        $f = $p . '/.conn_test_' . bin2hex(random_bytes(4));
        if (@file_put_contents($f, 'x') === false) { $bad[] = "$d is niet schrijfbaar"; } else { @unlink($f); }
    }
    return $bad ? ['ok' => false, 'detail' => implode('; ', $bad) . '. Zet de map op schrijfbaar (CHMOD 755/775).'] : ['ok' => true, 'detail' => 'storage/ en sandboxes/ zijn schrijfbaar.'];
}

/** Bereikbaarheid van een externe host (elk HTTP-antwoord onder 500 telt als bereikbaar). */
function conn_test_reach(string $url): array
{
    $t0 = microtime(true);
    [$code, , $err] = conn_http('GET', $url, null, [], 6);
    $ms = (int)round((microtime(true) - $t0) * 1000);
    $host = (string)parse_url($url, PHP_URL_HOST);
    if ($err !== '') { return ['ok' => false, 'detail' => "$host niet bereikbaar: $err"]; }
    return $code > 0 && $code < 500 ? ['ok' => true, 'detail' => "$host bereikbaar (HTTP $code, $ms ms)."] : ['ok' => false, 'detail' => "$host gaf HTTP $code."];
}

/** Welke OAuth-providers zijn ingesteld en welke redirect-URL moet er bij de provider staan. */
function conn_oauth_overview(): array
{
    require_once __DIR__ . '/oauth.php';
    $conf = cfg('oauth', []);
    $set = oauth_providers();
    $rows = [];
    foreach (OAUTH_DEFS as $name => $def) {
        $c = is_array($conf[$name] ?? null) ? $conf[$name] : [];
        $on = isset($set[$name]);
        $rows[] = ['name' => $name, 'label' => $def['label'], 'on' => $on,
                   'redirect' => $on ? $set[$name]['redirect'] : rtrim((string)cfg('app_url'), '/') . '/login.php?provider=' . $name,
                   'host' => (string)parse_url($def['auth'], PHP_URL_HOST), 'auth' => $def['auth'],
                   'partial' => !$on && (($c['client_id'] ?? '') !== '' || ($c['client_secret'] ?? '') !== '')];
    }
    return $rows;
}

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : includes/connections.php                                  ║
// ║  Role    : Admin                                                     ║
// ║  Version : 0.11.0                                                    ║
// ║  Updated : 2026-10-01                                                ║
// ║  Notes   : Tests voor mail, Discord-webhook, database, OAuth, opslag ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
