<?php
// includes/update_pubkey.php — publieke Ed25519-sleutel (base64, 32 bytes) waarmee releases worden gecontroleerd.
// Maak het sleutelpaar op je EIGEN computer: python tools/release.py keygen. De private sleutel verlaat die computer nooit.
// Deze sleutel is publiek en mag in git staan.
declare(strict_types=1);
return '7fMCongHkRX8Y5AMDZw6PND7NvJfKEr+I+2SpoBQWN0=';
