<?php
// includes/sandbox.php — sandboxes: platte mappen met een paar toegestane tekstbestanden.
// Bestanden worden nooit rechtstreeks door de webserver uitgeleverd; de playground toont ze via een
// afgeschermde iframe (srcdoc, sandbox zonder allow-same-origin).
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

const SB_MAX_FILES = 30;
const SB_MAX_BYTES = 204800;   // 200 KB per bestand
const SB_TTL_HOURS = 72;
const SB_EXT = ['html', 'css', 'js', 'json', 'txt', 'md', 'svg'];

function sandbox_base(): string
{
    $base = realpath(SS_ROOT . '/sandboxes');
    if ($base === false) { throw new RuntimeException('Map sandboxes ontbreekt.'); }
    return $base;
}

function sandbox_starter_files(): array
{
    return [
        'index.html' => "<!DOCTYPE html>\n<html lang=\"nl\">\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  <title>Mijn pagina</title>\n  <link rel=\"stylesheet\" href=\"style.css\">\n</head>\n<body>\n  <h1>Hallo ScriptSpace 👋</h1>\n  <p>Bewerk deze bestanden en zie direct het resultaat.</p>\n  <button id=\"knop\">Klik mij</button>\n  <script src=\"app.js\"></script>\n</body>\n</html>\n",
        'style.css'  => "body {\n  font-family: system-ui, sans-serif;\n  background: #0b0d14;\n  color: #e2e8f0;\n  text-align: center;\n  margin-top: 60px;\n}\nh1 { color: #8b5cf6; }\nbutton { background: #8b5cf6; color: #fff; border: 0; padding: 10px 18px; border-radius: 8px; cursor: pointer; }\n",
        'app.js'     => "document.getElementById('knop').addEventListener('click', () => {\n  alert('Het werkt!');\n});\n",
    ];
}

/** Maakt een sandbox voor een gebruiker. Gooit RuntimeException('quota') bij te veel actieve sandboxes. */
function sandbox_create(int $userId): array
{
    if (!user_can($userId, 'sandbox.unlimited')) {
        $st = db()->prepare('SELECT COUNT(*) FROM sandboxes WHERE user_id = ? AND expires_at > NOW()');
        $st->execute([$userId]);
        if ((int)$st->fetchColumn() >= 3) { throw new RuntimeException('quota'); }
    }
    $slug = 'sb_' . bin2hex(random_bytes(4));
    $dir = sandbox_base() . '/' . $slug;
    if (!mkdir($dir, 0755, true)) { throw new RuntimeException('Kon sandbox niet aanmaken.'); }
    foreach (sandbox_starter_files() as $name => $content) { file_put_contents($dir . '/' . $name, $content); }
    db()->prepare('INSERT INTO sandboxes (user_id, slug, expires_at) VALUES (?, ?, NOW() + INTERVAL ' . SB_TTL_HOURS . ' HOUR)')->execute([$userId, $slug]);
    audit('sandbox.create', $userId, ['slug' => $slug]);
    $st = db()->prepare('SELECT slug, created_at, expires_at FROM sandboxes WHERE slug = ?');
    $st->execute([$slug]);
    return $st->fetch();
}

function sandbox_list(int $userId): array
{
    $st = db()->prepare('SELECT slug, created_at, expires_at FROM sandboxes WHERE user_id = ? AND expires_at > NOW() ORDER BY id DESC');
    $st->execute([$userId]);
    return $st->fetchAll();
}

/** Map van een eigen, niet-verlopen sandbox, of null. */
function sandbox_dir(string $slug, int $userId): ?string
{
    if (!preg_match('/^sb_[a-f0-9]{8}$/', $slug)) { return null; }
    $st = db()->prepare('SELECT 1 FROM sandboxes WHERE slug = ? AND user_id = ? AND expires_at > NOW()');
    $st->execute([$slug, $userId]);
    if (!$st->fetchColumn()) { return null; }
    $dir = realpath(sandbox_base() . '/' . $slug);
    return ($dir !== false && str_starts_with($dir, sandbox_base() . DIRECTORY_SEPARATOR)) ? $dir : null;
}

/**
 * Geldige logische bestandsnaam. PHP-bestanden (alleen voor gebruikers met php.execute) staan op schijf als
 * "naam.php.sbx", zodat de webserver ze nooit als PHP kan uitvoeren, ook niet als een .htaccess niet werkt.
 */
function sandbox_valid_name(string $name, bool $allowPhp = false): bool
{
    $ext = SB_EXT;
    if ($allowPhp) { $ext[] = 'php'; }
    return (bool)preg_match('/^[A-Za-z0-9_-]{1,60}\.(' . implode('|', $ext) . ')$/i', $name);
}

function sandbox_is_php(string $name): bool
{
    return (bool)preg_match('/\.php$/i', $name);
}

/** Naam op schijf voor een logische naam. */
function sandbox_disk(string $name): string
{
    return sandbox_is_php($name) ? $name . '.sbx' : $name;
}

function sandbox_files(string $dir, bool $allowPhp = false): array
{
    $out = [];
    foreach (scandir($dir) ?: [] as $f) {
        $p = $dir . '/' . $f;
        if ($f[0] === '.' || !is_file($p) || is_link($p)) { continue; }
        $logical = preg_match('/\.php\.sbx$/i', $f) ? substr($f, 0, -4) : $f;
        if (str_ends_with($f, '.sbx') && !sandbox_is_php($logical)) { continue; }
        if (!sandbox_valid_name($logical, $allowPhp)) { continue; }
        $out[] = ['name' => $logical, 'size' => filesize($p), 'mtime' => filemtime($p)];
    }
    usort($out, fn($a, $b) => strcmp($a['name'], $b['name']));
    return $out;
}

/** Atomisch schrijven (tijdelijk bestand + rename). $name is de logische naam. */
function sandbox_write(string $dir, string $name, string $content): void
{
    $tmp = $dir . '/.tmp_' . bin2hex(random_bytes(4));
    if (file_put_contents($tmp, $content, LOCK_EX) === false) { throw new RuntimeException('Schrijven mislukt.'); }
    if (!rename($tmp, $dir . '/' . sandbox_disk($name))) { @unlink($tmp); throw new RuntimeException('Schrijven mislukt.'); }
}
