<?php
// cron/cleanup_task.php — ruimt verlopen sandboxes op (map + databaseregel).
// Aanroepen via: CLI (php cron/cleanup_task.php) of via web met header "X-Cron-Token: <cron_token>".
declare(strict_types=1);
require_once __DIR__ . '/../includes/bootstrap.php';

if (PHP_SAPI !== 'cli') {
    $sent = (string)($_SERVER['HTTP_X_CRON_TOKEN'] ?? '');
    $expected = (string)cfg('cron_token', '');
    if ($expected === '' || str_starts_with($expected, 'VERZIN_') || !hash_equals($expected, $sent)) {
        http_response_code(403);
        exit('Geen toegang.');
    }
}

require_once __DIR__ . '/../includes/maintenance.php';

$r = cleanup_run(null);
echo "Cleanup klaar. Verwijderde sandboxes: {$r['sandboxes_deleted']}, losse mappen: {$r['orphans_deleted']}, niet-bevestigde accounts: {$r['unverified_deleted']}\n";

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : cron/cleanup_task.php                                     ║
// ║  Role    : Cron                                                      ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Verlopen sandboxes opruimen                               ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
