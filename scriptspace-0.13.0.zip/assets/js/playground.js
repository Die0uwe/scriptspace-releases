/* playground.js — editor (Ace), live preview in afgeschermde iframe, console en AI-assistent. */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const body = document.body;
  const CAN_SANDBOX = body.dataset.canSandbox === '1';
  const CAN_AI = body.dataset.canAi === '1';
  const CAN_PHP = body.dataset.php === '1';

  const state = {
    csrf: $('meta[name="csrf"]').content,
    sandboxes: [], slug: null,
    files: new Map(),            // naam -> {session, saved, dirty}
    current: null,
    history: [],                 // AI-gesprek (laatste beurten)
    keys: { deepseek: false, gemini: false },
    errors: 0, busy: false,
  };
  let visual = null;           // visuele modus (visual.js)
  const store = {
    get(k, d) { try { return localStorage.getItem(k) ?? d; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* voorkeuren zijn optioneel */ } },
  };

  /* ---------- API ---------- */
  async function api(path, opts = {}) {
    const init = { credentials: 'same-origin', headers: { 'Accept': 'application/json' } };
    if (opts.body !== undefined) {
      init.method = 'POST';
      init.headers['Content-Type'] = 'application/json';
      init.headers['X-CSRF-Token'] = state.csrf;
      init.body = JSON.stringify(opts.body);
    }
    let res;
    try { res = await fetch(path, init); } catch (e) { throw new Error('Geen verbinding met de server.'); }
    let data = null;
    try { data = await res.json(); } catch (e) { /* geen JSON */ }
    if (data && data.csrf) { state.csrf = data.csrf; }
    if (res.status === 401) { location.href = 'login.php?redirect=' + encodeURIComponent(location.pathname + location.search); throw new Error('Niet ingelogd.'); }
    if (!res.ok) { throw new Error((data && data.error) || ('Fout ' + res.status)); }
    return data;
  }

  /* ---------- Dialogen ---------- */
  const dlgAsk = $('#dlgAsk');
  function ask({ title, text = '', value = '', ok = 'OK', input = true, validate }) {
    return new Promise(resolve => {
      $('#askTitle').textContent = title;
      $('#askText').textContent = text;
      const inp = $('#askInput'); inp.value = value; inp.hidden = !input;
      const err = $('#askErr'); err.hidden = true;
      $('#askOk').textContent = ok;
      let done = false;
      const finish = v => { if (done) return; done = true; dlgAsk.close(); cleanup(); resolve(v); };
      const onSubmit = e => {
        e.preventDefault();
        const v = inp.value.trim();
        if (input && validate) { const m = validate(v); if (m) { err.textContent = m; err.hidden = false; return; } }
        finish(input ? v : true);
      };
      const onCancel = () => finish(null);
      const cleanup = () => { $('#askForm').removeEventListener('submit', onSubmit); $('#askCancel').removeEventListener('click', onCancel); dlgAsk.removeEventListener('cancel', onCancel); };
      $('#askForm').addEventListener('submit', onSubmit);
      $('#askCancel').addEventListener('click', onCancel);
      dlgAsk.addEventListener('cancel', onCancel);
      dlgAsk.showModal();
      if (input) { inp.focus(); inp.select(); } else { $('#askOk').focus(); }
    });
  }
  const validName = n => new RegExp('^[A-Za-z0-9_-]{1,60}\\.(html|css|js|json|txt|md|svg' + (body.dataset.php !== '0' ? '|php' : '') + ')$', 'i').test(n) ? '' : 'Gebruik letters, cijfers, - of _ met extensie html, css, js, json, txt, md, svg' + (body.dataset.php !== '0' ? ' of php' : '') + '.';

  /* ---------- Editor ---------- */
  ace.config.set('basePath', 'assets/vendor/ace');
  const editor = ace.edit('editor', {
    theme: 'ace/theme/tomorrow_night', fontSize: 14, tabSize: 2, useSoftTabs: true, wrap: true,
    showPrintMargin: false, enableBasicAutocompletion: true, enableLiveAutocompletion: true, enableSnippets: false,
    highlightActiveLine: true, behavioursEnabled: true,
  });
  const modeFor = name => ({ html: 'html', css: 'css', js: 'javascript', json: 'json', md: 'markdown', svg: 'svg', txt: 'text', php: 'php' })[(name.split('.').pop() || '').toLowerCase()] || 'text';
  editor.commands.addCommand({ name: 'save', bindKey: { win: 'Ctrl-S', mac: 'Command-S' }, exec: () => saveCurrent(true) });
  editor.selection.on('changeCursor', () => { const p = editor.getCursorPosition(); $('#stCursor').textContent = 'Regel ' + (p.row + 1) + ', kolom ' + (p.column + 1); });

  function setStatus(msg, cls) { const el = $('#stSave'); el.textContent = msg; el.style.color = cls === 'err' ? 'var(--danger)' : cls === 'ok' ? 'var(--ok)' : ''; }
  function anyDirty() { for (const f of state.files.values()) { if (f.dirty) return true; } return false; }
  function refreshDirty() { $('#dirtyDot').hidden = !anyDirty(); renderFiles(); const f = state.files.get(state.current); $('#tabState').textContent = f && f.dirty ? 'niet opgeslagen' : ''; }

  function addFile(name, content) {
    const session = ace.createEditSession(content, 'ace/mode/' + modeFor(name));
    session.setUseWrapMode(true); session.setTabSize(2); session.setUseSoftTabs(true);
    const f = { session, saved: content, dirty: false };
    session.on('change', () => {
      const d = session.getValue() !== f.saved;
      if (d !== f.dirty) { f.dirty = d; refreshDirty(); }
      scheduleLive();
      if (visual) visual.codeChanged();
    });
    state.files.set(name, f);
  }

  function openFile(name) {
    const f = state.files.get(name); if (!f) return;
    state.current = name; editor.setSession(f.session);
    $('#tabName').textContent = name; editor.setReadOnly(false); refreshDirty();
    if (visual && visual.active) { visual.fileChanged(); } else { editor.focus(); }
  }

  /* ---------- Bestandenlijst ---------- */
  function renderFiles() {
    const ul = $('#fileList'); ul.textContent = '';
    for (const name of Array.from(state.files.keys()).sort()) {
      const f = state.files.get(name);
      const li = document.createElement('li'); li.className = name === state.current ? 'active' : ''; li.tabIndex = 0;
      const nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = name; li.appendChild(nm);
      if (f.dirty) { const m = document.createElement('span'); m.className = 'mod'; m.textContent = '●'; m.title = 'Niet opgeslagen'; li.appendChild(m); }
      const acts = document.createElement('span'); acts.className = 'acts';
      const ren = Object.assign(document.createElement('button'), { className: 'icon', title: 'Hernoemen', textContent: '✎' });
      const del = Object.assign(document.createElement('button'), { className: 'icon', title: 'Verwijderen', textContent: '🗑' });
      ren.addEventListener('click', e => { e.stopPropagation(); renameFile(name); });
      del.addEventListener('click', e => { e.stopPropagation(); deleteFile(name); });
      const dl = Object.assign(document.createElement('button'), { className: 'icon', title: 'Downloaden', textContent: '⬇' });
      dl.addEventListener('click', e => { e.stopPropagation(); downloadFile(name); });
      acts.append(dl, ren, del); li.appendChild(acts);
      li.addEventListener('click', () => openFile(name));
      li.addEventListener('keydown', e => { if (e.key === 'Enter') openFile(name); });
      ul.appendChild(li);
    }
    $('#filesHint').textContent = state.slug ? state.files.size + ' / 30 bestanden · max 200 KB per bestand' : '';
  }

  async function newFile(initial = '', content = '') {
    if (!state.slug) return;
    const name = await ask({ title: 'Nieuw bestand', text: 'Bestandsnaam, bijvoorbeeld pagina.html', value: initial, ok: 'Aanmaken', validate: v => validName(v) || (state.files.has(v) ? 'Dit bestand bestaat al.' : '') });
    if (!name) return null;
    try {
      await api('api/files.php', { body: { action: 'create', slug: state.slug, name, content } });
      addFile(name, content); openFile(name); setStatus('Bestand aangemaakt', 'ok'); return name;
    } catch (e) { setStatus(e.message, 'err'); return null; }
  }

  async function renameFile(name) {
    const nn = await ask({ title: 'Hernoemen', value: name, ok: 'Hernoemen', validate: v => validName(v) || (v !== name && state.files.has(v) ? 'Dit bestand bestaat al.' : '') });
    if (!nn || nn === name) return;
    try {
      await api('api/files.php', { body: { action: 'rename', slug: state.slug, name, new_name: nn } });
      const f = state.files.get(name); state.files.delete(name);
      // sessie opnieuw opbouwen zodat de mode bij de nieuwe extensie past
      const content = f.session.getValue(); addFile(nn, content);
      const nf = state.files.get(nn); nf.saved = f.saved; nf.dirty = content !== f.saved;
      if (state.current === name) openFile(nn); else refreshDirty();
      scheduleLive(true);
    } catch (e) { setStatus(e.message, 'err'); }
  }

  async function deleteFile(name) {
    const ok = await ask({ title: 'Bestand verwijderen?', text: name + ' wordt definitief verwijderd.', ok: 'Verwijderen', input: false });
    if (!ok) return;
    try {
      await api('api/files.php', { body: { action: 'delete', slug: state.slug, name } });
      state.files.delete(name);
      if (state.current === name) { const first = Array.from(state.files.keys()).sort()[0]; if (first) openFile(first); else { state.current = null; $('#tabName').textContent = '—'; editor.setSession(ace.createEditSession('', 'ace/mode/text')); } }
      refreshDirty(); scheduleLive(true);
    } catch (e) { setStatus(e.message, 'err'); }
  }

  async function saveFile(name) {
    const f = state.files.get(name); if (!f) return;
    const content = f.session.getValue();
    await api('api/files.php', { body: { action: 'save', slug: state.slug, name, content } });
    f.saved = content; f.dirty = false;
  }
  async function saveCurrent(all) {
    if (!state.slug) return;
    if (visual) visual.flush();
    setStatus('Opslaan…');
    try {
      const names = all ? Array.from(state.files.keys()).filter(n => state.files.get(n).dirty) : [state.current];
      for (const n of names) { await saveFile(n); }
      refreshDirty(); setStatus(names.length ? 'Opgeslagen ' + new Date().toLocaleTimeString('nl-NL') : 'Niets te bewaren', 'ok');
    } catch (e) { setStatus(e.message, 'err'); }
  }

  /* ---------- Download en upload (voor je eigen editor) ---------- */
  function startDownload(url) { const a = document.createElement('a'); a.href = url; a.download = ''; document.body.appendChild(a); a.click(); a.remove(); }
  async function downloadFile(name) {
    if (!state.slug) return;
    if (state.files.get(name)?.dirty) { await saveFile(name).catch(e => setStatus(e.message, 'err')); refreshDirty(); }
    startDownload('api/sandbox_io.php?download=file&slug=' + encodeURIComponent(state.slug) + '&name=' + encodeURIComponent(name));
  }
  async function downloadZip() {
    if (!state.slug) return;
    if (visual) visual.flush();
    if (anyDirty()) { await saveCurrent(true); }
    startDownload('api/sandbox_io.php?download=zip&slug=' + encodeURIComponent(state.slug));
    setStatus('ZIP wordt gedownload', 'ok');
  }
  async function uploadFiles(fileList) {
    const files = Array.from(fileList || []); if (!state.slug || !files.length) return;
    if (!(await ask({ title: files.length + ' bestand(en) uploaden?', text: 'Bestaande bestanden met dezelfde naam worden overschreven. Een ZIP wordt uitgepakt (alleen toegestane bestanden, submappen worden platgemaakt).', ok: 'Uploaden', input: false }))) return;
    if (visual) visual.flush();
    if (anyDirty()) { await saveCurrent(true); }
    const fd = new FormData(); fd.append('slug', state.slug); files.forEach(f => fd.append('files[]', f, f.name));
    setStatus('Uploaden…');
    let d;
    try {
      const res = await fetch('api/sandbox_io.php', { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'X-CSRF-Token': state.csrf, 'Accept': 'application/json' } });
      d = await res.json().catch(() => ({ error: 'Onverwacht antwoord van de server.' }));
      if (!res.ok) throw new Error(d.error || 'Uploaden mislukt.');
    } catch (e) { setStatus(e.message, 'err'); return; }
    const keep = state.current;
    await openSandbox(state.slug);
    if (keep && state.files.has(keep)) { openFile(keep); }
    setStatus(d.imported.length + ' bestand(en) geïmporteerd' + (d.skipped.length ? ', ' + d.skipped.length + ' overgeslagen' : ''), d.imported.length ? 'ok' : 'err');
    if (d.skipped.length) {
      await ask({ title: 'Niet alles is geïmporteerd', text: d.skipped.map(x => x.name + ': ' + x.reason).join('\n'), ok: 'OK', input: false });
    }
  }
  $('#fileZip').addEventListener('click', downloadZip);
  $('#fileUp').addEventListener('click', () => { if (state.slug) $('#fileInput').click(); else setStatus('Maak eerst een sandbox', 'err'); });
  $('#fileInput').addEventListener('change', e => { const fl = Array.from(e.target.files); e.target.value = ''; uploadFiles(fl); });
  ['dragover', 'drop'].forEach(ev => $('#files').addEventListener(ev, e => {
    if (!e.dataTransfer || !Array.from(e.dataTransfer.types || []).includes('Files')) return;
    e.preventDefault();
    if (ev === 'drop') uploadFiles(e.dataTransfer.files);
  }));

  /* ---------- Sandboxes ---------- */
  function renderSandboxes() {
    const sel = $('#sbSelect'); sel.textContent = '';
    for (const s of state.sandboxes) { const o = document.createElement('option'); o.value = s.slug; o.textContent = s.slug + ' · ' + hoursLeft(s.expires_at); sel.appendChild(o); }
    if (state.slug) sel.value = state.slug;
    $('#emptyState').hidden = state.sandboxes.length > 0;
    updateExpiry();
  }
  function parseDbDate(s) { return new Date(s.replace(' ', 'T')); }
  function hoursLeft(exp) { const h = Math.max(0, Math.round((parseDbDate(exp) - Date.now()) / 36e5)); return h + 'u over'; }
  function updateExpiry() {
    const s = state.sandboxes.find(x => x.slug === state.slug);
    $('#stExpiry').textContent = s ? 'Sandbox verloopt over ' + hoursLeft(s.expires_at).replace(' over', '') + ' — sla belangrijk werk elders op' : '';
  }

  async function loadSandboxes() {
    const d = await api('api/sandbox.php'); state.sandboxes = d.sandboxes; return d;
  }

  async function openSandbox(slug) {
    if (anyDirty() && !(await ask({ title: 'Niet-opgeslagen wijzigingen', text: 'Doorgaan en de wijzigingen weggooien?', ok: 'Doorgaan', input: false }))) { $('#sbSelect').value = state.slug; return; }
    state.slug = slug; state.files.clear(); state.current = null; clearConsole();
    try {
      const list = (await api('api/files.php?action=list&slug=' + encodeURIComponent(slug))).files;
      const contents = await Promise.all(list.map(f => api('api/files.php?action=read&slug=' + encodeURIComponent(slug) + '&name=' + encodeURIComponent(f.name))));
      contents.forEach(c => addFile(c.name, c.content));
      const first = state.files.has('index.html') ? 'index.html' : Array.from(state.files.keys()).sort()[0];
      if (first) openFile(first);
      history.replaceState(null, '', '?sandbox=' + encodeURIComponent(slug));
      store.set('ss_last_sandbox', slug);
      renderSandboxes(); renderFiles(); runPreview();
    } catch (e) { setStatus(e.message, 'err'); }
  }

  async function createSandbox() {
    if (!CAN_SANDBOX) return;
    try {
      const d = await api('api/sandbox.php', { body: { action: 'create' } });
      await loadSandboxes(); await openSandbox(d.sandbox.slug);
    } catch (e) { setStatus(e.message, 'err'); await ask({ title: 'Kan geen sandbox maken', text: e.message, ok: 'OK', input: false }); }
  }

  /* ---------- Preview + console ---------- */
  const preview = $('#preview');
  const BRIDGE = '<script>(function(){function s(v){try{if(typeof v==="string")return v;if(v instanceof Error)return v.stack||v.message;return JSON.stringify(v)}catch(e){return String(v)}}' +
    'function p(t,a){try{parent.postMessage({__ss:1,type:t,text:a.map(s).join(" ")},"*")}catch(e){}}' +
    '["log","info","warn","error"].forEach(function(k){var o=console[k];console[k]=function(){p(k,[].slice.call(arguments));try{o.apply(console,arguments)}catch(e){}}});' +
    'window.addEventListener("error",function(e){p("error",[e.message+(e.lineno?" (regel "+e.lineno+")":"")])});' +
    'window.addEventListener("unhandledrejection",function(e){p("error",["Unhandled promise: "+s(e.reason)])});})();<\/script>';

  function buildPreviewHtml() {
    const name = state.files.has('index.html') ? 'index.html' : Array.from(state.files.keys()).find(n => /\.html?$/i.test(n));
    if (!name) return '<p style="font-family:sans-serif;color:#666;padding:20px">Geen HTML-bestand om te tonen. Maak index.html aan.</p>';
    let html = state.files.get(name).session.getValue();
    const get = n => { const f = state.files.get(n); return f ? f.session.getValue() : null; };
    html = html.replace(/<link\b[^>]*>/gi, tag => {
      if (!/rel\s*=\s*["']?stylesheet/i.test(tag)) return tag;
      const m = tag.match(/href\s*=\s*(?:["']([^"']+)["']|([^\s>"']+))/i); const c = m && get(m[1] || m[2]);
      return c === null || !m ? tag : '<style>' + c.replace(/<\/style/gi, '<\\/style') + '</style>';
    });
    html = html.replace(/<script\b([^>]*?)\bsrc\s*=\s*(?:"([^"]+)"|'([^']+)'|([^\s>"']+))([^>]*)>\s*<\/script>/gi, (all, a, s1, s2, s3, b) => {
      const c = get(s1 || s2 || s3); return c === null ? all : '<script' + a + b + '>' + c.replace(/<\/script/gi, '<\\/script') + '<\/script>';
    });
    return /<head[^>]*>/i.test(html) ? html.replace(/<head[^>]*>/i, m => m + BRIDGE) : BRIDGE + html;
  }

  function runPreview() {
    if (!state.slug) { preview.srcdoc = ''; return; }
    clearConsole(); preview.srcdoc = buildPreviewHtml();
  }
  let liveTimer = null;
  function scheduleLive(force) {
    if (!force && !$('#chkLive').checked) return;
    clearTimeout(liveTimer); liveTimer = setTimeout(runPreview, force ? 0 : 450);
  }

  function clearConsole() { $('#consoleList').textContent = ''; state.errors = 0; $('#errCount').hidden = true; }
  function consoleAdd(type, text, withFix) {
    const list = $('#consoleList'); const li = document.createElement('li'); li.className = type;
    li.textContent = (type === 'error' ? '✖ ' : type === 'warn' ? '⚠ ' : '› ') + String(text).slice(0, 2000);
    if (type === 'error') {
      state.errors++; const b = $('#errCount'); b.textContent = state.errors; b.hidden = false;
      if (CAN_AI && withFix !== false) { const fix = Object.assign(document.createElement('button'), { className: 'btn', textContent: '🛠 Fix met AI' }); fix.addEventListener('click', () => sendAi('Ik krijg deze fout:\n' + String(text).slice(0, 800) + '\nWat is er mis en hoe los ik het op?')); li.appendChild(fix); }
    }
    list.appendChild(li); while (list.children.length > 200) list.removeChild(list.firstChild); list.scrollTop = list.scrollHeight;
  }
  window.addEventListener('message', e => {
    if (e.source !== preview.contentWindow || !e.data || e.data.__ss !== 1) return;
    consoleAdd(['log', 'info', 'warn', 'error'].includes(e.data.type) ? e.data.type : 'log', e.data.text);
  });

  /* ---------- PHP uitvoeren (alleen beheerders) ---------- */
  async function runPhp() {
    if (!CAN_PHP || !state.slug) return;
    const names = Array.from(state.files.keys()).filter(n => /\.php$/i.test(n)).sort();
    const entry = /\.php$/i.test(state.current || '') ? state.current : (names.includes('index.php') ? 'index.php' : names[0]);
    if (!entry) { setStatus('Maak eerst een .php-bestand (bijvoorbeeld index.php).', 'err'); return; }
    await saveCurrent(true);
    const btn = $('#btnPhp'); btn.disabled = true; setStatus('PHP draait…');
    try {
      const r = await api('api/php_run.php', { body: { slug: state.slug, file: entry, query: $('#phpQuery').value.trim().replace(/^\?/, '') } });
      clearConsole();
      const out = r.stdout || '';
      const html = /<[a-z!][\s\S]*>/i.test(out) ? out : '<pre style="font:14px ui-monospace,monospace;white-space:pre-wrap;margin:12px">' + out.replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c]) + '</pre>';
      preview.srcdoc = /<head[^>]*>/i.test(html) ? html.replace(/<head[^>]*>/i, m => m + BRIDGE) : BRIDGE + html;
      (r.stderr || '').split('\n').filter(Boolean).forEach(l => consoleAdd(/fatal|error|exception/i.test(l) ? 'error' : 'warn', l));
      consoleAdd(r.timed_out ? 'error' : 'info', 'PHP: ' + entry + ' klaar in ' + r.ms + ' ms (exit ' + r.exit + ')' + (r.timed_out ? ' — afgebroken: tijdslimiet' : '') + (r.truncated ? ' — uitvoer ingekort' : ''), false);
      setStatus('PHP klaar', r.exit === 0 && !r.timed_out ? 'ok' : 'err');
    } catch (e) { setStatus(e.message, 'err'); consoleAdd('error', e.message, false); }
    finally { btn.disabled = false; }
  }
  if ($('#btnPhp')) { $('#btnPhp').addEventListener('click', runPhp); $('#phpQuery').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); runPhp(); } }); }

  /* ---------- AI ---------- */
  const msgBox = $('#aiMessages');
  function addMsg(cls, text) { const d = document.createElement('div'); d.className = 'msg ' + cls; d.textContent = text; msgBox.appendChild(d); msgBox.scrollTop = msgBox.scrollHeight; return d; }

  DOMPurify.addHook('afterSanitizeAttributes', n => { if (n.tagName === 'A') { n.setAttribute('target', '_blank'); n.setAttribute('rel', 'noopener noreferrer nofollow'); } });

  function renderAssistant(el, markdown, opts = {}) {
    el.className = 'msg assistant' + (opts.reader ? ' readbody' : '');
    el.innerHTML = DOMPurify.sanitize(marked.parse(markdown, { gfm: true, breaks: false }));
    $$('pre > code', el).forEach(code => {
      const pre = code.parentElement; const lang = ((code.className.match(/language-([\w-]+)/) || [])[1] || '').toLowerCase();
      try { hljs.highlightElement(code); } catch (e) { /* onbekende taal */ }
      const lines = code.textContent.split('\n').length;
      const bar = document.createElement('div'); bar.className = 'codebar';
      const l = document.createElement('span'); l.className = 'lang'; l.textContent = (lang || 'code') + ' · ' + lines + ' regels'; bar.appendChild(l);
      const mk = (label, fn, title) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'btn'; b.textContent = label; if (title) b.title = title; b.addEventListener('click', fn); bar.appendChild(b); return b; };
      const text = code.textContent;
      mk('Toepassen in editor', () => applyToEditor(text, lang));
      mk('Nieuw bestand', () => newFile(lang === 'css' ? 'nieuw.css' : lang === 'js' || lang === 'javascript' ? 'nieuw.js' : 'nieuw.html', text));
      const copy = mk('Kopieer', async () => { try { await navigator.clipboard.writeText(text); copy.textContent = 'Gekopieerd ✓'; setTimeout(() => copy.textContent = 'Kopieer', 1500); } catch (e) { copy.textContent = 'Mislukt'; } });
      if (!opts.reader && lines > 14) {          // lange blokken standaard ingeklapt, zodat het antwoord overzichtelijk blijft
        pre.classList.add('collapsed');
        const tg = mk('Uitklappen', () => { const c = pre.classList.toggle('collapsed'); tg.textContent = c ? 'Uitklappen' : 'Inklappen'; });
      }
      const wrap = mk('Regelbreuk', () => { pre.classList.toggle('nowrap'); wrap.classList.toggle('active'); }, 'Lange regels afbreken of horizontaal scrollen');
      wrap.classList.add('active');
      pre.insertBefore(bar, code);
    });
    if (!opts.reader) {
      const head = document.createElement('div'); head.className = 'mhead';
      const who = document.createElement('span'); who.className = 'who'; who.textContent = '✨ ' + (opts.label || 'AI'); head.appendChild(who);
      const read = Object.assign(document.createElement('button'), { type: 'button', className: 'icon', title: 'Antwoord groot lezen', textContent: '⤢ Lezen' });
      read.addEventListener('click', () => { renderAssistant($('#readBody'), markdown, { reader: true }); $('#dlgRead').showModal(); });
      const cp = Object.assign(document.createElement('button'), { type: 'button', className: 'icon', title: 'Hele antwoord kopiëren', textContent: '📋' });
      cp.addEventListener('click', async () => { try { await navigator.clipboard.writeText(markdown); cp.textContent = '✓'; setTimeout(() => cp.textContent = '📋', 1200); } catch (e) { /* geen klembord */ } });
      head.append(read, cp); el.prepend(head);
    }
  }

  async function applyToEditor(text, lang) {
    if (!state.current) { setStatus('Open eerst een bestand.', 'err'); return; }
    const ext = state.current.split('.').pop().toLowerCase();
    const same = { html: ['html', 'htm', ''], css: ['css'], js: ['js', 'javascript'], json: ['json'] }[ext];
    const warn = same && lang && !same.includes(lang) ? '\n\nLet op: dit codeblok lijkt "' + lang + '" en jouw bestand is ".' + ext + '".' : '';
    const ok = await ask({ title: 'Toepassen in ' + state.current + '?', text: 'De inhoud van het bestand wordt vervangen. Met Ctrl+Z maak je het ongedaan.' + warn, ok: 'Toepassen', input: false });
    if (!ok) return;
    editor.selectAll(); editor.insert(text); editor.moveCursorTo(0, 0); editor.focus(); setStatus('AI-code toegepast in ' + state.current, 'ok');
  }

  // --- AI: streaming (SSE) met terugval op één-keer-antwoord ------------------------------------------------
  let aiAbort = null;
  function setAiBusy(on) {
    state.busy = on;
    const b = $('#aiSend');
    b.textContent = on ? '■ Stop' : 'Verstuur';
    b.type = on ? 'button' : 'submit';
    b.disabled = !on && !CAN_AI;
  }
  $('#aiSend').addEventListener('click', () => { if (state.busy && aiAbort) aiAbort.abort(); });

  function nearBottom() { return msgBox.scrollHeight - msgBox.scrollTop - msgBox.clientHeight < 80; }

  /** Leest de SSE-stroom. Geeft {text, status}; status: done | stopped | error | unsupported */
  async function streamAi(body, el, signal) {
    let res;
    try {
      res = await fetch('api/ai_stream.php', { method: 'POST', credentials: 'same-origin', signal,
        headers: { 'Content-Type': 'application/json', 'Accept': 'text/event-stream', 'X-CSRF-Token': state.csrf }, body: JSON.stringify(body) });
    } catch (e) { if (e.name === 'AbortError') return { text: '', status: 'stopped' }; return { text: '', status: 'unsupported' }; }
    const type = res.headers.get('Content-Type') || '';
    if (!type.includes('text/event-stream')) {
      let d = null; try { d = await res.json(); } catch (e) { /* geen JSON */ }
      if (d && d.error) return { text: '', status: 'error', error: d.error };
      return { text: '', status: 'unsupported' };
    }
    const reader = res.body.getReader(); const dec = new TextDecoder();
    let buf = '', text = '', status = 'done', error = '', raf = 0, thinking = false;
    const paint = () => {
      raf = 0; const stick = nearBottom();
      el.className = 'msg assistant streaming';
      el.innerHTML = DOMPurify.sanitize(marked.parse(text, { gfm: true, breaks: false }));
      if (stick) msgBox.scrollTop = msgBox.scrollHeight;
    };
    const handle = (ev, data) => {
      if (ev === 'delta') { text += data.t || ''; if (!raf) raf = requestAnimationFrame(paint); }
      else if (ev === 'think' && !text && !thinking) { thinking = true; el.textContent = 'Redeneren…'; }
      else if (ev === 'error') { status = 'error'; error = data.error || 'Onbekende fout.'; }
    };
    try {
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n\n')) !== -1) {
          const block = buf.slice(0, i); buf = buf.slice(i + 2);
          let ev = 'message', data = '';
          for (const line of block.split('\n')) {
            if (line.startsWith('event:')) ev = line.slice(6).trim();
            else if (line.startsWith('data:')) data += line.slice(5).trim();
          }
          if (!data) continue;
          try { handle(ev, JSON.parse(data)); } catch (e) { /* kapotte frame negeren */ }
        }
      }
    } catch (e) { status = e.name === 'AbortError' ? 'stopped' : (text ? 'error' : 'unsupported'); if (status === 'error') error = 'Verbinding onderbroken.'; }
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    return { text, status, error };
  }

  async function sendAi(prompt) {
    if (state.busy || !CAN_AI) return;
    const model = $('#aiModel').value; const provider = model.startsWith('gemini') ? 'gemini' : 'deepseek';
    if (!state.keys[provider]) { addMsg('error', 'Geen ' + provider + '-key ingesteld. Voeg je eigen key toe bij ⚙ Instellingen.'); openSettings(); return; }
    layout.show('ai');
    addMsg('user', prompt);
    const pending = addMsg('pending', 'Even nadenken…'); setAiBusy(true); aiAbort = new AbortController();
    const file = state.current ? { name: state.current, content: state.files.get(state.current).session.getValue() } : null;
    const body = { prompt, model, file, history: state.history.slice(-6) };
    const label = $('#aiModel').selectedOptions[0].textContent;
    const keep = t => state.history.push({ role: 'user', content: prompt }, { role: 'assistant', content: t.slice(0, 4000) });
    try {
      const r = await streamAi(body, pending, aiAbort.signal);
      if (r.status === 'unsupported') { // streaming werkt niet (proxy buffert, geen SSE): gewoon in één keer
        pending.className = 'msg pending'; pending.textContent = 'Even nadenken…';
        const d = await api('api/ai_chat.php', { body });
        renderAssistant(pending, d.reply, { label }); keep(d.reply);
      } else if (r.status === 'error' && !r.text) {
        pending.className = 'msg error'; pending.textContent = r.error;
      } else {
        if (r.text) { renderAssistant(pending, r.text, { label }); keep(r.text); }
        else pending.remove();
        if (r.status === 'stopped') addMsg('pending', r.text ? 'Gestopt — gedeeltelijk antwoord bewaard.' : 'Gestopt.');
        if (r.status === 'error') addMsg('error', r.error);
      }
    } catch (e) { pending.className = 'msg error'; pending.textContent = e.message; }
    finally { aiAbort = null; setAiBusy(false); msgBox.scrollTop = msgBox.scrollHeight; }
  }

  $('#aiForm').addEventListener('submit', e => { e.preventDefault(); const t = $('#aiInput').value.trim(); if (!t) return; $('#aiInput').value = ''; sendAi(t); });
  $('#aiInput').addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('#aiForm').requestSubmit(); } });
  $('#aiClear').addEventListener('click', () => { state.history = []; msgBox.textContent = ''; addMsg('sys', 'Gesprek gewist.'); });
  $('#aiModel').value = store.get('ss_model', 'deepseek-chat');
  $('#aiModel').addEventListener('change', () => store.set('ss_model', $('#aiModel').value));

  /* ---------- Instellingen (AI-keys) ---------- */
  const dlgSettings = $('#dlgSettings');
  async function refreshKeys() {
    if (!CAN_AI) return;
    try { const d = await api('api/ai_keys.php'); state.keys = d.providers; } catch (e) { /* toont zich bij gebruik */ }
    $$('.keyrow', dlgSettings).forEach(r => { const has = !!state.keys[r.dataset.provider]; const s = $('[data-status]', r); s.textContent = has ? '· opgeslagen ✓' : '· niet ingesteld'; s.classList.toggle('ok', has); });
  }
  async function openSettings() { await refreshKeys(); $('#settingsMsg').textContent = ''; dlgSettings.showModal(); }
  $$('.keyrow', dlgSettings).forEach(row => {
    const provider = row.dataset.provider;
    $('[data-save]', row).addEventListener('click', async () => {
      const inp = $('[data-key]', row); const msg = $('#settingsMsg');
      try { await api('api/ai_keys.php', { body: { action: 'save', provider, key: inp.value.trim() } }); inp.value = ''; msg.textContent = 'Key opgeslagen (versleuteld).'; await refreshKeys(); }
      catch (e) { msg.textContent = e.message; }
    });
    $('[data-delete]', row).addEventListener('click', async () => {
      try { await api('api/ai_keys.php', { body: { action: 'delete', provider } }); $('#settingsMsg').textContent = 'Key verwijderd.'; await refreshKeys(); }
      catch (e) { $('#settingsMsg').textContent = e.message; }
    });
  });
  $('#btnSettings').addEventListener('click', openSettings);


  /* ---------- Indeling: kolommen en blokken ---------- */
  const PANELS = { files: ['files', 'Bestanden'], editor: ['editorPane', 'Editor'], preview: ['previewPane', 'Preview'], console: ['consolePane', 'Console'], ai: ['aiPane', 'AI-assistent'] };
  const PRESETS = {
    three:   { label: '3 kolommen (standaard)', cols: [{ w: .9, p: [['editor', .8], ['files', .2]] }, { w: 1.7, p: [['preview', .75], ['console', .25]] }, { w: .6, p: [['ai', 1]] }] },
    four:    { label: '4 kolommen', cols: [{ w: .45, p: [['files', 1]] }, { w: 1.2, p: [['editor', 1]] }, { w: 1, p: [['preview', .72], ['console', .28]] }, { w: 1.05, p: [['ai', 1]] }] },
    read:    { label: 'AI lezen (breed antwoord)', cols: [{ w: .9, p: [['editor', .8], ['files', .2]] }, { w: 1.3, p: [['ai', 1]] }] },
    preview: { label: 'Editor + preview', cols: [{ w: 1, p: [['editor', .8], ['files', .2]] }, { w: 1, p: [['preview', .72], ['console', .28]] }] },
    editai:  { label: 'Editor + AI', cols: [{ w: 1.1, p: [['editor', .8], ['files', .2]] }, { w: 1, p: [['ai', 1]] }] },
    editor:  { label: 'Alleen editor', cols: [{ w: 1, p: [['editor', .8], ['files', .2]] }] },
    view:    { label: 'Alleen preview', cols: [{ w: 1, p: [['preview', .75], ['console', .25]] }] },
  };
  const layout = {
    cols: null, name: 'three',
    clone(c) { return JSON.parse(JSON.stringify(c)); },
    valid(c) {
      if (!Array.isArray(c) || !c.length || c.length > 4) return false;
      const seen = new Set();
      for (const col of c) {
        if (!col || typeof col.w !== 'number' || !Array.isArray(col.p) || !col.p.length) return false;
        for (const x of col.p) { if (!Array.isArray(x) || !PANELS[x[0]] || seen.has(x[0]) || typeof x[1] !== 'number') return false; seen.add(x[0]); }
      }
      return true;
    },
    init() {
      const sel = $('#layoutPreset');
      for (const [k, v] of Object.entries(PRESETS)) sel.add(new Option(v.label, k));
      sel.add(new Option('Eigen indeling', 'custom'));
      let saved = null; try { saved = JSON.parse(store.get('ss_layout', 'null')); } catch (e) { saved = null; }
      if (saved && layout.valid(saved.cols)) { layout.cols = saved.cols; layout.name = saved.name || 'custom'; }
      else { layout.name = innerWidth >= 1200 ? 'three' : 'preview'; layout.cols = layout.clone(PRESETS[layout.name].cols); }
      layout.apply();
    },
    save() { store.set('ss_layout', JSON.stringify({ name: layout.name, cols: layout.cols })); },
    preset(name) {
      if (!PRESETS[name]) { return; }
      layout.name = name; layout.cols = layout.clone(PRESETS[name].cols); layout.apply(); layout.save();
    },
    visible(id) { return layout.cols.some(c => c.p.some(x => x[0] === id)); },
    show(id) {
      if (layout.visible(id)) return;
      if (layout.cols.length < 4) layout.cols.push({ w: 1, p: [[id, 1]] }); else layout.cols[layout.cols.length - 1].p.push([id, .5]);
      layout.name = 'custom'; layout.apply(); layout.save();
    },
    hide(id) {
      layout.cols = layout.cols.map(c => ({ w: c.w, p: c.p.filter(x => x[0] !== id) })).filter(c => c.p.length);
      if (!layout.cols.length) layout.cols = [{ w: 1, p: [['editor', 1]] }];
      layout.name = 'custom'; layout.apply(); layout.save();
    },
    toggle(id) { if (layout.visible(id)) layout.hide(id); else layout.show(id); },

    /* DOM opbouwen: elk blok wordt in een kolom verplaatst; verborgen blokken gaan naar #parking */
    apply() {
      const main = $('#main'), park = $('#parking');
      for (const [, v] of Object.entries(PANELS)) { const el = document.getElementById(v[0]); if (el.parentElement !== park) park.appendChild(el); }
      main.textContent = '';
      layout.cols.forEach((col, ci) => {
        if (ci) main.appendChild(layout.splitter('v', () => [main.children[ci * 2 - 2], main.children[ci * 2]]));
        const c = document.createElement('div'); c.className = 'col'; c.style.flex = col.w + ' 1 0';
        col.p.forEach((x, pi) => {
          if (pi) c.appendChild(layout.splitter('h', () => [c.children[pi * 2 - 2], c.children[pi * 2]]));
          const el = document.getElementById(PANELS[x[0]][0]); el.style.flex = x[1] + ' 1 0'; c.appendChild(el);
        });
        main.appendChild(c);
      });
      const sel = $('#layoutPreset'); sel.value = PRESETS[layout.name] ? layout.name : 'custom';
      $('#btnAi').classList.toggle('active', layout.visible('ai'));
      setTimeout(() => { editor.resize(); if (state.slug) runPreview(); }, 0);
    },

    splitter(dir, getPair) {
      const s = document.createElement('div'); s.className = 'split ' + dir; s.setAttribute('role', 'separator'); s.tabIndex = 0;
      s.setAttribute('aria-orientation', dir === 'v' ? 'vertical' : 'horizontal'); s.title = 'Sleep om de grootte aan te passen';
      const horiz = dir === 'h', min = horiz ? 70 : 180;
      const size = el => horiz ? el.getBoundingClientRect().height : el.getBoundingClientRect().width;
      const resize = delta => {
        const [a, b] = getPair(); const sibs = Array.from(a.parentElement.children).filter(n => !n.classList.contains('split'));
        const sizes = sibs.map(size); sibs.forEach((n, i) => { n.style.flex = sizes[i] + ' 1 0'; });
        const ia = sibs.indexOf(a), ib = sibs.indexOf(b); const d = Math.max(min - sizes[ia], Math.min(delta, sizes[ib] - min));
        a.style.flex = (sizes[ia] + d) + ' 1 0'; b.style.flex = (sizes[ib] - d) + ' 1 0';
        return sibs;
      };
      const commit = () => { layout.readSizes(); layout.name = 'custom'; $('#layoutPreset').value = 'custom'; layout.save(); editor.resize(); };
      s.addEventListener('pointerdown', e => {
        e.preventDefault(); s.setPointerCapture(e.pointerId); document.body.classList.add('dragging');
        const start = horiz ? e.clientY : e.clientX; const [a, b] = getPair(); const sa = size(a), sb = size(b);
        const sibs = Array.from(a.parentElement.children).filter(n => !n.classList.contains('split')); const base = sibs.map(size);
        const move = ev => { sibs.forEach((n, i) => { n.style.flex = base[i] + ' 1 0'; }); const d = Math.max(min - sa, Math.min((horiz ? ev.clientY : ev.clientX) - start, sb - min)); a.style.flex = (sa + d) + ' 1 0'; b.style.flex = (sb - d) + ' 1 0'; editor.resize(); };
        const up = () => { s.removeEventListener('pointermove', move); s.removeEventListener('pointerup', up); s.removeEventListener('pointercancel', up); document.body.classList.remove('dragging'); commit(); };
        s.addEventListener('pointermove', move); s.addEventListener('pointerup', up); s.addEventListener('pointercancel', up);
      });
      s.addEventListener('keydown', e => {
        const k = horiz ? ['ArrowUp', 'ArrowDown'] : ['ArrowLeft', 'ArrowRight']; const i = k.indexOf(e.key); if (i < 0) return;
        e.preventDefault(); resize(i ? 24 : -24); commit();
      });
      return s;
    },
    /* huidige groottes (px) terugschrijven als verhoudingen, gemiddeld 1 */
    readSizes() {
      const cols = Array.from($('#main').children).filter(n => n.classList.contains('col'));
      const norm = arr => { const t = arr.reduce((x, y) => x + y, 0) || 1; return arr.map(v => Math.round(v / t * arr.length * 1000) / 1000); };
      const ws = norm(cols.map(c => c.getBoundingClientRect().width));
      cols.forEach((c, i) => {
        layout.cols[i].w = ws[i];
        const panes = Array.from(c.children).filter(n => !n.classList.contains('split'));
        const hs = norm(panes.map(p => p.getBoundingClientRect().height));
        panes.forEach((p, j) => { layout.cols[i].p[j][1] = hs[j]; });
      });
    },

    /* Dialoog: per blok kolom kiezen en volgorde wijzigen */
    renderDialog() {
      const box = $('#layoutRows'); box.textContent = '';
      for (const id of Object.keys(PANELS)) {
        const ci = layout.cols.findIndex(c => c.p.some(x => x[0] === id));
        const row = document.createElement('div'); row.className = 'lrow';
        const name = document.createElement('span'); name.className = 'lname'; name.textContent = PANELS[id][1];
        const sel = document.createElement('select'); sel.setAttribute('aria-label', 'Kolom voor ' + PANELS[id][1]);
        sel.add(new Option('Verborgen', '-1'));
        for (let n = 0; n < 4; n++) sel.add(new Option('Kolom ' + (n + 1), String(n)));
        sel.value = String(ci);
        sel.addEventListener('change', () => layout.move(id, parseInt(sel.value, 10)));
        const up = Object.assign(document.createElement('button'), { type: 'button', className: 'icon', title: 'Omhoog', textContent: '▲', disabled: ci < 0 });
        const dn = Object.assign(document.createElement('button'), { type: 'button', className: 'icon', title: 'Omlaag', textContent: '▼', disabled: ci < 0 });
        up.addEventListener('click', () => layout.shift(id, -1)); dn.addEventListener('click', () => layout.shift(id, 1));
        row.append(name, sel, up, dn); box.appendChild(row);
      }
    },
    move(id, target) {
      // bouw een kolomlijst op index (0..3); behoud breedtes van bestaande kolommen
      const slots = [0, 1, 2, 3].map(i => layout.cols[i] ? { w: layout.cols[i].w, p: layout.cols[i].p.filter(x => x[0] !== id) } : { w: 1, p: [] });
      if (target >= 0) slots[target].p.push([id, .6]);
      let cols = slots.filter(c => c.p.length);
      if (!cols.length) cols = [{ w: 1, p: [['editor', 1]] }];
      layout.cols = cols; layout.name = 'custom'; layout.apply(); layout.save(); layout.renderDialog();
    },
    shift(id, d) {
      const col = layout.cols.find(c => c.p.some(x => x[0] === id)); if (!col) return;
      const i = col.p.findIndex(x => x[0] === id), j = i + d; if (j < 0 || j >= col.p.length) return;
      [col.p[i], col.p[j]] = [col.p[j], col.p[i]]; layout.name = 'custom'; layout.apply(); layout.save(); layout.renderDialog();
    },
  };

  /* ---------- Visuele modus ---------- */
  const visTarget = () => /\.html?$/i.test(state.current || '') ? state.current : (state.files.has('index.html') ? 'index.html' : null);
  visual = SSVisual.create({
    wrap: $('#visWrap'), frame: $('#visFrame'), bar: $('#visBar'), props: $('#visProps'), note: $('#visNote'),
    ask,
    getName: () => visTarget(),
    getSource: () => { const n = visTarget(); return n ? state.files.get(n).session.getValue() : null; },
    getFile: n => state.files.has(n) ? state.files.get(n).session.getValue() : null,
    setSource: text => {
      const n = visTarget(); if (!n) return;
      const s = state.files.get(n).session, Range = ace.require('ace/range').Range, last = s.getLength() - 1;
      s.replace(new Range(0, 0, last, s.getLine(last).length), text);
    },
    save: () => saveCurrent(true),
  });
  function setMode(m) {
    $$('#modeSeg button').forEach(x => x.classList.toggle('active', x.dataset.mode === m));
    if (m === 'visual') { $('#previewWrap').hidden = true; visual.activate(); }
    else { visual.deactivate(); $('#previewWrap').hidden = false; scheduleLive(true); }
    store.set('ss_mode', m);
  }
  $$('#modeSeg button').forEach(b => b.addEventListener('click', () => { if (state.slug || b.dataset.mode === 'preview') setMode(b.dataset.mode); }));

  /* ---------- Knoppen ---------- */
  $('#btnAi').addEventListener('click', () => layout.toggle('ai'));
  $$('#devices button').forEach(b => b.addEventListener('click', () => {
    $$('#devices button').forEach(x => x.classList.toggle('active', x === b)); preview.style.width = b.dataset.w; preview.style.maxWidth = '100%'; if (visual) visual.setWidth(b.dataset.w);
  }));
  $('#btnFull').addEventListener('click', () => { if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen?.().catch(() => setStatus('Volledig scherm niet beschikbaar', 'err')); });
  document.addEventListener('fullscreenchange', () => { $('#btnFull').classList.toggle('active', !!document.fullscreenElement); editor.resize(); });
  $('#btnSave').addEventListener('click', () => saveCurrent(true));
  $('#btnRun').addEventListener('click', () => runPreview());
  $('#fileNew').addEventListener('click', () => newFile());
  $('#sbNew').addEventListener('click', createSandbox);
  $('#emptyNew').addEventListener('click', createSandbox);
  $('#sbSelect').addEventListener('change', e => openSandbox(e.target.value));
  $('#consoleClear').addEventListener('click', clearConsole);
  window.addEventListener('beforeunload', e => { if (anyDirty()) { e.preventDefault(); e.returnValue = ''; } });
  window.addEventListener('resize', () => editor.resize());
  $('#btnLayout').addEventListener('click', () => { layout.renderDialog(); $('#dlgLayout').showModal(); });
  $('#layoutPreset').addEventListener('change', e => layout.preset(e.target.value));
  $('#layoutReset').addEventListener('click', () => layout.preset('three'));
  setInterval(updateExpiry, 60000);

  /* ---------- Start ---------- */
  (async function init() {
    layout.init();
    if (!CAN_SANDBOX) { $('#emptyState p').textContent = 'Je account mag geen sandboxes gebruiken.'; $('#emptyNew').hidden = true; $('#sbNew').hidden = true; $('#emptyState').hidden = false; return; }
    try {
      await loadSandboxes(); await refreshKeys();
      const wanted = new URLSearchParams(location.search).get('sandbox') || store.get('ss_last_sandbox', '');
      const slug = state.sandboxes.some(s => s.slug === wanted) ? wanted : (state.sandboxes[0] && state.sandboxes[0].slug);
      renderSandboxes();
      if (slug) await openSandbox(slug);
      else { editor.setValue('', -1); editor.setReadOnly(true); }
    } catch (e) { setStatus(e.message, 'err'); }
  })();
})();
