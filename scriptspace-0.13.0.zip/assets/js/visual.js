/* visual.js — visuele (WYSIWYG) modus voor HTML-bestanden in de playground.
 *
 * Werking: de HTML wordt in een iframe zonder scripts getoond (sandbox="allow-same-origin") en <body> is bewerkbaar.
 * Bij wijzigen wordt ALLEEN de inhoud van <body> teruggeschreven in de broncode; <head>, doctype, scripts en CSS blijven onaangeraakt.
 * Aangemaakt: SSVisual.create({...}) in playground.js.
 * Afbeeldingen: invoegen met breedte/alt-tekst; klik op een afbeelding toont een formaatbalk (buiten het iframe, dus nooit in de opgeslagen HTML). */
(function () {
  'use strict';

  const BLOCK = new Set(['address', 'article', 'aside', 'blockquote', 'details', 'dd', 'div', 'dl', 'dt', 'fieldset', 'figcaption', 'figure', 'footer', 'form',
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'header', 'hr', 'li', 'main', 'nav', 'ol', 'p', 'pre', 'section', 'table', 'tbody', 'td', 'tfoot', 'th', 'thead', 'tr', 'ul',
    'script', 'style', 'noscript', 'template']);
  const VOID = new Set(['hr', 'br', 'img', 'input', 'meta', 'link', 'area', 'base', 'col', 'embed', 'source', 'track', 'wbr']);
  const RAW = new Set(['pre', 'textarea', 'script', 'style', 'noscript', 'template']);

  const EDIT_CSS =
    'html{cursor:text}body{min-height:100vh;outline:none}' +
    'body *:hover{outline:1px dashed rgba(139,92,246,.65);outline-offset:1px}' +
    '[data-ss-sel]{outline:2px solid #8b5cf6!important;outline-offset:2px}img[data-ss-sel]{outline-width:3px!important}' +
    'script,style,noscript,template{display:none!important}img{cursor:pointer}a{cursor:text}';

  const esc = s => String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const hex2 = n => ('0' + Math.max(0, Math.min(255, n | 0)).toString(16)).slice(-2);
  function toHex(css) {
    const m = /rgba?\((\d+)[ ,]+(\d+)[ ,]+(\d+)(?:[ ,/]+([\d.]+))?/.exec(css || '');
    if (!m || (m[4] !== undefined && parseFloat(m[4]) === 0)) return '';
    return '#' + hex2(+m[1]) + hex2(+m[2]) + hex2(+m[3]);
  }

  /** Strenge breedte-validatie: alleen getal(+px) of getal+% (1-2000 px, 1-100 %). '' = origineel, null = ongeldig.
   *  Geeft altijd een zelfgebouwde string terug (cijfers + eenheid), nooit de invoer zelf. */
  function parseWidth(v) {
    const t = String(v == null ? '' : v).trim();
    if (t === '') return '';
    const m = /^(\d{1,4})\s*(px|%)?$/i.exec(t);
    if (!m) return null;
    const n = parseInt(m[1], 10), unit = (m[2] || 'px').toLowerCase();
    if (unit === '%' ? (n < 1 || n > 100) : (n < 1 || n > 2000)) return null;
    return n + unit;
  }
  const WIDTH_MSG = 'Gebruik een getal met px (1-2000) of % (1-100), bijvoorbeeld 300px of 50%. Leeg laten = origineel.';

  /** Mooie inspringing voor blokken; inline-inhoud blijft ongemoeid. */
  function pretty(el, depth) {
    const kids = Array.from(el.childNodes);
    const structural = kids.some(k => k.nodeType === 1) &&
      kids.every(k => (k.nodeType === 1 && BLOCK.has(k.tagName.toLowerCase())) || (k.nodeType === 3 && !k.textContent.trim()) || k.nodeType === 8);
    if (!structural) { return el.innerHTML; }
    const pad = '  '.repeat(depth);
    let out = '';
    for (const k of kids) {
      if (k.nodeType === 3) { continue; }
      if (k.nodeType === 8) { out += '\n' + pad + '<!--' + k.data + '-->'; continue; }
      const tag = k.tagName.toLowerCase();
      if (RAW.has(tag)) { out += '\n' + pad + k.outerHTML; continue; }
      const shell = k.cloneNode(false).outerHTML;
      if (VOID.has(tag)) { out += '\n' + pad + shell; continue; }
      const open = shell.slice(0, shell.length - ('</' + tag + '>').length);
      const inner = pretty(k, depth + 1);
      out += '\n' + pad + open + (inner.startsWith('\n') ? inner + '\n' + pad : inner) + '</' + tag + '>';
    }
    return out;
  }

  /** Vervangt de inhoud van <body> in de bronstring; de rest blijft letterlijk staan. */
  function spliceBody(src, inner) {
    const low = src.toLowerCase();
    const open = /<body\b[^>]*>/i.exec(src);
    let start, end;
    if (open) {
      start = open.index + open[0].length;
      const c = low.lastIndexOf('</body');
      end = c >= start ? c : (low.lastIndexOf('</html') >= start ? low.lastIndexOf('</html') : src.length);
    } else {
      const h = /<\/head\s*>/i.exec(src);
      if (h) { start = h.index + h[0].length; const c = low.lastIndexOf('</html'); end = c >= start ? c : src.length; }
      else { start = 0; end = src.length; }
    }
    return src.slice(0, start) + inner + src.slice(end);
  }

  function create(o) {
    const $ = (s, r) => (r || document).querySelector(s);
    const frame = o.frame;
    const st = { active: false, dirty: false, syncing: false, sel: null, range: null, pushTimer: 0, reloadTimer: 0, name: null };
    let doc = null;

    /* ---------- Werkbalk ---------- */
    const bar = o.bar;
    bar.innerHTML =
      '<select data-block title="Soort tekstblok"><option value="">Stijl…</option><option value="<p>">Alinea</option><option value="<h1>">Kop 1</option><option value="<h2>">Kop 2</option><option value="<h3>">Kop 3</option><option value="<blockquote>">Citaat</option><option value="<pre>">Code</option></select>' +
      '<span class="vsep"></span>' +
      b('bold', '<b>B</b>', 'Vet (Ctrl+B)') + b('italic', '<i>I</i>', 'Cursief (Ctrl+I)') + b('underline', '<u>U</u>', 'Onderstreept (Ctrl+U)') + b('strikeThrough', '<s>S</s>', 'Doorgestreept') +
      '<span class="vsep"></span>' +
      b('insertUnorderedList', '• ≡', 'Opsomming') + b('insertOrderedList', '1. ≡', 'Genummerde lijst') +
      '<span class="vsep"></span>' +
      b('justifyLeft', '⇤', 'Links uitlijnen') + b('justifyCenter', '↔', 'Centreren') + b('justifyRight', '⇥', 'Rechts uitlijnen') +
      '<span class="vsep"></span>' +
      '<button type="button" class="icon" data-act="link" title="Link toevoegen">🔗</button><button type="button" class="icon" data-cmd="unlink" title="Link weghalen">⛓</button>' +
      '<button type="button" class="icon" data-act="image" title="Afbeelding invoegen">🖼</button><button type="button" class="icon" data-act="table" title="Tabel invoegen">▦</button>' +
      '<span class="vsep"></span>' +
      '<label class="vcolor" title="Tekstkleur">A<input type="color" data-color="foreColor" value="#000000"></label>' +
      '<label class="vcolor" title="Markeerkleur">▮<input type="color" data-color="hiliteColor" value="#ffff00"></label>' +
      b('removeFormat', 'Tx', 'Opmaak wissen') +
      '<span class="vsep"></span>' + b('undo', '↶', 'Ongedaan maken (Ctrl+Z)') + b('redo', '↷', 'Opnieuw (Ctrl+Y)');
    function b(cmd, label, title) { return '<button type="button" class="icon" data-cmd="' + cmd + '" title="' + title + '">' + label + '</button>'; }

    // Knoppen mogen de selectie in het iframe niet wegnemen
    bar.addEventListener('mousedown', e => { if (e.target.closest('button')) { e.preventDefault(); } });
    bar.addEventListener('click', async e => {
      const btn = e.target.closest('button'); if (!btn || !doc) return;
      if (btn.dataset.cmd) { run(btn.dataset.cmd); }
      else if (btn.dataset.act === 'link') { await insertLink(); }
      else if (btn.dataset.act === 'image') { await insertImage(); }
      else if (btn.dataset.act === 'table') { await insertTable(); }
    });
    bar.addEventListener('change', e => {
      const t = e.target;
      if ('block' in t.dataset) { if (t.value) { run('formatBlock', t.value); } t.value = ''; }
    });
    bar.addEventListener('input', e => { const t = e.target; if (t.dataset && t.dataset.color) { run(t.dataset.color, t.value); } });

    function restore() {
      if (!doc || !st.range) return;
      const s = doc.getSelection(); s.removeAllRanges(); s.addRange(st.range);
    }
    function run(cmd, val) {
      if (!doc) return;
      doc.defaultView.focus(); restore();
      try { doc.execCommand('styleWithCSS', false, true); doc.execCommand(cmd, false, val === undefined ? null : val); } catch (e) { /* niet ondersteund */ }
      edited();
    }
    function insertHtml(html) { if (!doc) return; doc.defaultView.focus(); restore(); try { doc.execCommand('insertHTML', false, html); } catch (e) { /* */ } edited(); }

    async function insertLink() {
      const keep = st.range;
      const url = await o.ask({ title: 'Link toevoegen', text: 'Selecteer eerst tekst in de pagina. Adres (https://…, mailto: of #anker):', value: 'https://', ok: 'Toevoegen',
        validate: v => /^(https?:\/\/[^\s"'<>]+|mailto:[^\s"'<>]+|#[\w-]+|\/[^\s"'<>]*)$/i.test(v) ? '' : 'Gebruik een adres dat begint met https://, mailto: of #.' });
      if (!url) return;
      st.range = keep; run('createLink', url);
    }
    async function insertImage() {
      const keep = st.range;
      const v = await o.ask({ title: 'Afbeelding invoegen', text: 'Adres (https://…) of de naam van een .svg-bestand uit deze sandbox:', value: 'https://', ok: 'Verder',
        validate: x => (/^https:\/\/[^\s"'<>]+$/i.test(x) || (/^[\w.-]+\.svg$/i.test(x) && o.getFile(x) !== null)) ? '' : 'Gebruik een https-adres of de naam van een bestaand .svg-bestand.' });
      if (!v) return;
      const w = await o.ask({ title: 'Breedte van de afbeelding', text: 'Breedte in px of % (bijvoorbeeld 300px of 50%). Leeg = originele grootte.', value: '', ok: 'Verder',
        validate: x => parseWidth(x) === null ? WIDTH_MSG : '' });
      if (w === null) return;
      const alt = await o.ask({ title: 'Alt-tekst', text: 'Korte beschrijving van de afbeelding voor screenreaders (optioneel).', value: '', ok: 'Invoegen',
        validate: x => x.length > 200 ? 'Maximaal 200 tekens.' : '' });
      if (alt === null) return;
      st.range = keep;
      const width = parseWidth(w);   // opnieuw gebouwd uit cijfers + eenheid, nooit de ruwe invoer
      const style = (width ? 'width:' + width + ';' : '') + 'max-width:100%;height:auto';
      const altA = ' alt="' + esc(alt.replace(/[\u0000-\u001f\u007f]/g, ' ')) + '"';
      if (/^https:/i.test(v)) { insertHtml('<img src="' + esc(v) + '"' + altA + ' style="' + style + '">'); }
      else { insertHtml('<img src="data:image/svg+xml;charset=utf-8,' + encodeURIComponent(o.getFile(v)) + '" data-ss-orig="' + esc(v) + '"' + altA + ' style="' + style + '">'); }
    }
    async function insertTable() {
      const keep = st.range;
      const v = await o.ask({ title: 'Tabel invoegen', text: 'Rijen x kolommen (bijv. 3x3, maximaal 12x8):', value: '3x3', ok: 'Invoegen',
        validate: x => { const m = /^(\d{1,2})\s*[x×]\s*(\d{1,2})$/i.exec(x); return m && +m[1] >= 1 && +m[1] <= 12 && +m[2] >= 1 && +m[2] <= 8 ? '' : 'Bijvoorbeeld 3x3.'; } });
      if (!v) return;
      const m = /^(\d+)\s*[x×]\s*(\d+)$/i.exec(v); st.range = keep;
      const cell = 'style="border:1px solid #999;padding:6px"';
      let h = '<table style="border-collapse:collapse;width:100%"><tbody>';
      for (let r = 0; r < +m[1]; r++) { h += '<tr>'; for (let c = 0; c < +m[2]; c++) { h += '<td ' + cell + '><br></td>'; } h += '</tr>'; }
      insertHtml(h + '</tbody></table><p><br></p>');
    }

    /* ---------- Afbeelding-formaatbalk (buiten het iframe: komt nooit in de opgeslagen HTML) ---------- */
    const ibar = document.createElement('div');
    ibar.className = 'vimgbar'; ibar.hidden = true; ibar.setAttribute('role', 'toolbar'); ibar.setAttribute('aria-label', 'Afbeelding aanpassen');
    const ib = (attr, label, title) => '<button type="button" ' + attr + ' title="' + title + '" aria-label="' + title + '">' + label + '</button>';
    ibar.innerHTML =
      [25, 50, 75, 100].map(n => ib('data-iw="' + n + '"', n + '%', 'Breedte ' + n + '%')).join('') +
      ib('data-ia="custom"', 'px…', 'Eigen breedte instellen') + ib('data-ia="orig"', '↺', 'Originele grootte') +
      '<span class="vsep"></span>' +
      ib('data-ia="left"', '⇤', 'Afbeelding links uitlijnen') + ib('data-ia="center"', '↔', 'Afbeelding centreren') + ib('data-ia="right"', '⇥', 'Afbeelding rechts uitlijnen') +
      '<span class="vsep"></span>' + ib('data-ia="del"', '🗑', 'Afbeelding verwijderen');
    const ihandle = document.createElement('div');
    ihandle.className = 'vimghandle'; ihandle.hidden = true; ihandle.title = 'Sleep om te schalen'; ihandle.setAttribute('aria-hidden', 'true');
    document.body.appendChild(ibar); document.body.appendChild(ihandle);

    const isImg = el => !!el && el.tagName === 'IMG';
    function applyWidth(img, css) {
      img.removeAttribute('width'); img.removeAttribute('height');
      if (css) { img.style.width = css; } else { img.style.removeProperty('width'); }
      img.style.maxWidth = '100%'; img.style.height = 'auto';
    }
    function placeImgBar() {
      const img = st.sel;
      if (!st.active || !doc || !isImg(img) || !doc.body.contains(img)) { ibar.hidden = true; ihandle.hidden = true; return; }
      const r = img.getBoundingClientRect(), fr = frame.getBoundingClientRect();
      const out = r.bottom < 0 || r.top > fr.height || r.right < 0 || r.left > fr.width;
      ibar.hidden = out; ihandle.hidden = out; if (out) return;
      const bw = ibar.offsetWidth, bh = ibar.offsetHeight;
      let top = fr.top + r.top - bh - 6; if (top < fr.top + 2) { top = fr.top + Math.max(r.top, 0) + 4; }
      let left = fr.left + r.left; left = Math.max(fr.left + 4, Math.min(left, fr.right - bw - 4));
      ibar.style.top = Math.round(top) + 'px'; ibar.style.left = Math.round(left) + 'px';
      ihandle.style.left = Math.round(fr.left + Math.min(r.right, fr.width) - 8) + 'px';
      ihandle.style.top = Math.round(fr.top + Math.min(r.bottom, fr.height) - 8) + 'px';
      const w = img.style.width;
      ibar.querySelectorAll('[data-iw]').forEach(x => x.setAttribute('aria-pressed', w === x.dataset.iw + '%' ? 'true' : 'false'));
      const al = (img.style.marginLeft === 'auto' ? (img.style.marginRight === 'auto' ? 'center' : 'right') : (img.style.marginRight === 'auto' ? 'left' : ''));
      ibar.querySelectorAll('[data-ia=left],[data-ia=center],[data-ia=right]').forEach(x => x.setAttribute('aria-pressed', x.dataset.ia === al ? 'true' : 'false'));
    }
    ibar.addEventListener('mousedown', e => { if (e.target.closest('button')) { e.preventDefault(); } });
    ibar.addEventListener('click', async e => {
      const btn = e.target.closest('button'); const img = st.sel; if (!btn || !isImg(img)) return;
      if (btn.dataset.iw) { applyWidth(img, btn.dataset.iw + '%'); }
      else {
        switch (btn.dataset.ia) {
          case 'orig': applyWidth(img, ''); break;
          case 'custom': {
            const cur = parseWidth(img.style.width) || '';
            const w = await o.ask({ title: 'Eigen breedte', text: 'Breedte in px of % (bijvoorbeeld 300px of 50%). Leeg = originele grootte.', value: cur, ok: 'Toepassen',
              validate: x => parseWidth(x) === null ? WIDTH_MSG : '' });
            if (w === null || !isImg(st.sel) || !doc.body.contains(st.sel)) return;
            applyWidth(st.sel, parseWidth(w)); break;
          }
          case 'left': case 'center': case 'right': {
            const a = btn.dataset.ia;
            img.style.display = 'block';
            img.style.marginLeft = a === 'left' ? '0' : 'auto'; img.style.marginRight = a === 'right' ? '0' : 'auto'; break;
          }
          case 'del': { const nxt = img.nextElementSibling || img.previousElementSibling || img.parentElement; img.remove(); select(nxt && nxt !== doc.body ? nxt : null); break; }
          default: return;
        }
      }
      edited(); placeImgBar();
    });
    let drag = null;
    ihandle.addEventListener('pointerdown', e => {
      const img = st.sel; if (!isImg(img) || e.button !== 0) return;
      e.preventDefault(); ihandle.setPointerCapture(e.pointerId);
      drag = { x: e.clientX, w: img.getBoundingClientRect().width };
    });
    ihandle.addEventListener('pointermove', e => {
      if (!drag || !isImg(st.sel)) return;
      applyWidth(st.sel, Math.max(1, Math.min(2000, Math.round(drag.w + e.clientX - drag.x))) + 'px'); placeImgBar();
    });
    const endDrag = () => { if (drag) { drag = null; edited(); } };
    ihandle.addEventListener('pointerup', endDrag); ihandle.addEventListener('pointercancel', endDrag);
    window.addEventListener('resize', placeImgBar);

    /* ---------- Eigenschappenpaneel ---------- */
    const props = o.props;
    props.innerHTML =
      '<span class="pname" data-f="tag">Klik op een element…</span>' +
      f('color', 'Tekst', '<input type="color" data-p="color">') + f('bg', 'Achtergrond', '<input type="color" data-p="backgroundColor"><button type="button" class="icon" data-clear="backgroundColor" title="Achtergrond wissen">✕</button>') +
      f('fs', 'Grootte', '<input type="number" min="6" max="200" step="1" data-p="fontSize" data-unit="px"> px') +
      f('pad', 'Binnenruimte', '<input type="number" min="0" max="200" step="2" data-p="padding" data-unit="px"> px') +
      f('mar', 'Buitenruimte', '<input type="number" min="0" max="200" step="2" data-p="margin" data-unit="px"> px') +
      f('rad', 'Afronding', '<input type="number" min="0" max="200" step="1" data-p="borderRadius" data-unit="px"> px') +
      f('w', 'Breedte', '<input type="text" size="7" maxlength="10" placeholder="auto" data-p="width">') +
      '<span class="pbtns"><button type="button" class="icon" data-el="parent" title="Bovenliggend element selecteren">⤒</button><button type="button" class="icon" data-el="up" title="Omhoog">▲</button><button type="button" class="icon" data-el="down" title="Omlaag">▼</button><button type="button" class="icon" data-el="dup" title="Dupliceren">⧉</button><button type="button" class="icon" data-el="del" title="Verwijderen">🗑</button></span>';
    function f(id, label, inner) { return '<label class="pf"><span>' + label + '</span>' + inner + '</label>'; }

    props.addEventListener('input', e => {
      const t = e.target; if (!st.sel || !t.dataset.p) return;
      let v = t.value.trim();
      if (t.dataset.p === 'width') { if (v !== '' && !/^(auto|\d+(\.\d+)?(px|%|rem|em|vw)?)$/i.test(v)) return; if (/^\d+(\.\d+)?$/.test(v)) v += 'px'; }
      else if (t.dataset.unit) { v = v === '' ? '' : v + t.dataset.unit; }
      st.sel.style[t.dataset.p] = v;
      edited();
    });
    props.addEventListener('click', e => {
      const b2 = e.target.closest('button'); if (!b2 || !st.sel) return;
      if (b2.dataset.clear) { st.sel.style[b2.dataset.clear] = ''; fillProps(); edited(); return; }
      const el = st.sel;
      switch (b2.dataset.el) {
        case 'parent': if (el.parentElement && el.parentElement !== doc.body) { select(el.parentElement); } return;
        case 'up': if (el.previousElementSibling) { el.parentNode.insertBefore(el, el.previousElementSibling); } break;
        case 'down': if (el.nextElementSibling) { el.parentNode.insertBefore(el.nextElementSibling, el); } break;
        case 'dup': { const c = el.cloneNode(true); c.removeAttribute('data-ss-sel'); el.after(c); break; }
        case 'del': { const nxt = el.nextElementSibling || el.previousElementSibling || el.parentElement; el.remove(); select(nxt && nxt !== doc.body ? nxt : null); break; }
      }
      edited();
    });

    function select(el) {
      if (st.sel) { st.sel.removeAttribute('data-ss-sel'); }
      st.sel = el && el !== doc.body && el !== doc.documentElement ? el : null;
      if (st.sel) { st.sel.setAttribute('data-ss-sel', ''); }
      fillProps();
    }
    function fillProps() {
      const tag = props.querySelector('[data-f=tag]');
      const inputs = props.querySelectorAll('[data-p]');
      if (!st.sel) { tag.textContent = 'Klik op een element…'; inputs.forEach(i => { i.disabled = true; }); placeImgBar(); return; }
      const cs = doc.defaultView.getComputedStyle(st.sel);
      tag.textContent = '<' + st.sel.tagName.toLowerCase() + '>' + (st.sel.className && typeof st.sel.className === 'string' ? ' .' + st.sel.className.trim().split(/\s+/)[0] : '');
      inputs.forEach(i => {
        i.disabled = false; const p = i.dataset.p;
        if (p === 'color') { i.value = toHex(cs.color) || '#000000'; }
        else if (p === 'backgroundColor') { i.value = toHex(cs.backgroundColor) || '#ffffff'; }
        else if (p === 'width') { i.value = st.sel.style.width || ''; }
        else { i.value = String(parseFloat(cs[p]) || 0); }
      });
      placeImgBar();
      if (isImg(st.sel) && !st.sel.complete) { st.sel.addEventListener('load', placeImgBar, { once: true }); }
    }

    /* ---------- Synchronisatie met de code ---------- */
    function edited() { st.dirty = true; placeImgBar(); clearTimeout(st.pushTimer); st.pushTimer = setTimeout(push, 500); }

    function cleanBody() {
      const c = doc.body.cloneNode(true);
      c.querySelectorAll('[data-ss-sel]').forEach(n => n.removeAttribute('data-ss-sel'));
      c.querySelectorAll('.vimgbar,.vimghandle').forEach(n => n.remove());   // veiligheidsnet: hulpelementen horen er nooit in
      c.querySelectorAll('img[data-ss-orig]').forEach(i => { i.setAttribute('src', i.getAttribute('data-ss-orig')); i.removeAttribute('data-ss-orig'); });
      c.querySelectorAll('[style=""],[class=""]').forEach(n => { if (n.getAttribute('style') === '') n.removeAttribute('style'); if (n.getAttribute('class') === '') n.removeAttribute('class'); });
      return c;
    }
    function push() {
      clearTimeout(st.pushTimer);
      if (!st.dirty || !doc) return;
      const src = o.getSource(); if (src === null) return;
      const body = cleanBody();
      const p = pretty(body, 1);
      const inner = p.startsWith('\n') ? p + '\n' : p;
      const next = spliceBody(src, inner);
      st.dirty = false;
      if (next !== src) { st.syncing = true; try { o.setSource(next); } finally { st.syncing = false; } }
    }

    /* ---------- Weergave opbouwen ---------- */
    function buildDisplay(src) {
      const hasDoc = /<(html|head|body)\b/i.test(src);
      const d = new DOMParser().parseFromString(hasDoc ? src : '<body>' + src + '</body>', 'text/html');
      d.querySelectorAll('link[rel~=stylesheet]').forEach(l => {
        const css = o.getFile((l.getAttribute('href') || '').replace(/^\.\//, ''));
        if (css !== null) { const s = d.createElement('style'); s.textContent = css; l.replaceWith(s); }
      });
      d.querySelectorAll('meta[http-equiv],base').forEach(n => n.remove());
      d.querySelectorAll('img[src]').forEach(i => {
        const n = (i.getAttribute('src') || '').replace(/^\.\//, '');
        const c = /^[\w.-]+\.svg$/i.test(n) ? o.getFile(n) : null;
        if (c !== null) { i.setAttribute('data-ss-orig', n); i.setAttribute('src', 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(c)); }
      });
      const s = d.createElement('style'); s.id = '__ss'; s.textContent = EDIT_CSS; d.head.appendChild(s);
      d.body.setAttribute('contenteditable', 'true');
      return '<!DOCTYPE html>' + d.documentElement.outerHTML;
    }

    function note(msg) { o.note.textContent = msg || ''; o.note.hidden = !msg; }

    function load(keepScroll) {
      const src = o.getSource();
      if (src === null) { frame.hidden = true; bar.classList.add('off'); props.classList.add('off'); doc = null; ibar.hidden = true; ihandle.hidden = true; note('Open een HTML-bestand om visueel te bewerken.'); return; }
      frame.hidden = false; bar.classList.remove('off'); props.classList.remove('off');
      const warn = /<script\b/i.test(src) && /(innerHTML|document\.write|createElement|appendChild|insertAdjacent)/.test(src);
      note(warn ? 'Let op: deze pagina bouwt inhoud met JavaScript op. Die inhoud is hier niet zichtbaar of bewerkbaar; alleen de vaste HTML wel. Scripts draaien niet in de visuele modus.' : '');
      const y = keepScroll && doc ? doc.defaultView.scrollY : 0;
      st.name = o.getName();
      frame.onload = () => { doc = frame.contentDocument; wire(); if (y) doc.defaultView.scrollTo(0, y); };
      frame.srcdoc = buildDisplay(src);
    }

    function wire() {
      if (!doc) return;
      st.sel = null; st.range = null; fillProps();
      try { doc.execCommand('styleWithCSS', false, true); doc.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) { /* */ }
      doc.addEventListener('input', edited);
      doc.defaultView.addEventListener('scroll', placeImgBar);
      doc.addEventListener('click', e => {
        const a = e.target.closest && e.target.closest('a'); if (a) { e.preventDefault(); }
        select(e.target.nodeType === 1 ? e.target : e.target.parentElement);
      });
      doc.addEventListener('selectionchange', () => {
        const s = doc.getSelection(); if (!s || !s.rangeCount) return;
        st.range = s.getRangeAt(0).cloneRange();
        const r0 = st.range;   // een geselecteerde afbeelding (range om precies die <img>) behoudt de selectie
        if (isImg(st.sel) && r0.startContainer === r0.endContainer && r0.endOffset - r0.startOffset === 1 && r0.startContainer.childNodes[r0.startOffset] === st.sel) { return; }
        const n = s.anchorNode; const el = n && (n.nodeType === 1 ? n : n.parentElement);
        if (el && el !== st.sel && el !== doc.body && doc.body.contains(el)) { select(el); }
      });
      doc.addEventListener('keydown', e => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); o.save(); }
      });
      doc.addEventListener('paste', e => {
        e.preventDefault();
        const cd = e.clipboardData; const html = cd.getData('text/html'); const txt = cd.getData('text/plain');
        let ins;
        if (html && window.DOMPurify) {
          ins = window.DOMPurify.sanitize(html, { FORBID_TAGS: ['style', 'script', 'iframe', 'object', 'embed', 'form', 'link', 'meta', 'base'], FORBID_ATTR: ['style', 'class', 'id'] });
        } else { ins = esc(txt).replace(/\r?\n/g, '<br>'); }
        doc.execCommand('insertHTML', false, ins);
      });
      doc.addEventListener('dragover', e => { if (e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files')) { e.preventDefault(); } });
      doc.addEventListener('drop', e => { if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) { e.preventDefault(); } });
    }

    /* ---------- Publiek ---------- */
    return {
      get active() { return st.active; },
      activate() { st.active = true; o.wrap.hidden = false; load(false); },
      deactivate() { push(); st.active = false; o.wrap.hidden = true; doc = null; frame.srcdoc = ''; ibar.hidden = true; ihandle.hidden = true; },
      flush() { if (st.active) { push(); } },
      /** Andere (of dezelfde) bestandskeuze in de editor. */
      fileChanged() { if (st.active) { push(); load(false); } },
      /** De gebruiker typt in de code: weergave vernieuwen (niet als de wijziging van onszelf komt). */
      codeChanged() {
        if (!st.active || st.syncing) return;
        clearTimeout(st.reloadTimer); st.reloadTimer = setTimeout(() => { if (!st.dirty) load(true); }, 600);
      },
      setWidth(w) { frame.style.width = w; frame.style.maxWidth = '100%'; },
    };
  }

  window.SSVisual = { create, pretty, spliceBody, parseWidth };
})();

/*
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  FILE CARD                                                           ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  File    : assets/js/visual.js                                       ║
 * ║  Role    : View (script)                                             ║
 * ║  Version : 0.12.2                                                    ║
 * ║  Updated : 2026-10-01                                                ║
 * ║  Notes   : Visuele modus; afbeelding met breedte/alt, formaatbalk    ║
 * ╠══════════════════════════════════════════════════════════════════════╣
 * ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 */
