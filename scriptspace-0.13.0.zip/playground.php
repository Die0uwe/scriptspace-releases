<?php
// playground.php — editor (Ace), live preview in afgeschermde iframe en AI-assistent.
declare(strict_types=1);
define('SS_NO_CSP', true);
require_once __DIR__ . '/includes/auth.php';
$u = require_login();
$canSandbox = can('sandbox.create');
$canAi = can('ai.use');
$phpState = '0'; // 0 = geen recht, 1 = beschikbaar, x = recht maar niet beschikbaar op deze server
$phpWhy = '';
if (php_exec_allowed((int)$u['id'])) {
    require_once __DIR__ . '/includes/phprun.php';
    $pi = phprun_info();
    $phpState = $pi['ok'] ? '1' : 'x';
    $phpWhy = $pi['reason'];
}
?>
<!DOCTYPE html>
<html lang="nl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf" content="<?= e(csrf_token()) ?>">
<title>Playground — scriptspace.nl</title>
<link rel="icon" href="weblogo.png" type="image/png">
<link rel="stylesheet" href="assets/vendor/hljs/github-dark.min.css">
<link rel="stylesheet" href="assets/css/playground.css">
</head>
<body class="pg" data-user="<?= e($u['username']) ?>" data-can-sandbox="<?= $canSandbox ? '1' : '0' ?>" data-can-ai="<?= $canAi ? '1' : '0' ?>" data-php="<?= e($phpState) ?>">
<div id="app">

  <header class="bar">
    <a class="brand" href="index.php" title="Naar home"><img src="weblogo.png" alt="" width="24" height="24"><span>script<b>space</b></span></a>
    <div class="group">
      <label class="sr" for="sbSelect">Sandbox</label>
      <select id="sbSelect" title="Sandbox"></select>
      <button id="sbNew" class="btn" title="Nieuwe sandbox (72 uur)">+ Sandbox</button>
    </div>
    <div class="group">
      <button id="btnSave" class="btn primary" title="Opslaan (Ctrl+S)">Opslaan <span id="dirtyDot" class="dot" hidden></span></button>
      <button id="btnRun" class="btn" title="Preview vernieuwen">▶ Uitvoeren</button>
      <label class="chk" title="Preview automatisch bijwerken tijdens typen"><input type="checkbox" id="chkLive" checked> live</label>
    </div>
    <?php if ($phpState !== '0'): ?>
    <div class="group">
      <button id="btnPhp" class="btn" <?= $phpState === 'x' ? 'disabled' : '' ?> title="<?= e($phpState === 'x' ? 'PHP uitvoeren is hier niet beschikbaar: ' . $phpWhy : 'Voert het open .php-bestand (of index.php) uit in een beperkt proces (alleen super_admin; geen volwaardige beveiligingsgrens)') ?>">▶ PHP</button>
      <label class="sr" for="phpQuery">Querystring</label>
      <input id="phpQuery" class="qinput" type="text" placeholder="?a=1&amp;b=2" maxlength="300" autocomplete="off" spellcheck="false" <?= $phpState === 'x' ? 'disabled' : '' ?>>
    </div>
    <?php endif; ?>
    <div class="group" role="group" aria-label="Indeling">
      <label class="sr" for="layoutPreset">Indeling</label>
      <select id="layoutPreset" title="Kies een indeling"></select>
      <button id="btnLayout" class="btn" title="Blokken verplaatsen, tonen of verbergen">▦ Indeling…</button>
    </div>
    <span class="spacer"></span>
    <button id="btnAi" class="btn" title="AI-paneel tonen of verbergen">✨ AI</button>
    <button id="btnSettings" class="btn" title="AI-instellingen en keys">⚙</button>
    <button id="btnFull" class="btn" title="Volledig scherm (F11-stijl)">⛶</button>
    <?php if (can('admin.access')): ?><a class="btn ghost" href="admin/index.php" title="Beheerpaneel">Admin</a><?php endif; ?>
    <a class="btn ghost" href="user/dashboard.php" title="Dashboard"><?= e($u['username']) ?></a>
  </header>

  <main id="main" aria-label="Werkruimte">
    <aside id="files" class="pane" data-title="Bestanden">
      <div class="pane-head"><span>Bestanden</span><span class="group">
        <button id="fileUp" class="icon" title="Bestanden of een ZIP uploaden (of sleep ze hierheen)">⬆</button>
        <button id="fileZip" class="icon" title="Hele sandbox als ZIP downloaden, om te bewerken in je eigen editor">⬇ ZIP</button>
        <button id="fileNew" class="icon" title="Nieuw bestand">＋</button>
      </span></div>
      <input type="file" id="fileInput" multiple hidden accept=".html,.htm,.css,.js,.json,.txt,.md,.svg,.php,.zip">
      <ul id="fileList" class="filelist"></ul>
      <p id="filesHint" class="hint"></p>
    </aside>

    <section id="editorPane" class="pane" data-title="Editor">
      <div class="pane-head"><span id="tabName">—</span><span id="tabState" class="muted"></span></div>
      <div id="editor" aria-label="Code-editor"></div>
      <div id="emptyState" class="empty" hidden>
        <p>Je hebt nog geen sandbox.</p>
        <button id="emptyNew" class="btn primary">Maak je eerste sandbox</button>
      </div>
    </section>

    <section id="previewPane" class="pane" data-title="Preview">
      <div class="pane-head">
        <span class="group seg" id="modeSeg" role="group" aria-label="Weergave">
          <button class="btn active" data-mode="preview" title="Live preview van je pagina">👁 Preview</button>
          <button class="btn" data-mode="visual" title="Visueel bewerken: klik en typ direct in de pagina">✏ Visueel</button>
        </span>
        <span class="group seg" id="devices">
          <button class="icon active" data-w="100%" title="Volledige breedte">🖥</button>
          <button class="icon" data-w="768px" title="Tablet 768px">▭</button>
          <button class="icon" data-w="375px" title="Mobiel 375px">📱</button>
        </span>
      </div>
      <div id="previewWrap"><iframe id="preview" title="Preview" sandbox="allow-scripts allow-forms allow-modals"></iframe></div>
      <div id="visWrap" hidden>
        <div id="visNote" hidden></div>
        <div id="visBar" class="vbar" role="toolbar" aria-label="Opmaak"></div>
        <div class="visframe"><iframe id="visFrame" title="Visuele editor" sandbox="allow-same-origin"></iframe></div>
        <div id="visProps" class="vprops" aria-label="Eigenschappen van het geselecteerde element"></div>
      </div>
    </section>

    <section id="consolePane" class="pane" data-title="Console">
      <div class="pane-head"><span>Console <span id="errCount" class="badge" hidden>0</span></span><button id="consoleClear" class="icon" title="Console wissen">🧹</button></div>
      <ul id="consoleList"></ul>
    </section>

    <aside id="aiPane" class="pane" data-title="AI-assistent">
      <div class="pane-head">
        <span>AI-assistent</span>
        <span class="group">
          <select id="aiModel" title="Model">
            <option value="deepseek-chat">DeepSeek V3</option>
            <option value="deepseek-reasoner">DeepSeek R1</option>
            <option value="gemini-2.5-flash">Gemini 2.5 Flash</option>
          </select>
          <button id="aiClear" class="icon" title="Gesprek wissen">🗑</button>
        </span>
      </div>
      <div id="aiMessages" class="messages" aria-live="polite">
        <div class="msg sys">Hoi <?= e($u['username']) ?>! Vraag me om code te schrijven, te verbeteren of uit te leggen. Ik zie het bestand dat je open hebt.</div>
      </div>
      <form id="aiForm" class="aiform">
        <textarea id="aiInput" rows="2" placeholder="Vraag iets… (Enter = versturen, Shift+Enter = nieuwe regel)" <?= $canAi ? '' : 'disabled' ?>></textarea>
        <button id="aiSend" class="btn primary" type="submit" <?= $canAi ? '' : 'disabled' ?>>Verstuur</button>
      </form>
    </aside>
  </main>
  <div id="parking" hidden></div>

  <footer class="status">
    <span id="stSave">Klaar</span>
    <span id="stExpiry" class="muted"></span>
    <span class="spacer"></span>
    <span id="stCursor" class="muted"></span>
  </footer>
</div>

<!-- Dialogen -->
<dialog id="dlgLayout">
  <form method="dialog">
    <h3>Indeling van de werkruimte</h3>
    <p class="muted">Kies per blok in welke kolom het staat, of verberg het. Met ▲▼ verander je de volgorde binnen een kolom. Sleep de balkjes tussen de blokken om de grootte aan te passen.</p>
    <div id="layoutRows"></div>
    <menu><button type="button" class="btn" id="layoutReset">Standaard (3 kolommen)</button><button class="btn primary" value="close">Klaar</button></menu>
  </form>
</dialog>

<dialog id="dlgRead" class="wide">
  <form method="dialog">
    <div class="readhead"><h3>AI-antwoord</h3><button class="btn" value="close">Sluiten</button></div>
    <div id="readBody" class="msg assistant readbody"></div>
  </form>
</dialog>
<dialog id="dlgAsk">
  <form method="dialog" id="askForm">
    <h3 id="askTitle"></h3>
    <p id="askText" class="muted"></p>
    <input id="askInput" type="text" autocomplete="off" spellcheck="false">
    <p id="askErr" class="err" hidden></p>
    <menu><button type="button" class="btn" id="askCancel">Annuleren</button><button class="btn primary" id="askOk" value="ok">OK</button></menu>
  </form>
</dialog>

<dialog id="dlgSettings">
  <form method="dialog">
    <h3>AI-instellingen</h3>
    <p class="muted">Gebruik je eigen key. Die wordt versleuteld op de server bewaard en nooit meer aan de browser teruggegeven.</p>
    <div class="keyrow" data-provider="deepseek">
      <div><b>DeepSeek</b> <span class="status muted" data-status></span><br><a href="https://platform.deepseek.com/api_keys" target="_blank" rel="noopener noreferrer">Key aanmaken</a></div>
      <input type="password" autocomplete="off" placeholder="sk-…" data-key>
      <button type="button" class="btn primary" data-save>Opslaan</button>
      <button type="button" class="btn" data-delete>Verwijderen</button>
    </div>
    <div class="keyrow" data-provider="gemini">
      <div><b>Gemini</b> <span class="status muted" data-status></span><br><a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener noreferrer">Key aanmaken</a></div>
      <input type="password" autocomplete="off" placeholder="AIza…" data-key>
      <button type="button" class="btn primary" data-save>Opslaan</button>
      <button type="button" class="btn" data-delete>Verwijderen</button>
    </div>
    <p id="settingsMsg" class="muted"></p>
    <menu><button class="btn" value="close">Sluiten</button></menu>
  </form>
</dialog>

<script src="assets/vendor/hljs/highlight.min.js"></script>
<script src="assets/vendor/marked.umd.js"></script>
<script src="assets/vendor/purify.min.js"></script>
<script src="assets/vendor/ace/ace.js"></script>
<script src="assets/vendor/ace/ext-language_tools.js"></script>
<script src="assets/js/visual.js"></script>
<script src="assets/js/playground.js"></script>
</body>
</html>
<?php
// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : playground.php                                            ║
// ║  Role    : View                                                      ║
// ║  Version : 0.3.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Editor, live preview, console en AI-assistent             ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
