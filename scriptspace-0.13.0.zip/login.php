<?php
// login.php — inloggen met gebruikersnaam of e-mail + wachtwoord (Argon2id, rate-limit, audit).
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/oauth.php';

$redirectParam = (string)($_POST['redirect'] ?? $_GET['redirect'] ?? '');

if (current_user() !== null && !isset($_GET['provider'])) {
    redirect(safe_redirect_target($redirectParam, 'user/dashboard.php'));
}

$error = '';
$ident = '';

// --- OAuth (GitHub / Google / Discord): ?provider=naam, daarna terug met ?code=...&state=... ---
$prov = (string)($_GET['provider'] ?? '');
if ($prov !== '') {
    $intent = (string)($_SESSION['oauth_intent'] ?? 'login');
    if (current_user() !== null && !(in_array($intent, ['link', 'merge'], true) && isset($_GET['code']))) {
        redirect(safe_redirect_target($redirectParam, 'user/dashboard.php')); // al ingelogd
    }
    if (!isset(oauth_providers()[$prov])) {
        $error = 'Deze inlogmethode is niet ingesteld.';
    } elseif (isset($_GET['error'])) {
        $error = 'Inloggen is geannuleerd.';
    } elseif (!isset($_GET['code'])) {
        if (oauth_rate_limited()) { $error = 'Te veel pogingen. Probeer het over enkele minuten opnieuw.'; }
        else { oauth_begin($prov, safe_redirect_target($redirectParam, '')); }
    } else {
        unset($_SESSION['oauth_intent']);
        [$prof, $err] = oauth_profile($prov, (string)$_GET['code'], (string)($_GET['state'] ?? ''));
        if ($intent === 'link') { // koppelen vanuit het account van een ingelogde gebruiker
            $me = current_user();
            if (!$me) { redirect('login.php'); }
            $e2 = $prof ? oauth_link_to_user((int)$me['id'], $prov, $prof) : $err;
            redirect('user/account.php?' . ($e2 === '' ? 'linked=' . rawurlencode($prov) : 'linkerr=' . rawurlencode($e2)) . '#koppelingen');
        }
        if ($intent === 'merge') { // bewijs voor het andere account bij "accounts samenvoegen"
            $me = current_user();
            if (!$me) { redirect('login.php'); }
            require_once __DIR__ . '/includes/accounts.php';
            $mergeErr = $prof ? '' : $err;
            if ($prof) {
                $q = db()->prepare('SELECT user_id FROM oauth_identities WHERE provider = ? AND provider_uid = ?');
                $q->execute([$prov, $prof['uid']]);
                $owner = $q->fetchColumn();
                if ($owner === false) { $mergeErr = 'Dit ' . OAUTH_DEFS[$prov]['label'] . '-account hangt aan geen enkel ScriptSpace-account. Je kunt het gewoon koppelen via Account, Gekoppelde accounts.'; }
                elseif ((int)$owner === (int)$me['id']) { $mergeErr = 'Dit ' . OAUTH_DEFS[$prov]['label'] . '-account is al aan dit account gekoppeld.'; }
                elseif (($mergeErr = account_merge_check((int)$me['id'], (int)$owner)) === '') { $_SESSION['merge_proof'] = ['keep' => (int)$me['id'], 'drop' => (int)$owner, 'at' => time()]; }
            }
            if ($mergeErr !== '') { $_SESSION['merge_error'] = $mergeErr; }
            redirect('user/merge.php');
        }
        $user = null;
        if ($prof) { [$user, $err] = oauth_resolve_user($prov, $prof); }
        if ($user && !(int)$user['is_active']) { audit('auth.login_denied_inactive', (int)$user['id']); $user = null; $err = 'Dit account is geblokkeerd.'; }
        if ($user) {
            $after = (string)($_SESSION['oauth_redirect'] ?? '');
            db()->prepare('UPDATE users SET last_login_at = NOW(), last_login_ip = ? WHERE id = ?')->execute([client_ip(), $user['id']]);
            start_user_session($user);
            audit('auth.oauth_login', (int)$user['id'], ['provider' => $prov]);
            $default = user_can((int)$user['id'], 'admin.access') ? 'admin/index.php' : 'user/dashboard.php';
            redirect(safe_redirect_target($after, $default));
        }
        $error = $err ?: 'Inloggen mislukt.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ident = trim((string)($_POST['ident'] ?? ''));
    $pass  = (string)($_POST['password'] ?? '');

    if (!csrf_verify()) {
        $error = 'Sessie verlopen, probeer opnieuw.';
    } elseif ($ident === '' || $pass === '') {
        $error = 'Vul je gegevens in.';
    } elseif (login_blocked($ident)) {
        $error = 'Te veel pogingen. Probeer het over ' . SS_LOGIN_WINDOW_MIN . ' minuten opnieuw.';
        audit('auth.login_rate_limited', null, ['identifier' => substr($ident, 0, 100)]);
    } elseif (!captcha_ok()) {
        $error = 'Captcha mislukt.';
    } else {
        $st = db()->prepare('SELECT * FROM users WHERE (username = ? OR email = ?) AND deleted_at IS NULL LIMIT 1');
        $st->execute([$ident, strtolower($ident)]);
        $user = $st->fetch();

        // Altijd een hash controleren, zodat de responstijd niets verraadt over bestaande accounts
        static $dummy = null;
        $dummy ??= hash_password('dummy-wachtwoord-voor-timing');
        $ok = password_verify($pass, $user['password_hash'] ?? $dummy) && $user;

        if (!$ok) {
            login_failed($ident);
            audit('auth.login_failed', $user ? (int)$user['id'] : null, ['identifier' => substr($ident, 0, 100)]);
            $error = 'Onjuiste inloggegevens.';
        } elseif (!(int)$user['is_active']) {
            audit('auth.login_denied_inactive', (int)$user['id']);
            $error = 'Onjuiste inloggegevens.'; // geblokkeerd: niets verklappen
        } elseif ($user['email_verified_at'] === null) {
            $error = 'Bevestig eerst je e-mailadres via de link in je mail.';
        } else {
            if (password_needs_rehash($user['password_hash'], password_algo(), password_opts())) {
                db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?')->execute([hash_password($pass), $user['id']]);
            }
            db()->prepare('UPDATE users SET last_login_at = NOW(), last_login_ip = ? WHERE id = ?')->execute([client_ip(), $user['id']]);
            login_cleared($ident);
            start_user_session($user);
            audit('auth.login', (int)$user['id']);
            $default = user_can((int)$user['id'], 'admin.access') ? 'admin/index.php' : 'user/dashboard.php';
            redirect(safe_redirect_target($redirectParam, $default));
        }
    }
}

page_header('Inloggen');
?>
<div class="card narrow">
  <h1>Inloggen</h1>
  <?php if ($error): ?><div class="msg err"><?= e($error) ?></div><?php endif; ?>
  <?php if (!empty($_GET['reset'])): ?><div class="msg ok">Wachtwoord gewijzigd. Log in met je nieuwe wachtwoord.</div><?php endif; ?>
  <?php if (!empty($_GET['verified'])): ?><div class="msg ok">E-mailadres bevestigd. Je kunt nu inloggen.</div><?php endif; ?>
  <form method="post" autocomplete="on">
    <?= csrf_field() ?>
    <input type="hidden" name="redirect" value="<?= e(safe_redirect_target($redirectParam, '')) ?>">
    <label for="ident">Gebruikersnaam of e-mail</label>
    <input type="text" id="ident" name="ident" value="<?= e($ident) ?>" required autofocus>
    <label for="password">Wachtwoord</label>
    <input type="password" id="password" name="password" required>
    <?= captcha_widget() ?>
    <button type="submit">Inloggen</button>
  </form>
  <?= oauth_buttons(safe_redirect_target($redirectParam, '')) ?>
  <p class="muted"><a href="forgot.php" style="color:#8b5cf6">Wachtwoord vergeten?</a></p>
  <p class="muted">Nog geen account? <a href="register.php" style="color:#8b5cf6">Registreren</a></p>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : login.php                                                 ║
// ║  Role    : Auth                                                      ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Inloggen: Argon2id, rate-limit, veilige redirect          ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
