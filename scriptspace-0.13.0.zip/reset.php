<?php
// reset.php — nieuw wachtwoord instellen via de eenmalige link uit de mail.
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';
header('Referrer-Policy: no-referrer'); // de token staat in de URL

$token = (string)($_POST['t'] ?? $_GET['t'] ?? '');
$valid = null;
if (preg_match('/^[a-f0-9]{64}$/', $token)) {
    $st = db()->prepare('SELECT r.id, r.user_id FROM password_resets r JOIN users u ON u.id = r.user_id
                         WHERE r.token_hash = ? AND r.used_at IS NULL AND r.expires_at > NOW()
                           AND u.is_active = 1 AND u.deleted_at IS NULL AND u.email_verified_at IS NOT NULL');
    $st->execute([hash('sha256', $token)]);
    $valid = $st->fetch() ?: null;
}

$errors = [];
if ($valid && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $pass  = (string)($_POST['password'] ?? '');
    $pass2 = (string)($_POST['password2'] ?? '');
    if (!csrf_verify()) {
        $errors[] = 'Sessie verlopen, probeer opnieuw.';
    } else {
        $errors = password_problems($pass, $pass2);
    }
    if (!$errors) {
        // Eenmalig: claim de token atomair, pas dan wijzigen
        $claim = db()->prepare('UPDATE password_resets SET used_at = NOW() WHERE id = ? AND used_at IS NULL');
        $claim->execute([$valid['id']]);
        if ($claim->rowCount() === 1) {
            set_user_password((int)$valid['user_id'], $pass, 'reset_done');
            redirect('login.php?reset=1');
        }
        $valid = null;
    }
}

page_header('Nieuw wachtwoord');
?>
<div class="card narrow">
  <h1>Nieuw wachtwoord</h1>
  <?php if (!$valid): ?>
    <div class="msg err">Deze link is ongeldig, verlopen of al gebruikt.</div>
    <a class="btn" href="forgot.php">Nieuwe link aanvragen</a>
  <?php else: ?>
    <?php foreach ($errors as $err): ?><div class="msg err"><?= e($err) ?></div><?php endforeach; ?>
    <form method="post" autocomplete="off">
      <?= csrf_field() ?>
      <input type="hidden" name="t" value="<?= e($token) ?>">
      <label for="password">Nieuw wachtwoord (min. 10 tekens)</label>
      <input type="password" id="password" name="password" required autofocus autocomplete="new-password">
      <label for="password2">Herhaal wachtwoord</label>
      <input type="password" id="password2" name="password2" required autocomplete="new-password">
      <button type="submit">Wachtwoord opslaan</button>
    </form>
  <?php endif; ?>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : reset.php                                                 ║
// ║  Role    : Auth                                                      ║
// ║  Version : 0.6.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Nieuw wachtwoord via eenmalige link (1 uur)               ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
