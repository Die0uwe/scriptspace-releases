<?php
// forgot.php — wachtwoord vergeten: stuurt (indien het account bestaat) een eenmalige link, 1 uur geldig.
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

if (current_user() !== null) { redirect('user/account.php'); }

$errors = [];
$done = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    if (!csrf_verify()) {
        $errors[] = 'Sessie verlopen, probeer opnieuw.';
    } elseif (!empty($_POST['website'])) {
        $done = true; // honeypot
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
        $errors[] = 'Vul een geldig e-mailadres in.';
    } elseif (!captcha_ok()) {
        $errors[] = 'Captcha mislukt.';
    } else {
        // Maximaal 5 aanvragen per uur per IP en 3 per uur per account; de melding blijft altijd gelijk
        $st = db()->prepare("SELECT COUNT(*) FROM audit_log WHERE action = 'auth.reset_request' AND ip_address = ? AND created_at > (NOW() - INTERVAL 1 HOUR)");
        $st->execute([client_ip()]);
        $ipCount = (int)$st->fetchColumn();

        $st = db()->prepare('SELECT id, username FROM users WHERE email = ? AND is_active = 1 AND deleted_at IS NULL AND email_verified_at IS NOT NULL');
        $st->execute([$email]);
        $user = $st->fetch();
        audit('auth.reset_request', $user ? (int)$user['id'] : null);

        if ($ipCount < 5 && $user) {
            $st = db()->prepare("SELECT COUNT(*) FROM password_resets WHERE user_id = ? AND created_at > (NOW() - INTERVAL 1 HOUR)");
            $st->execute([$user['id']]);
            if ((int)$st->fetchColumn() < 3) {
                $token = bin2hex(random_bytes(32));
                db()->prepare('DELETE FROM password_resets WHERE user_id = ? AND (used_at IS NOT NULL OR expires_at < NOW())')->execute([$user['id']]);
                db()->prepare('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, NOW() + INTERVAL 1 HOUR)')
                    ->execute([$user['id'], hash('sha256', $token)]);
                send_mail($email, 'Wachtwoord opnieuw instellen op scriptspace.nl',
                    "Hoi {$user['username']},\n\nJe kunt een nieuw wachtwoord instellen via deze link (1 uur geldig, eenmalig):\n" . cfg('app_url') . "/reset.php?t=$token\n\nHeb jij dit niet aangevraagd? Dan kun je deze mail negeren; je wachtwoord blijft hetzelfde.\n");
            }
        }
        $done = true;
    }
}

page_header('Wachtwoord vergeten');
?>
<div class="card narrow">
  <h1>Wachtwoord vergeten</h1>
  <?php if ($done): ?>
    <div class="msg ok">Als dit e-mailadres bij een bevestigd account hoort, sturen we zo een mail met een link om een nieuw wachtwoord in te stellen. Controleer ook je spam.</div>
    <a class="btn ghost" href="login.php">Terug naar inloggen</a>
  <?php else: ?>
    <?php foreach ($errors as $err): ?><div class="msg err"><?= e($err) ?></div><?php endforeach; ?>
    <form method="post" autocomplete="on">
      <?= csrf_field() ?>
      <div class="hp" aria-hidden="true"><label>Website</label><input type="text" name="website" tabindex="-1" autocomplete="off"></div>
      <label for="email">E-mailadres van je account</label>
      <input type="email" id="email" name="email" required autofocus>
      <?= captcha_widget() ?>
      <button type="submit">Stuur link</button>
    </form>
    <p class="muted"><a href="login.php" style="color:#8b5cf6">Terug naar inloggen</a></p>
  <?php endif; ?>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : forgot.php                                                ║
// ║  Role    : Auth                                                      ║
// ║  Version : 0.6.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Wachtwoord vergeten: eenmalige link, rate-limit           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
