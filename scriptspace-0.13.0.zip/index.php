<?php
// index.php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/oauth.php';

$isLoggedIn = current_user() !== null;
$currentUser = $isLoggedIn ? current_user()['username'] : '';
?>
<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ScriptSpace & Socials Linktree</title>
    <!-- Web icon / Favicon -->
    <link rel="icon" href="weblogo.png" type="image/png">
    <link rel="stylesheet" href="style.css">
    <style>
        /* Pagina vullend en gecentreerd zonder scrollbars */
        body {
            display: flex;
            flex-direction: column;
            height: 100vh;
            margin: 0;
            background-color: var(--bg, #0b0f19);
            color: var(--text, #f3f4f6);
            font-family: system-ui, -apple-system, sans-serif;
            overflow: hidden;
        }
        .auth-wrapper {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 6px 15px;
            box-sizing: border-box;
            gap: 10px; /* Klein beetje aangepast voor de schaling */
            
            /* Gehele inlogsectie exact 20% groter gemaakt, gecentreerd passend op het scherm */
            transform: scale(1.2);
            transform-origin: center center;
        }

        /* Vaste uniforme breedte voor alle componenten zodat alles perfect uitlijnt */
        .auth-main-layout, 
        .auth-teasers, 
        .ai-status-row, 
        .auth-links-grid-container {
            max-width: 560px;
            width: 100%;
            box-sizing: border-box;
        }

        /* Centrale inlogkaart */
        .auth-card {
            width: 100%;
            background: rgba(17, 24, 39, 0.85);
            border: 1px solid var(--border, rgba(255, 255, 255, 0.08));
            border-radius: 12px;
            padding: 12px 20px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
            text-align: center;
            box-sizing: border-box;
        }

        /* Logoveld hoogte (240px) */
        .logo-banner {
            width: 100%;
            height: 240px;
            background: #05070c;
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 8px;
            box-shadow: inset 0 2px 6px rgba(0,0,0,0.5);
            border: 1px solid rgba(255,255,255,0.06);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .logo-banner img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain; /* Zorgt dat het logo volledig zichtbaar blijft */
            display: block;
        }

        /* Horizontaal Raster voor Subdomeinen & Links */
        .auth-links-grid-container {
            background: rgba(17, 24, 39, 0.85);
            border: 1px solid var(--border, rgba(255, 255, 255, 0.08));
            border-radius: 12px;
            padding: 10px 16px;
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.2);
        }
        .auth-links-grid-container h3 {
            font-size: 0.8rem;
            color: #fff;
            margin: 0 0 6px 0;
            border-bottom: 1px solid var(--border, rgba(255, 255, 255, 0.08));
            padding-bottom: 4px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .referral-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* 3 breed */
            grid-template-rows: repeat(2, auto);    /* 2 hoog */
            gap: 5px;
        }
        .referral-grid a {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            font-size: 0.73rem;
            color: var(--text-muted, #9ca3af);
            text-decoration: none;
            padding: 5px 6px;
            background: rgba(255, 255, 255, 0.02);
            border-radius: 6px;
            border: 1px solid transparent;
            transition: all 0.2s ease;
            text-align: center;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .referral-grid a:hover {
            color: #fff;
            background: rgba(255, 255, 255, 0.06);
            border-color: var(--accent, #8b5cf6);
        }

        /* Splash Video Overlay */
        #splashOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: #000000;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            transition: opacity 0.5s ease;
        }
        .splash-video-container {
            position: relative;
            width: 90%;
            max-width: 900px;
            aspect-ratio: 16 / 9;
            background: #000000;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 16px 50px rgba(0,0,0,0.8);
            border: 1px solid rgba(255, 255, 255, 0.12);
            display: flex;
            align-items: center;
            justify-content: center;
        }
        #splashVideo {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        .skip-splash {
            margin-top: 20px;
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.2);
            color: #fff;
            padding: 8px 24px;
            border-radius: 30px;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.2s ease;
        }
        .skip-splash:hover {
            background: var(--accent, #8b5cf6);
            border-color: var(--accent, #8b5cf6);
        }

        .btn-replay-intro {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border, rgba(255, 255, 255, 0.08));
            color: var(--text-muted, #9ca3af);
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 0.72rem;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            margin-top: 6px;
        }
        .btn-replay-intro:hover {
            background: rgba(255, 255, 255, 0.08);
            color: #fff;
            border-color: var(--accent, #8b5cf6);
        }

        /* Teasers (Home blokken) */
        .auth-teasers {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
        }
        .auth-teaser-card {
            background: rgba(17, 24, 39, 0.85);
            border: 1px solid var(--border, rgba(255, 255, 255, 0.08));
            border-radius: 10px;
            padding: 8px 10px;
            text-align: left;
        }
        .auth-teaser-card h4 {
            font-size: 0.78rem;
            margin: 0 0 2px 0;
            color: #fff;
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .auth-teaser-card p {
            font-size: 0.7rem;
            color: var(--text-muted, #9ca3af);
            margin: 0;
            line-height: 1.2;
        }

        /* AI Status Rij */
        .ai-status-row {
            background: rgba(138, 43, 226, 0.06);
            border: 1px solid rgba(138, 43, 226, 0.2);
            border-radius: 10px;
            padding: 6px 12px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 0.76rem;
            color: var(--text-muted, #9ca3af);
        }
        .ai-status-row span b {
            color: #fff;
        }

        /* Copyright Footer */
        site-footer {
            width: 100%;
            padding: 6px;
            text-align: center;
            border-top: 1px solid var(--border, rgba(255, 255, 255, 0.08));
            font-size: 0.7rem;
            color: var(--text-muted, #9ca3af);
            background: rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>

<?php if (!$isLoggedIn): ?>
    <!-- SPLASH VIDEO POPUP -->
    <div id="splashOverlay">
        <div class="splash-video-container">
            <video id="splashVideo" autoplay muted playsinline>
                <source src="splash.mp4" type="video/mp4">
                Je browser ondersteunt geen video.
            </video>
        </div>
        <button class="skip-splash" onclick="closeSplash()">Overslaan / Doorgaan ➔</button>
    </div>

    <!-- INLOGSCHERM WRAPPER -->
    <div class="auth-wrapper">
        
        <!-- Centrale inlogkaart -->
        <div class="auth-main-layout">
            <div class="auth-card">
                <div class="logo-banner">
                    <img src="logoo.jpg" alt="ScriptSpace Logo">
                </div>
                
                <p style="margin: 0 0 8px 0; color: var(--text-muted, #9ca3af); font-size: 0.78rem;">Log in of maak een account om de playground te gebruiken.</p>
                <div style="display: flex; gap: 6px; margin-bottom: 8px;">
                    <a href="login.php" class="btn-sm btn-accent" style="flex: 1; text-decoration: none; padding: 8px; border-radius: 6px; font-size: 0.8rem; text-align: center;">Inloggen</a>
                    <a href="register.php" class="btn-sm" style="flex: 1; text-decoration: none; padding: 8px; border-radius: 6px; font-size: 0.8rem; text-align: center; border: 1px solid var(--border, rgba(255,255,255,0.1));">Registreren</a>
                </div>
                <?php $oa = oauth_providers(); if ($oa): ?>
                <div style="border-top: 1px solid var(--border, rgba(255, 255, 255, 0.08)); margin: 6px 0; padding-top: 6px;">
                    <p style="font-size: 0.72rem; color: var(--text-muted, #9ca3af); margin-bottom: 5px;">Of log direct in via een externe service:</p>
                    <div style="display: flex; gap: 6px; justify-content: center;">
                        <?php $oc = ['google' => '#db4437', 'github' => '#24292e', 'discord' => '#5865F2', 'facebook' => '#1877f2']; foreach ($oa as $on => $op): ?>
                        <a href="login.php?provider=<?= htmlspecialchars($on) ?>" class="btn-sm" data-provider="<?= htmlspecialchars($on) ?>" style="flex: 1; background: <?= $oc[$on] ?>; color: #fff; text-decoration: none; border: 1px solid rgba(255,255,255,0.1); padding: 5px; border-radius: 6px; font-size: 0.72rem; text-align: center;"><?= htmlspecialchars($op['label']) ?></a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div>
                    <button onclick="resetSplash()" class="btn-replay-intro">
                        ▶ Bekijk intro video opnieuw
                    </button>
                </div>
            </div>
        </div>

        <!-- Teasers (Home blokken) -->
        <div class="auth-teasers">
            <div class="auth-teaser-card">
                <h4>⚡ Playground</h4>
                <p>Bewerk HTML & CSS.</p>
            </div>
            <div class="auth-teaser-card">
                <h4>🔗 Linktree</h4>
                <p>Social overzicht.</p>
            </div>
            <div class="auth-teaser-card">
                <h4>🔐 Sessies</h4>
                <p>Veilige PHP login.</p>
            </div>
        </div>

        <!-- AI Status Rij -->
        <div class="ai-status-row">
            <span>✨ <b>AI Status:</b> DeepSeek V3 / R1 Engine gereed.</span>
            <span style="color: var(--accent, #8b5cf6);">● Actief</span>
        </div>

        <!-- Subdomeinen & Links Raster -->
        <div class="auth-links-grid-container">
            <h3>📌 Subdomeinen & Links</h3>
            <div class="referral-grid">
                <a href="https://cms.scriptspace.nl" target="_blank">🛠️ CMS Subdomein</a>
                <a href="https://wiki.scriptspace.nl" target="_blank">📖 Wiki Subdomein</a>
                <a href="http://www.slayeralliance.com" target="_blank">⚡ Slayer Alliance</a>
                <a href="https://deepseek.com" target="_blank">🤖 DeepSeek API</a>
                <a href="https://github.com" target="_blank">📂 GitHub Platform</a>
                <a href="https://discord.com" target="_blank">💬 Discord Community</a>
            </div>
        </div>

    </div>

    <!-- Copyright Footer -->
    <site-footer>
        &copy; 2026 ScriptSpace. Alle rechten voorbehouden.
    </site-footer>

    <script>
        const splashOverlay = document.getElementById('splashOverlay');
        const splashVideo = document.getElementById('splashVideo');

        function closeSplash() {
            splashOverlay.style.opacity = '0';
            setTimeout(() => {
                splashOverlay.style.display = 'none';
            }, 500);
            sessionStorage.setItem('splashShown', 'true');
        }

        function resetSplash() {
            sessionStorage.removeItem('splashShown');
            location.reload();
        }

        if (sessionStorage.getItem('splashShown') === 'true') {
            splashOverlay.style.display = 'none';
        } else {
            splashVideo.onended = function() {
                closeSplash();
            };
        }
    </script>

<?php else: ?>
    <!-- HOOFDAPPLICATIE -->
    <div class="page-wrapper" id="appWrapper">
        <!-- Header -->
        <header>
            <div class="header-left">
                <a href="/" class="logo" style="display: flex; align-items: center; gap: 8px; text-decoration: none;">
                    <img src="weblogo.png" alt="Icon" style="width: 28px; height: 28px; border-radius: 50%;"> 
                    <span>ScriptSpace</span>
                </a>
                <nav class="nav-links">
                    <a class="nav-link" href="playground.php" style="text-decoration:none">Playground</a>
                    <span class="nav-link" id="navSocials">Socials & Linktree</span>
                    <span class="nav-link active" id="navHome">Home</span>
                </nav>
            </div>
            <div class="header-right">
                <?php if (can('admin.access')): ?><a class="btn-sm" href="admin/index.php" style="text-decoration:none">Admin</a><?php endif; ?>
                <a class="btn-sm" href="user/account.php" style="text-decoration:none">Account</a>
                <div class="user-badge">
                    <div class="user-avatar"><?php echo strtoupper(substr($currentUser, 0, 1)); ?></div>
                    <span><?php echo htmlspecialchars($currentUser); ?></span>
                </div>
                <form method="post" action="logout.php" style="display:inline"><?= csrf_field() ?><button type="submit" class="btn-sm" style="background: transparent; border-color: var(--border);">Uitloggen</button></form>
            </div>
        </header>

        <!-- 2. Socials & Linktree Hub View -->
        <div class="linktree-container" id="socialsView" style="display: none;">
            <div class="linktree-header">
                <h2>Jouw Persoonlijke Linktree & Socials Hub</h2>
                <p>Beheer hier je koppelingen.</p>
            </div>

            <div class="platforms-grid">
                <div class="platform-card">
                    <div class="platform-info">
                        <h3>CMS Subdomein</h3>
                        <p>Status: <span class="status-badge connected">Actief</span></p>
                    </div>
                    <a href="https://cms.scriptspace.nl" target="_blank" class="btn-sm btn-accent" style="text-decoration: none;">Open CMS</a>
                </div>
                <div class="platform-card">
                    <div class="platform-info">
                        <h3>Wiki Subdomein</h3>
                        <p>Status: <span class="status-badge connected">Actief</span></p>
                    </div>
                    <a href="https://wiki.scriptspace.nl" target="_blank" class="btn-sm btn-accent" style="text-decoration: none;">Open Wiki</a>
                </div>
            </div>
        </div>

        <!-- 3. Landingspagina / Hero View -->
        <div class="hero-container" id="heroView">
            <h1>Code, AI & Socials <span>Centraal Beheer</span></h1>
            <p class="hero-sub">Welkom terug in je ScriptSpace-omgeving.</p>
            <div class="login-buttons" style="margin-top: 20px;">
                <a href="playground.php" class="btn-sm btn-accent" style="padding: 8px 16px; text-decoration: none;">Start Playground</a>
            </div>
        </div>
    </div>
<?php endif; ?>

    <script>
        // Tabwissel Home <-> Socials (alleen voor ingelogde gebruikers)
        (function () {
            const home = document.getElementById('heroView'), soc = document.getElementById('socialsView');
            const nHome = document.getElementById('navHome'), nSoc = document.getElementById('navSocials');
            if (!home || !soc || !nHome || !nSoc) return;
            function show(which) {
                home.style.display = which === 'home' ? 'flex' : 'none';
                soc.style.display = which === 'soc' ? 'flex' : 'none';
                nHome.classList.toggle('active', which === 'home');
                nSoc.classList.toggle('active', which === 'soc');
            }
            nHome.addEventListener('click', () => show('home'));
            nSoc.addEventListener('click', () => show('soc'));
        })();
    </script>
</body>
</html>