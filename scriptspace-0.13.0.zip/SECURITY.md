# Security Policy — ScriptSpace CMS

Meld een kwetsbaarheid **niet** via een openbare issue. Gebruik het tabblad **Security → Report a vulnerability** van deze repository, of neem contact op via [www.dieouwe.nl](https://www.dieouwe.nl).

Geef waar mogelijk: geteste versie/commit, reproductiestappen en de ingeschatte impact (privilege-escalatie, data-lek, XSS, CSRF, enz.).

## Bekende architectuurkeuzes

- Wachtwoorden: Argon2id (`password_hash`), herhash bij login.
- Sessies: `HttpOnly`, `SameSite=Lax`, `Secure` op https, nieuw sessie-ID na inloggen.
- CSRF-token op alle POST-acties, ook login en registratie.
- SQL uitsluitend via PDO prepared statements.
- Rechten: rollen → permissies; geen rol boven je eigen priority toekennen (zie [docs/AUTH.md](docs/AUTH.md)).
- Gevoelige waarden: AES-256-GCM met `app_key` uit `config/config.php` (niet in git).
- Sandboxes bevatten geen PHP en geen database-gegevens.
