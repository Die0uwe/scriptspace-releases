-- Baseline: alles wat vroeger met de hand in phpMyAdmin moest (oude installaties vóór 0.10.0). Idempotent.
CREATE TABLE IF NOT EXISTS oauth_identities (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    provider VARCHAR(20) NOT NULL,
    provider_uid VARCHAR(100) NOT NULL,
    email VARCHAR(190) NULL,
    display_name VARCHAR(100) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_provider_uid (provider, provider_uid),
    KEY idx_user (user_id),
    CONSTRAINT fk_oauth_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS social_links (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    service VARCHAR(20) NOT NULL,
    handle VARCHAR(100) NOT NULL,
    url VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_user_service (user_id, service),
    CONSTRAINT fk_social_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
ALTER TABLE users ADD COLUMN password_set TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE oauth_identities ADD COLUMN display_name VARCHAR(100) NULL;
