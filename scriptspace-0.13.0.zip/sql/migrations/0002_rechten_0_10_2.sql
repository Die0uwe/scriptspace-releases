-- 0.10.2: PHP uitvoeren alleen voor super_admin. 0.11.0/0.12.0: nieuwe rechten voor testpaneel en updates.
DELETE rp FROM role_permissions rp JOIN roles r ON r.id = rp.role_id AND r.name = 'admin' JOIN permissions p ON p.id = rp.permission_id AND p.name = 'php.execute';
INSERT IGNORE INTO permissions (name, group_name, description) VALUES ('system.test', 'admin', 'Verbindingen testen (mail, Discord, database)');
INSERT IGNORE INTO permissions (name, group_name, description) VALUES ('system.update', 'admin', 'Updates controleren en databasemigraties uitvoeren');
