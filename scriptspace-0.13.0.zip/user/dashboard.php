<?php
// user/dashboard.php — persoonlijk overzicht van de ingelogde gebruiker.
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
$u = require_login('../');

$st = db()->prepare('SELECT slug, created_at, expires_at FROM sandboxes WHERE user_id = ? ORDER BY id DESC');
$st->execute([$u['id']]);
$sandboxes = $st->fetchAll();

page_header('Dashboard', '../');
?>
<div class="card">
  <h1>Welkom, <?= e($u['username']) ?></h1>
  <p class="muted">Rollen: <?= e(implode(', ', array_column(user_roles($u['id']), 'display_name')) ?: '—') ?></p>
  <a class="btn" href="../playground.php">Naar de playground</a> <a class="btn ghost" href="account.php">Account</a>
</div>
<div class="card">
  <h2>Mijn sandboxes</h2>
  <?php if (can('sandbox.create')): ?><form method="post" action="../create_sandbox.php"><?= csrf_field() ?><button type="submit" style="margin-top:0">+ Nieuwe sandbox (72 uur)</button></form><?php endif; ?>
  <?php if (!$sandboxes): ?><p class="muted">Nog geen sandboxes.</p><?php else: ?>
  <table>
    <tr><th>ID</th><th>Aangemaakt</th><th>Verloopt</th></tr>
    <?php foreach ($sandboxes as $s): ?>
      <tr><td><?= e($s['slug']) ?></td><td><?= e($s['created_at']) ?></td><td><?= e($s['expires_at']) ?></td></tr>
    <?php endforeach; ?>
  </table>
  <?php endif; ?>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : user/dashboard.php                                        ║
// ║  Role    : User                                                      ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Persoonlijk dashboard                                     ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
