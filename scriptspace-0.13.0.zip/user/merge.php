<?php
// user/merge.php — een tweede eigen account samenvoegen met dit account.
// Je bent ingelogd op het account dat je WILT BEHOUDEN. Het andere account bewijs je met zijn wachtwoord of met zijn
// gekoppelde GitHub/Google/Discord-login, daarna bevestig je (met je eigen wachtwoord als dat is ingesteld).
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/oauth.php';
require_once __DIR__ . '/../includes/accounts.php';
$u = require_login('../');
$me = (int)$u['id'];
$pdo = db();
$providers = oauth_providers();
$msg = null;   // [soort, tekst]
$done = null;

$st = $pdo->prepare('SELECT password_hash, password_set FROM users WHERE id = ?');
$st->execute([$me]);
$mine = $st->fetch();
$hasPassword = (int)$mine['password_set'] === 1;

/** Geldig bewijs voor het andere account (alleen voor DIT ingelogde account, 10 minuten, eenmalig)? Geeft het id of 0. */
function merge_proof_id(int $me): int
{
    $p = $_SESSION['merge_proof'] ?? null;
    if (!is_array($p) || (int)($p['keep'] ?? 0) !== $me || (int)($p['at'] ?? 0) < time() - MERGE_PROOF_SECONDS) { unset($_SESSION['merge_proof']); return 0; }
    return (int)$p['drop'];
}

if (!empty($_SESSION['merge_error'])) { $msg = ['err', (string)$_SESSION['merge_error']]; unset($_SESSION['merge_error']); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    if (!csrf_verify()) {
        $msg = ['err', 'Sessie verlopen. Probeer het opnieuw.'];
    } elseif ($action === 'cancel') {
        unset($_SESSION['merge_proof']);
        redirect('account.php#koppelingen');
    } elseif ($action === 'oauth') {
        $prov = (string)($_POST['provider'] ?? '');
        if (!isset($providers[$prov])) { $msg = ['err', 'Deze dienst is niet ingesteld.']; }
        elseif (oauth_rate_limited()) { $msg = ['err', 'Te veel pogingen. Probeer het over enkele minuten opnieuw.']; }
        else { unset($_SESSION['merge_proof']); oauth_begin($prov, 'user/merge.php', 'merge'); }
    } elseif ($action === 'password') {
        $ident = trim((string)($_POST['ident'] ?? ''));
        $pass = (string)($_POST['password'] ?? '');
        if ($ident === '' || $pass === '') {
            $msg = ['err', 'Vul de gegevens van het andere account in.'];
        } elseif (login_blocked($ident)) {
            $msg = ['err', 'Te veel pogingen. Probeer het over ' . SS_LOGIN_WINDOW_MIN . ' minuten opnieuw.'];
        } else {
            $q = $pdo->prepare('SELECT * FROM users WHERE (username = ? OR email = ?) AND deleted_at IS NULL LIMIT 1');
            $q->execute([$ident, strtolower($ident)]);
            $other = $q->fetch();
            static $dummy = null;
            $dummy ??= hash_password('dummy-wachtwoord-voor-timing');
            $okpw = password_verify($pass, $other['password_hash'] ?? $dummy) && $other && (int)$other['password_set'] === 1;
            if (!$okpw) {
                login_failed($ident);
                audit('account.merge_failed', $me, ['identifier' => substr($ident, 0, 100)]);
                $msg = ['err', 'Onjuiste gegevens van het andere account.'];
            } elseif (($e = account_merge_check($me, (int)$other['id'])) !== '') {
                $msg = ['err', $e];
            } else {
                login_cleared($ident);
                $_SESSION['merge_proof'] = ['keep' => $me, 'drop' => (int)$other['id'], 'at' => time()];
                redirect('merge.php');
            }
        }
    } elseif ($action === 'confirm') {
        $drop = merge_proof_id($me);
        if ($drop === 0) {
            $msg = ['err', 'Het bewijs voor het andere account is verlopen. Begin opnieuw.'];
        } elseif ($hasPassword && !password_verify((string)($_POST['current'] ?? ''), (string)$mine['password_hash'])) {
            audit('account.merge_failed', $me, ['reason' => 'password']);
            $msg = ['err', 'Je eigen wachtwoord klopt niet.'];
        } else {
            unset($_SESSION['merge_proof']);
            try { $done = account_merge($me, $drop); } catch (RuntimeException $e) { $msg = ['err', $e->getMessage()]; }
        }
    }
}

$drop = $done ? 0 : merge_proof_id($me);
$prev = $drop ? account_merge_preview($drop) : null;

page_header('Accounts samenvoegen', '../');
?>
<div class="card">
  <h1>Accounts samenvoegen</h1>
  <?php if ($msg): ?><div class="msg <?= e($msg[0]) ?>"><?= e($msg[1]) ?></div><?php endif; ?>

<?php if ($done): ?>
  <div class="msg ok">Samengevoegd. Het account <strong><?= e($done['dropped'][0]) ?></strong> is opgegaan in <strong><?= e($u['username']) ?></strong>.</div>
  <ul>
    <li><?= (int)$done['identities'] ?> inlogkoppeling(en), <?= (int)$done['sandboxes'] ?> sandbox(es), <?= (int)$done['socials'] ?> social(s) en <?= (int)$done['keys'] ?> API-sleutel(s) verhuisd</li>
    <li><?= (int)$done['roles'] ?> extra rol(len) overgenomen</li>
  </ul>
  <p class="muted">Er is een bevestigingsmail naar beide e-mailadressen gestuurd. Inloggen met de gekoppelde diensten werkt nu op dit account.</p>
  <a class="btn" href="account.php#koppelingen">Naar mijn account</a>

<?php elseif ($prev): ?>
  <p>Je staat op het punt <strong><?= e($prev['username']) ?></strong> (<?= e($prev['email']) ?>) samen te voegen met <strong><?= e($u['username']) ?></strong>. Jij behoudt <strong><?= e($u['username']) ?></strong>.</p>
  <table>
    <tr><th>Gaat naar jouw account</th><td>
      <?= $prev['providers'] ? 'Inloggen met ' . e(implode(', ', $prev['providers'])) : 'geen gekoppelde logins' ?> ·
      <?= (int)$prev['sandboxes'] ?> sandbox(es) · <?= (int)$prev['socials'] ?> social(s) · <?= (int)$prev['keys'] ?> API-sleutel(s) ·
      rollen: <?= $prev['roles'] ? e(implode(', ', $prev['roles'])) : 'geen' ?></td></tr>
    <tr><th>Verdwijnt</th><td>het account <?= e($prev['username']) ?> zelf (gebruikersnaam, e-mailadres, wachtwoord). Is een dienst al aan jouw account gekoppeld, dan blijft jouw koppeling.</td></tr>
  </table>
  <p class="muted"><strong>Dit kan niet worden teruggedraaid.</strong> Maak zo nodig eerst een back-up.</p>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="confirm">
    <?php if ($hasPassword): ?>
      <label for="current">Je eigen wachtwoord (ter bevestiging)</label>
      <input id="current" type="password" name="current" autocomplete="current-password" required>
    <?php endif; ?>
    <button type="submit">Ja, voeg samen</button>
  </form>
  <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="action" value="cancel"><button class="btn ghost" type="submit">Annuleren</button></form>

<?php else: ?>
  <p class="muted">Heb je per ongeluk twee accounts (bijvoorbeeld omdat je met Discord een ander e-mailadres gebruikt)? Je behoudt het account waarmee je nu bent ingelogd (<strong><?= e($u['username']) ?></strong>). Bewijs eerst dat het andere account van jou is:</p>
  <?php if ($providers): ?>
  <h2>Met een gekoppelde dienst</h2>
  <p class="muted">Log in met de GitHub/Google/Discord die aan het <em>andere</em> account hangt.</p>
  <div class="row">
    <?php foreach ($providers as $key => $p): ?>
      <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="oauth"><input type="hidden" name="provider" value="<?= e($key) ?>"><button type="submit" style="margin-top:0">Met <?= e($p['label']) ?></button></form>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
  <h2>Met gebruikersnaam en wachtwoord</h2>
  <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="password">
    <label for="ident">Gebruikersnaam of e-mailadres van het andere account</label>
    <input id="ident" type="text" name="ident" autocomplete="off" required>
    <label for="pw">Wachtwoord van het andere account</label>
    <input id="pw" type="password" name="password" autocomplete="off" required>
    <button type="submit">Dit account controleren</button>
  </form>
  <p class="muted">Heeft het andere account geen wachtwoord (alleen een inlogdienst), gebruik dan de knop hierboven.</p>
  <a class="btn ghost" href="account.php#koppelingen">Terug</a>
<?php endif; ?>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : user/merge.php                                            ║
// ║  Role    : User                                                      ║
// ║  Version : 0.12.1                                                    ║
// ║  Updated : 2026-10-01                                                ║
// ║  Notes   : Twee eigen accounts samenvoegen (bewijs + bevestiging)    ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
