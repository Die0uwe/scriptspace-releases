<?php
// user/account.php — eigen accountgegevens en wachtwoord wijzigen.
declare(strict_types=1);
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/oauth.php';
require_once __DIR__ . '/../includes/socials.php';
$u = require_login('../');

$errors = [];
$ok = false;
$notice = '';
$linkErr = '';
$pdo = db();
$st = $pdo->prepare('SELECT email, created_at, password_set FROM users WHERE id = ?');
$st->execute([$u['id']]);
$row = $st->fetch();
$hasPassword = (int)$row['password_set'] === 1;
$hadPassword = $hasPassword;
$providers = oauth_providers();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? 'password');
    if (!csrf_verify()) {
        $errors[] = 'Sessie verlopen, probeer opnieuw.';
    } elseif ($action === 'link') {
        $prov = (string)($_POST['provider'] ?? '');
        if (!isset($providers[$prov])) { $linkErr = 'Deze dienst is niet ingesteld.'; }
        elseif (oauth_rate_limited()) { $linkErr = 'Te veel pogingen. Probeer het over enkele minuten opnieuw.'; }
        else { oauth_begin($prov, 'user/account.php', 'link'); }
    } elseif ($action === 'unlink') {
        $prov = (string)($_POST['provider'] ?? '');
        if (!oauth_can_unlink((int)$u['id'])) {
            $linkErr = 'Je kunt je laatste inlogmethode niet ontkoppelen. Stel eerst een wachtwoord in of koppel een ander account.';
        } else {
            $d = $pdo->prepare('DELETE FROM oauth_identities WHERE user_id = ? AND provider = ?');
            $d->execute([$u['id'], $prov]);
            if ($d->rowCount()) { audit('auth.oauth_unlink', (int)$u['id'], ['provider' => $prov]); $notice = 'Ontkoppeld.'; }
        }
    } elseif ($action === 'social_save') {
        $svc = (string)($_POST['service'] ?? '');
        [$handle, $url, $err] = social_normalize($svc, (string)($_POST['value'] ?? ''));
        if ($err !== '') { $linkErr = $err; }
        else {
            $pdo->prepare('INSERT INTO social_links (user_id, service, handle, url) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE handle = VALUES(handle), url = VALUES(url)')
                ->execute([$u['id'], $svc, $handle, $url]);
            audit('social.save', (int)$u['id'], ['service' => $svc]);
            $notice = SOCIAL_SERVICES[$svc]['label'] . ' opgeslagen.';
        }
    } elseif ($action === 'social_delete') {
        $svc = (string)($_POST['service'] ?? '');
        $d = $pdo->prepare('DELETE FROM social_links WHERE user_id = ? AND service = ?');
        $d->execute([$u['id'], $svc]);
        if ($d->rowCount()) { audit('social.delete', (int)$u['id'], ['service' => $svc]); $notice = 'Verwijderd.'; }
    } else { // wachtwoord wijzigen of (voor OAuth-accounts zonder wachtwoord) instellen
        $cur   = (string)($_POST['current'] ?? '');
        $pass  = (string)($_POST['password'] ?? '');
        $pass2 = (string)($_POST['password2'] ?? '');
        // Bescherming tegen het raden van het huidige wachtwoord via een gekaapte sessie
        $st = $pdo->prepare("SELECT COUNT(*) FROM audit_log WHERE action = 'auth.password_change_failed' AND user_id = ? AND created_at > (NOW() - INTERVAL 15 MINUTE)");
        $st->execute([$u['id']]);
        if ($hasPassword && (int)$st->fetchColumn() >= 5) {
            $errors[] = 'Te veel mislukte pogingen. Probeer het over een kwartier opnieuw.';
        } else {
            $st = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
            $st->execute([$u['id']]);
            if ($hasPassword && !password_verify($cur, (string)$st->fetchColumn())) {
                audit('auth.password_change_failed', (int)$u['id']);
                $errors[] = 'Je huidige wachtwoord klopt niet.';
            } else {
                $errors = password_problems($pass, $pass2);
                if (!$errors) {
                    set_user_password((int)$u['id'], $pass, $hasPassword ? 'password_change' : 'password_set');
                    $_SESSION['login_time'] = time() + 1; // deze sessie blijft geldig, andere sessies niet
                    session_regenerate_id(true);
                    $ok = true;
                    $hasPassword = true;
                }
            }
        }
    }
}
if (!empty($_GET['linked']) && isset(OAUTH_DEFS[(string)$_GET['linked']])) { $notice = OAUTH_DEFS[(string)$_GET['linked']]['label'] . ' gekoppeld.'; }
if (!empty($_GET['linkerr'])) { $linkErr = mb_substr((string)$_GET['linkerr'], 0, 200); }

$idents = identities_of((int)$u['id']);
$links = social_links_of((int)$u['id']);
$canUnlink = oauth_can_unlink((int)$u['id']);
$bcolors = ['github' => '#24292e', 'google' => '#db4437', 'discord' => '#5865F2', 'facebook' => '#1877f2'];

page_header('Account', '../');
?>
<div class="card">
  <h1>Account</h1>
  <p class="muted">Gebruikersnaam: <strong><?= e($u['username']) ?></strong> · E-mail: <?= e((string)$row['email']) ?> · Lid sinds <?= e(substr((string)$row['created_at'], 0, 10)) ?></p>
  <a class="btn ghost" href="dashboard.php">Terug naar dashboard</a>
</div>

<div class="card" id="koppelingen">
  <h2>Gekoppelde accounts</h2>
  <p class="muted">Met een gekoppeld account kun je inloggen zonder wachtwoord. Deze koppelingen zijn geverifieerd door de dienst zelf.</p>
  <?php if ($notice): ?><div class="msg ok"><?= e($notice) ?></div><?php endif; ?>
  <?php if ($linkErr): ?><div class="msg err"><?= e($linkErr) ?></div><?php endif; ?>
  <table id="tblOauth">
    <tr><th>Dienst</th><th>Status</th><th>Gekoppeld als</th><th></th></tr>
    <?php foreach (OAUTH_DEFS as $key => $def):
        $id = $idents[$key] ?? null; $configured = isset($providers[$key]);
        if (!$id && !$configured) { continue; } ?>
    <tr data-provider="<?= e($key) ?>">
      <td style="white-space:nowrap"><span class="dot" style="display:inline-block;width:10px;height:10px;border-radius:50%;background:<?= e($bcolors[$key] ?? '#64748b') ?>;margin-right:6px"></span><?= e($def['label']) ?></td>
      <td><?= $id ? '<span class="badge ok">Gekoppeld</span>' : '<span class="badge">Niet gekoppeld</span>' ?></td>
      <td class="brk"><?= $id ? e(($id['display_name'] ?: '') . ($id['email'] ? ' · ' . $id['email'] : '')) . ' <small>sinds ' . e(substr((string)$id['created_at'], 0, 10)) . '</small>' : '' ?></td>
      <td style="white-space:nowrap">
        <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="provider" value="<?= e($key) ?>">
        <?php if ($id): ?>
          <input type="hidden" name="action" value="unlink"><button class="btn ghost" style="margin:0;padding:4px 12px" type="submit" <?= $canUnlink ? '' : 'disabled title="Je laatste inlogmethode kun je niet ontkoppelen"' ?>>Ontkoppelen</button>
        <?php else: ?>
          <input type="hidden" name="action" value="link"><button class="btn" style="margin:0;padding:4px 12px" type="submit">Koppelen</button>
        <?php endif; ?>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
    <tr><td>E-mail &amp; wachtwoord</td><td><?= $hasPassword ? '<span class="badge ok">Ingesteld</span>' : '<span class="badge warn">Niet ingesteld</span>' ?></td><td class="muted"><?= e((string)$row['email']) ?></td><td></td></tr>
  </table>
  <p class="muted">Heb je per ongeluk twee accounts? <a href="merge.php">Accounts samenvoegen</a></p>
  <?php if (!$providers && !$idents): ?><p class="muted">Er zijn nog geen inlogdiensten ingesteld door de beheerder.</p><?php endif; ?>
</div>

<div class="card" id="socials">
  <h2>Socials</h2>
  <p class="muted">Vul je profielen in. Deze links zijn door jou ingevuld en <strong>niet geverifieerd</strong>.</p>
  <table id="tblSocial">
    <tr><th>Dienst</th><th>Profiel</th><th></th></tr>
    <?php foreach (SOCIAL_SERVICES as $key => $def): $l = $links[$key] ?? null; ?>
    <tr data-service="<?= e($key) ?>">
      <td style="white-space:nowrap"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:<?= e($def['color']) ?>;margin-right:6px"></span><?= e($def['label']) ?></td>
      <td class="brk" style="min-width:260px">
        <form method="post" class="row"><?= csrf_field() ?><input type="hidden" name="action" value="social_save"><input type="hidden" name="service" value="<?= e($key) ?>">
          <input type="text" name="value" value="<?= e($l['handle'] ?? '') ?>" placeholder="<?= e($def['ph']) ?>" maxlength="200" aria-label="<?= e($def['label']) ?>">
          <button type="submit" style="margin:0;padding:8px 12px"><?= $l ? 'Bijwerken' : 'Opslaan' ?></button>
        </form>
        <?php if ($l): ?><small><a href="<?= e($l['url']) ?>" target="_blank" rel="noopener noreferrer nofollow ugc"><?= e($l['url']) ?></a></small><?php endif; ?>
      </td>
      <td style="white-space:nowrap"><?php if ($l): ?>
        <form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="social_delete"><input type="hidden" name="service" value="<?= e($key) ?>"><button class="btn ghost" style="margin:0;padding:4px 12px" type="submit">Verwijderen</button></form>
      <?php endif; ?></td>
    </tr>
    <?php endforeach; ?>
  </table>
</div>

<div class="card">
  <h2><?= $hasPassword ? 'Wachtwoord wijzigen' : 'Wachtwoord instellen' ?></h2>
  <?php if (!$hasPassword): ?><p class="muted">Je account is gemaakt via een andere dienst en heeft nog geen eigen wachtwoord. Stel er een in om ook met e-mail te kunnen inloggen.</p><?php endif; ?>
  <?php if ($ok): ?><div class="msg ok"><?= $hadPassword ? 'Wachtwoord gewijzigd.' : 'Wachtwoord ingesteld.' ?> Andere apparaten zijn uitgelogd.</div><?php endif; ?>
  <?php foreach ($errors as $err): ?><div class="msg err"><?= e($err) ?></div><?php endforeach; ?>
  <form method="post" autocomplete="off">
    <?= csrf_field() ?><input type="hidden" name="action" value="password">
    <?php if ($hasPassword): ?><label for="current">Huidig wachtwoord</label><input type="password" id="current" name="current" required autocomplete="current-password"><?php endif; ?>
    <label for="password">Nieuw wachtwoord (min. 10 tekens)</label><input type="password" id="password" name="password" required autocomplete="new-password">
    <label for="password2">Herhaal nieuw wachtwoord</label><input type="password" id="password2" name="password2" required autocomplete="new-password">
    <button type="submit"><?= $hasPassword ? 'Wijzigen' : 'Instellen' ?></button>
  </form>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : user/account.php                                          ║
// ║  Role    : Auth                                                      ║
// ║  Version : 1.0.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Account: gekoppelde accounts, socials, wachtwoord         ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
