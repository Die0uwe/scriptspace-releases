<div align="center">

<img src="weblogo.png" alt="ScriptSpace" width="96">

# ScriptSpace CMS

**Code, AI & sandboxes op één plek** — een PHP-platform met gebruikers, rollen, een AI-playground en tijdelijke sandboxes.

![PHP](https://img.shields.io/badge/PHP-8.x-777BB4?logo=php&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-PDO-4479A1?logo=mysql&logoColor=white)
![Hosting](https://img.shields.io/badge/hosting-STRATO%20shared-orange)
![Status](https://img.shields.io/badge/status-in%20ontwikkeling-8b5cf6)

[Masterplan](docs/MASTERPLAN.md) · [Auth & rechten](docs/AUTH.md) · [Analyse & roadmap](docs/ROADMAP.md) · [Live zetten](docs/DEPLOY.md) · [Security-audit](docs/SECURITY-AUDIT.md) · [Security](SECURITY.md) · [Changelog](CHANGELOG.md)

</div>

---

## Wat is dit?

ScriptSpace (scriptspace.nl) groeit van een losse playground naar een volwaardig platform:

- 🔐 **Accounts** met open registratie, e-mailverificatie en rollen/permissies (RBAC, naar het model van [Blueprint CMS](https://github.com/Die0uwe/Blueprint-CMS))
- 🧪 **Playground** met live preview en AI-assistent (DeepSeek, Gemini) en een instelbare werkruimte: blokken (bestanden, editor, preview, console, AI) in 1–4 kolommen, sleepbare scheidingen, presets, onthouden per browser
- 📦 **Sandboxes**: tijdelijke werkomgevingen (72 uur) met automatische opruiming
- 🛠️ **Beheerpaneel** voor gebruikers, opschonen en back-up
- 💾 **Back-up & herstel** van projectbestanden en database (ZIP, herstel alleen voor super admin)
- 🧹 **Opschonen** met een knop in het adminpaneel (of via cron)

## Status

| Fase | Onderdeel | Status |
|:--:|---|:--:|
| 0 | Hygiëne: naam-login weg, OAuth uit de repo, `.htaccess`, config-template | ✅ |
| 1 | Database, login, registratie, mailverificatie, rate-limit, install-script | ✅ |
| 1b | Auth v2: RBAC met priority, audit-log, Argon2id, veilige redirect, AES-GCM-helper, 51 automatische controles | ✅ |
| 2 | `/admin/` en `/user/` met rol-poort, cron-cleanup | 🟡 skeleton |
| 3 | Playground: Ace-editor, live preview + console, full-screen, AI-proxy met eigen versleutelde key, Markdown + "Toepassen in editor" | ✅ |
| 4 | Back-up/herstel (ZIP + SQL-export), cleanup-knop in admin | ✅ |
| 5 | Eindtest en beveiligingscheck ([audit](docs/SECURITY-AUDIT.md), [live zetten](docs/DEPLOY.md)) | ✅ |
| 6 | Wachtwoord vergeten, account-pagina, sessies ongeldig na wachtwoordwijziging | ✅ |
| 7 | AI-antwoorden streamen met Stop-knop (terugval zonder streaming) | ✅ |
| 8 | Inloggen met GitHub, Google en Discord (OAuth) | ✅ |
| 9 | Account-pagina: gekoppelde accounts (GitHub/Google/Discord/Facebook) en socials (YouTube, Instagram, X, ...), uitbreidbaar | ✅ |
| 10 | Visuele (WYSIWYG) modus in de playground | ✅ |
| 11 | Bestanden en sandbox als ZIP downloaden/uploaden (voor Notepad++, VS Code, ...) | ✅ |
| 12 | Beheerpagina's: tabbalk en layout zonder overlopende tekst | ✅ |
| 7 | PHP uitvoeren in de playground (standaard uit, alleen super_admin, beperkt proces) | ✅ |
| – | Lokale map koppelen (Chrome/Edge), 2FA, PHP-WASM voor gebruikers, GrapesJS-ontwerptab | ⏳ |

Details en keuzes: [`docs/MASTERPLAN.md`](docs/MASTERPLAN.md).

## Architectuur

```mermaid
flowchart LR
    B[Browser] --> P[Pagina's<br/>login · register · playground]
    P --> A[includes/auth.php + rbac.php<br/>permissie- en statuscheck]
    A --> BS[includes/bootstrap.php<br/>sessie · CSRF · PDO · logging]
    BS --> DB[(MySQL<br/>users · roles · permissions · audit_log)]
    B -->|X-Cron-Token| C[cron/cleanup_task.php]
    C --> DB
    C --> S[sandboxes/]
    P --> AI[AI-proxy<br/>api/ai_chat.php]
    AI --> LLM[DeepSeek / Gemini]
```

### Rollen en rechten

Pagina's controleren een **permissie**, geen rolnaam. Meer in [`docs/AUTH.md`](docs/AUTH.md).

| Permissie | Anoniem | `user` (10) | `admin` (80) | `super_admin` (100) |
|---|:--:|:--:|:--:|:--:|
| Registreren / inloggen | ✅ | – | – | – |
| `sandbox.create`, `ai.use` | ❌ | ✅ | ✅ | ✅ |
| `sandbox.unlimited` | ❌ | ❌ | ✅ | ✅ |
| `php.execute` (en `'php_exec' => true`) | ❌ | ❌ | ❌ | ✅ |
| `admin.access`, `users.manage`, `logs.view`, `cleanup.run`, `backup.manage` | ❌ | ❌ | ✅ | ✅ |
| `*` (alles, inclusief rollen toekennen boven admin-niveau) | ❌ | ❌ | ❌ | ✅ |

Rolregels: nooit een rol toekennen boven je eigen niveau, geen hogere gebruikers bewerken, geen zelf-lockout, altijd minstens één actieve `super_admin`.

## Beveiliging

| Onderwerp | Aanpak |
|---|---|
| Wachtwoorden | Argon2id (terugval op PHP-standaard), herhash bij login |
| Inloggen | Rate-limit (5 pogingen / 15 min per account, 20 per IP), gelijke responstijd voor onbekende accounts |
| Formulieren | CSRF-token op alle POST-acties |
| Registratie | E-mailverificatie (token als hash opgeslagen, 24 uur geldig), honeypot, optioneel Cloudflare Turnstile, max. 5 per uur per IP |
| Sessies | `HttpOnly`, `SameSite=Lax`, `Secure` op https, nieuw sessie-ID na inloggen |
| Toegang | Rollen → permissies; account, status en verificatie bij élk verzoek uit de database; gedeactiveerde gebruikers vallen direct uit |
| Redirects | `?redirect=` alleen naar eigen paden (geen open redirect) |
| Audit | Alle gevoelige acties in `audit_log` (actie, gebruiker, JSON-context, IP), zichtbaar in het adminpaneel |
| Geheimen | AES-256-GCM (`app_key`) voor o.a. AI-keys per gebruiker |
| Bestanden | `.htaccess` deny op `includes/`, `config/`, `sql/`, `storage/`; secrets in `config/config.php` (niet in git) |
| Sandboxes | Geen PHP en geen database-gegevens in gebruikerssandboxes; quota van 3 actieve sandboxes |
| Cron | Token in header (`X-Cron-Token`) met `hash_equals`, of CLI |

## Installeren

**Vereisten:** PHP 8.x (met PDO MySQL, `mbstring`, `curl`) en een MySQL-database. Getest met PHP 8.4 en MariaDB 10.11.

1. Maak een MySQL-database aan.
2. Kopieer `config/config.example.php` naar `config/config.php` en vul in: database, `app_url`, `install_token`, `cron_token` (lange willekeurige teksten) en `app_key` (`php -r "echo 'base64:'.base64_encode(random_bytes(32)).PHP_EOL;"`).
3. Upload de bestanden en open `install.php`: token + admin-gegevens invullen. Dit maakt de tabellen en de eerste admin.
4. **Verwijder daarna `install.php` van de server.**
5. Controleer dat `/config/config.php`, `/includes/bootstrap.php` en `/sql/schema.sql` een 403 geven.

**Mail:** standaard PHP `mail()`. Lokaal testen: `'mail_debug' => true` schrijft mails naar `storage/mail.log`.
**Captcha (optioneel):** Cloudflare Turnstile-sleutels in `config.php`; leeg = uit.
**Cleanup:** gebeurt vanzelf (hoogstens elke 6 uur, `auto_cleanup_hours`), dus een cron is niet nodig op STRATO. Handmatig: knop in het adminpaneel. Optioneel: `php cron/cleanup_task.php` (CLI) of via web met header `X-Cron-Token: <cron_token>` vanuit een externe cron-dienst.

### Lokaal draaien

```bash
cp config/config.example.php config/config.php   # vul lokale DB in, mail_debug => true
php -S 127.0.0.1:8000
```

### Testen

`tests/flow_test.py` draait end-to-end controles (installatie, registratie, verificatie, login, open redirect, rechten per rol, escalatie, zelf-lockout, rate-limit, cron, sandbox-API, bestandsbeveiliging, quota, versleutelde AI-keys, AI-proxy met mock) tegen een draaiende instantie met een **lege** database. Dezelfde test draait in GitHub Actions (`.github/workflows/ci.yml`).

```bash
# testconfig: mail_debug => true, install_token en cron_token zoals in tests/flow_test.py
php -S 127.0.0.1:8099 &
SS_MYSQL="mysql ss_test" python3 tests/flow_test.py
python3 tests/ui_test.py     # browsertest van de playground (Playwright + Chromium)
```

Voor de tests moet `config.php` `'ai_mock' => true` bevatten (nep-AI-antwoorden, nooit in productie) en een geldige `app_key`.

## Mappenstructuur

```
├── index.php            landing en playground-startpagina
├── login.php  register.php  verify.php  forgot.php  reset.php  logout.php  install.php
├── playground.php  create_sandbox.php
├── api/                 sandbox · files · ai_keys · ai_chat · ai_stream · sandbox_io (JSON/SSE/ZIP, CSRF-beveiligd)
├── assets/              css/js van de playground, vendor/ (Ace, marked, DOMPurify, highlight.js)
├── admin/               index · users_manage · user_edit · logs · system_cleanup · backup_manage
├── user/                dashboard · account (wachtwoord wijzigen)
├── includes/            bootstrap · auth · rbac · crypto · layout · api · sandbox · maintenance · ai · oauth · socials
├── config/              config.example.php (config.php genegeerd)
├── cron/                cleanup_task.php
├── sql/                 schema.sql (tabellen + rollen/permissies-seed)
├── tests/               flow_test.py · ui_test.py
├── docs/                MASTERPLAN · AUTH · ROADMAP · DEPLOY · SECURITY-AUDIT
├── .github/             CI-workflow, issue- en PR-templates
├── sandboxes/  storage/ runtime, genegeerd
└── SECURITY.md  CONTRIBUTING.md  CHANGELOG.md
```

## Bekende beperkingen

- PHP uitvoeren (▶ PHP) staat standaard uit (zet `'php_exec' => true` in `config.php`), werkt alleen voor `super_admin`, en alleen als de server `proc_open`, `prlimit` en een php-cli heeft; op veel shared hosting is dat niet zo. De knop toont dan waarom hij uit staat. Gewone gebruikers krijgen HTML/CSS/JS in een afgeschermde iframe.
- AI-antwoorden komen in één keer binnen (nog geen streaming).
- Sandboxes zijn 72 uur beschikbaar, maximaal 3 tegelijk voor gewone gebruikers.
- OAuth (Google/GitHub/Discord) is bewust uit de repo gehaald en kan later als extra loginmethode terugkomen.

## Licentie

[GPL-3.0](LICENSE) © Dieouwe ([@Die0uwe](https://github.com/Die0uwe)), net als Blueprint CMS. De meegeleverde libraries in `assets/vendor/` behouden hun eigen licentie (zie `assets/vendor/README.md`).
