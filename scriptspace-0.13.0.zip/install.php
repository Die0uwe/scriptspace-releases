<?php
// install.php — eenmalig: tabellen aanmaken en eerste admin registreren.
// Vereist install_token uit config/config.php. Blokkeert zichzelf zodra er een admin bestaat of storage/install.lock bestaat.
declare(strict_types=1);
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/layout.php';

$lock = SS_ROOT . '/storage/install.lock';
if (is_file($lock)) {
    http_response_code(403);
    exit('Installatie is al uitgevoerd. Verwijder install.php van de server.');
}

$errors = [];
$done = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token    = (string)($_POST['install_token'] ?? '');
    $username = trim((string)($_POST['username'] ?? ''));
    $email    = strtolower(trim((string)($_POST['email'] ?? '')));
    $pass     = (string)($_POST['password'] ?? '');

    $expected = (string)cfg('install_token', '');
    if (!csrf_verify()) { $errors[] = 'Sessie verlopen.'; }
    if ($expected === '' || str_starts_with($expected, 'VERZIN_') || !hash_equals($expected, $token)) { $errors[] = 'Install-token onjuist of nog niet ingesteld in config.php.'; }
    if (!preg_match('/^[A-Za-z0-9_]{3,24}$/', $username)) { $errors[] = 'Ongeldige gebruikersnaam.'; }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = 'Ongeldig e-mailadres.'; }
    if (mb_strlen($pass) < 12) { $errors[] = 'Wachtwoord minimaal 12 tekens.'; }

    if (!$errors) {
        try {
            $pdo = db();
            // Commentaarregels eerst weghalen, dan statement voor statement uitvoeren
            $schema = preg_replace('/^\s*--.*$/m', '', (string)file_get_contents(SS_ROOT . '/sql/schema.sql'));
            foreach (array_filter(array_map('trim', explode(";\n", $schema))) as $sql) { $pdo->exec(rtrim($sql, ';')); }

            require_once SS_ROOT . '/includes/migrate.php';
            migrate_mark_all_applied();   // schema.sql is de actuele situatie: alle migraties zijn daarmee al verwerkt

            $n = (int)$pdo->query("SELECT COUNT(*) FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE r.name = 'super_admin'")->fetchColumn();
            if ($n > 0) {
                $errors[] = 'Er bestaat al een super admin.';
            } else {
                $pdo->prepare("INSERT INTO users (username, email, password_hash, display_name, is_active, email_verified_at) VALUES (?, ?, ?, ?, 1, NOW())")
                    ->execute([$username, $email, hash_password($pass), $username]);
                $uid = (int)$pdo->lastInsertId();
                $pdo->prepare("INSERT INTO user_roles (user_id, role_id) SELECT ?, id FROM roles WHERE name = 'super_admin'")->execute([$uid]);
                audit('system.install', $uid, ['username' => $username]);
                file_put_contents($lock, date('c'));
                $done = true;
            }
        } catch (Throwable $ex) {
            $errors[] = 'Databasefout: controleer de gegevens in config/config.php.';
        }
    }
}

// Omgevingscontrole (alleen zichtbaar tot de installatie klaar is)
require_once __DIR__ . '/includes/crypto.php';
$keyOk = true;
try { crypto_key(); } catch (Throwable $e) { $keyOk = false; }
$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
$checks = [
    ['PHP 8.1 of nieuwer (nu ' . PHP_VERSION . ')', version_compare(PHP_VERSION, '8.1.0', '>=')],
    ['Extensie pdo_mysql', extension_loaded('pdo_mysql')],
    ['Extensie mbstring', extension_loaded('mbstring')],
    ['Extensie openssl (versleutelen van AI-keys)', extension_loaded('openssl')],
    ['Extensie curl (AI-aanroepen)', extension_loaded('curl')],
    ['Extensie zip (back-ups; zonder zip werkt alleen de rest)', class_exists('ZipArchive')],
    ['storage/ is beschrijfbaar', is_writable(SS_ROOT . '/storage')],
    ['sandboxes/ is beschrijfbaar', is_writable(SS_ROOT . '/sandboxes')],
    ['Verbinding via https', $https],
    ['app_key in config.php is geldig', $keyOk],
];
page_header('Installatie');
?>
<div class="card narrow">
  <h1>Installatie</h1>
  <?php if ($done): ?>
    <div class="msg ok">Klaar. Super admin aangemaakt. <strong>Verwijder nu install.php van de server.</strong></div>
    <a class="btn" href="login.php">Naar inloggen</a>
  <?php else: ?>
    <?php foreach ($errors as $err): ?><div class="msg err"><?= e($err) ?></div><?php endforeach; ?>
    <h2 style="font-size:1rem">Omgevingscontrole</h2>
    <ul style="list-style:none;padding:0;margin:0 0 12px;font-size:.88rem">
      <?php foreach ($checks as [$label, $good]): ?><li><?= $good ? '✅' : '⚠️' ?> <?= e($label) ?></li><?php endforeach; ?>
    </ul>
    <?php if (!$keyOk): ?>
      <div class="msg err">Zet deze regel in <code>config/config.php</code> als <code>app_key</code> (elke keer een nieuwe waarde; bewaar hem, anders kunnen opgeslagen AI-keys niet meer gelezen worden):<br><code style="word-break:break-all">'app_key' =&gt; '<?= e('base64:' . base64_encode(random_bytes(32))) ?>',</code></div>
    <?php endif; ?>
    <form method="post" autocomplete="off">
      <?= csrf_field() ?>
      <label>Install-token (uit config/config.php)</label><input type="password" name="install_token" required>
      <label>Super admin-gebruikersnaam</label><input type="text" name="username" required>
      <label>Super admin-e-mail</label><input type="email" name="email" required>
      <label>Super admin-wachtwoord (min. 12 tekens)</label><input type="password" name="password" required>
      <button type="submit">Installeren</button>
    </form>
  <?php endif; ?>
</div>
<?php page_footer();

// ╔══════════════════════════════════════════════════════════════════════╗
// ║  FILE CARD                                                           ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  File    : install.php                                               ║
// ║  Role    : Setup                                                     ║
// ║  Version : 0.2.0                                                     ║
// ║  Updated : 2026-09-30                                                ║
// ║  Notes   : Eenmalig: schema + eerste super admin                     ║
// ╠══════════════════════════════════════════════════════════════════════╣
// ║  Created by Dieouwe · www.dieouwe.nl · www.slayeralliance.com        ║
// ╚══════════════════════════════════════════════════════════════════════╝
